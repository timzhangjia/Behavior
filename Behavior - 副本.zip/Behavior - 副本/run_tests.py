"""
Behavior Framework Test Runner
Provides simple command-line interface to run tests
"""

import asyncio
import sys
import os
from pathlib import Path

# Add project root directory to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

# TestRunner is not needed for this simple test runner
from tests.test_ui_example import run_all_ui_tests
from tests.test_api_example import run_all_api_tests


async def main():
    """Main function"""
    if len(sys.argv) < 2:
        print("🎭 Behavior Framework Test Runner")
        print("=" * 40)
        print("Usage:")
        print("  python run_tests.py demo          # Run demo tests")
        print("  python run_tests.py ui            # Run UI tests")
        print("  python run_tests.py api           # Run API tests")
        print("  python run_tests.py all           # Run all tests")
        return
    
    command = sys.argv[1].lower()
    
    if command == "demo":
        print("🚀 Running demo tests...")
        from main import demo_ui_test, demo_api_test
        await demo_ui_test()
        print("\n" + "="*50)
        await demo_api_test()
        
    elif command == "ui":
        print("🌐 Running UI tests...")
        await run_all_ui_tests()
        
    elif command == "api":
        print("📡 Running API tests...")
        await run_all_api_tests()
        
    elif command == "all":
        print("🎯 Running all tests...")
        print("\n" + "="*50)
        print("1. Running demo tests")
        from main import demo_ui_test, demo_api_test
        await demo_ui_test()
        print("\n" + "="*50)
        await demo_api_test()
        
        print("\n" + "="*50)
        print("2. Running UI tests")
        await run_all_ui_tests()
        
        print("\n" + "="*50)
        print("3. Running API tests")
        await run_all_api_tests()
        
        print("\n🎉 All tests completed!")
        
    else:
        print(f"❌ Unknown command: {command}")
        print("Available commands: demo, ui, api, all")


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n⏹️ Tests interrupted by user")
    except Exception as e:
        print(f"\n❌ Error running tests: {str(e)}")
