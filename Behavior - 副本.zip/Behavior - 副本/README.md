# Behavior Framework

A Python UI and API automation testing framework based on Playwright, providing clean APIs and powerful functionality.

## 🚀 Features

- **Clean APIs**: Behavior-based testing approach, easy to understand and maintain
- **Powerful Element Location**: Supports multiple element location strategies
- **Rich Assertions**: Built-in various assertion behaviors with custom assertion support
- **Async Support**: Fully based on async/await for excellent performance
- **Flexible Configuration**: Supports environment variables and configuration files
- **Detailed Logging**: Complete logging and debugging information
- **Screenshot Support**: Automatic screenshots and report generation
- **Dual Testing**: Separate UI and API testing modules

## 📦 Installation

1. Clone the project or download source code
2. Install dependencies:

```bash
pip install -r requirements.txt
```

3. Install Playwright browsers:

```bash
playwright install
```

## 🎯 快速开始

### 基本用法

```python
import asyncio
from behavior_framework import Browser, Page, Navigate, Click, Type, ShouldBeVisible

async def test_example():
    async with Browser() as browser:
        page = await browser.new_page()
        
        # 导航到页面
        navigate = Navigate(page, "https://example.com")
        await navigate.execute()
        
        # 查找并点击元素
        button = page.get_element("button")
        click_action = Click(button)
        await click_action.execute()
        
        # 输入文本
        input_field = page.get_element("input")
        type_action = Type(input_field, "Hello World")
        await type_action.execute()
        
        # 验证元素可见
        result = page.get_element("#result")
        should_be_visible = ShouldBeVisible(result)
        assert await should_be_visible.execute()

# 运行测试
asyncio.run(test_example())
```

### 独立测试函数

```python
import asyncio
from behavior_framework import Browser, Page

async def test_with_async():
    async with Browser() as browser:
        page = await browser.new_page()
        await page.goto("https://example.com")
        
        element = page.get_element("h1")
        is_visible = await element.is_visible()
        print(f"元素可见: {is_visible}")

# 运行测试
asyncio.run(test_with_async())
```

## 🏗️ 框架结构

```
behavior_framework/
├── core/                    # 核心模块
│   ├── browser.py          # 浏览器管理
│   ├── page.py             # 页面管理
│   └── element.py          # 元素管理
├── behaviors/              # 行为模式
│   ├── actions.py          # 操作行为
│   └── assertions.py       # 断言行为
├── config/                 # 配置管理
│   └── settings.py         # 设置配置
├── utils/                  # 工具模块
│   └── logger.py           # 日志工具
└── test_runner.py          # 测试运行器

tests/                      # 测试用例
├── conftest.py            # pytest 配置
├── test_example.py        # 示例测试
└── test_behavior_patterns.py  # 行为模式测试
```

## 🎭 行为模式

### 操作行为

- **Navigate**: 页面导航
- **Click**: 点击操作
- **Type**: 文本输入
- **Clear**: 清空内容
- **Hover**: 鼠标悬停
- **Wait**: 等待操作
- **Select**: 下拉选择
- **Scroll**: 滚动操作

### 断言行为

- **ShouldBeVisible**: 元素可见断言
- **ShouldNotBeVisible**: 元素不可见断言
- **ShouldHaveText**: 文本内容断言
- **ShouldBeEnabled**: 元素启用断言
- **ShouldBeDisabled**: 元素禁用断言
- **ShouldBeChecked**: 元素选中断言
- **ShouldHaveAttribute**: 属性断言
- **ShouldHaveCount**: 数量断言

## ⚙️ 配置

### 环境变量配置

复制 `env.example` 为 `.env` 文件并修改配置：

```bash
# 浏览器配置
HEADLESS=false
BROWSER_TYPE=chromium
DEFAULT_TIMEOUT=30000

# 日志配置
LOG_LEVEL=INFO
LOG_FILE_PATH=logs/behavior_framework.log

# 截图配置
SCREENSHOT_ON_FAILURE=true
SCREENSHOT_DIR=screenshots
```

### 代码配置

```python
from behavior_framework import Settings

# 创建自定义配置
settings = Settings()
settings.browser.headless = True
settings.timeout.default_timeout = 60000

# 使用配置创建浏览器
browser = Browser(settings)
```

## 🧪 运行测试

### 直接运行测试文件

```bash
# 运行演示程序
python main.py

# 运行示例测试
python tests/test_example.py

# 运行行为模式测试
python tests/test_behavior_patterns.py

# 使用测试运行器（推荐）
python run_tests.py demo      # 演示测试
python run_tests.py example   # 示例测试
python run_tests.py behavior  # 行为模式测试
python run_tests.py all       # 所有测试
```

### 使用测试运行器

```python
import asyncio
from behavior_framework import TestRunner
from tests.test_example import test_simple_navigation

async def run_tests():
    runner = TestRunner()
    await runner.run_single_test(test_simple_navigation)

# 运行测试
asyncio.run(run_tests())
```

## 📊 报告和日志

- **HTML 报告**: 自动生成详细的测试报告
- **截图**: 失败时自动截图
- **日志**: 完整的操作日志记录
- **控制台输出**: 清晰的测试结果显示

## 🔧 扩展开发

### 自定义行为

```python
from behavior_framework.behaviors.actions import Action

class CustomAction(Action):
    def __init__(self, element, custom_param):
        self.element = element
        self.custom_param = custom_param
    
    async def execute(self):
        # 实现自定义逻辑
        await self.element.click()
        # 其他操作...
```

### 自定义断言

```python
from behavior_framework.behaviors.assertions import Assertion

class CustomAssertion(Assertion):
    def __init__(self, element, expected_value):
        self.element = element
        self.expected_value = expected_value
    
    async def execute(self):
        # 实现自定义断言逻辑
        actual_value = await self.element.get_attribute("data-value")
        return actual_value == self.expected_value
```

## 🤝 贡献

欢迎提交 Issue 和 Pull Request 来改进框架！

## 📄 许可证

MIT License

## 📞 支持

如有问题，请提交 Issue 或联系开发团队。
