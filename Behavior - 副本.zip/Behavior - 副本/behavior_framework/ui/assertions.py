"""
UI Assertion Module - Provides predefined assertion behaviors
"""

from typing import Optional, Union
from .element import Element
from ..utils.logger import Logger


class ShouldBeVisible:
    """Element should be visible assertion"""
    
    def __init__(self, element: Element, timeout: Optional[int] = None):
        self.element = element
        self.timeout = timeout
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute visibility assertion"""
        try:
            is_visible = await self.element.is_visible(timeout=self.timeout)
            if is_visible:
                self.logger.info("Assertion passed: Element is visible")
                return True
            else:
                self.logger.error("Assertion failed: Element is not visible")
                return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False


class ShouldNotBeVisible:
    """Element should not be visible assertion"""
    
    def __init__(self, element: Element, timeout: Optional[int] = None):
        self.element = element
        self.timeout = timeout
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute not visible assertion"""
        try:
            is_visible = await self.element.is_visible(timeout=self.timeout)
            if not is_visible:
                self.logger.info("Assertion passed: Element is not visible")
                return True
            else:
                self.logger.error("Assertion failed: Element is visible")
                return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False


class ShouldHaveText:
    """Element should have specified text assertion"""
    
    def __init__(self, element: Element, expected_text: str, exact: bool = False, timeout: Optional[int] = None):
        self.element = element
        self.expected_text = expected_text
        self.exact = exact
        self.timeout = timeout
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute text assertion"""
        try:
            actual_text = await self.element.text_content(timeout=self.timeout)
            
            if actual_text is None:
                self.logger.error(f"Assertion failed: Unable to get element text")
                return False
            
            if self.exact:
                is_match = actual_text == self.expected_text
            else:
                is_match = self.expected_text in actual_text
            
            if is_match:
                self.logger.info(f"Assertion passed: Element text matches '{self.expected_text}'")
                return True
            else:
                self.logger.error(f"Assertion failed: Expected text '{self.expected_text}', Actual text '{actual_text}'")
                return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False


class ShouldBeEnabled:
    """Element should be enabled assertion"""
    
    def __init__(self, element: Element, timeout: Optional[int] = None):
        self.element = element
        self.timeout = timeout
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute enabled state assertion"""
        try:
            is_enabled = await self.element.is_enabled(timeout=self.timeout)
            if is_enabled:
                self.logger.info("Assertion passed: Element is enabled")
                return True
            else:
                self.logger.error("Assertion failed: Element is not enabled")
                return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False


class ShouldBeDisabled:
    """Element should be disabled assertion"""
    
    def __init__(self, element: Element, timeout: Optional[int] = None):
        self.element = element
        self.timeout = timeout
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute disabled state assertion"""
        try:
            is_enabled = await self.element.is_enabled(timeout=self.timeout)
            if not is_enabled:
                self.logger.info("Assertion passed: Element is disabled")
                return True
            else:
                self.logger.error("Assertion failed: Element is not disabled")
                return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False


class ShouldBeChecked:
    """Element should be checked assertion"""
    
    def __init__(self, element: Element, timeout: Optional[int] = None):
        self.element = element
        self.timeout = timeout
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute checked state assertion"""
        try:
            is_checked = await self.element.is_checked(timeout=self.timeout)
            if is_checked:
                self.logger.info("Assertion passed: Element is checked")
                return True
            else:
                self.logger.error("Assertion failed: Element is not checked")
                return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False


class ShouldHaveAttribute:
    """Element should have specified attribute assertion"""
    
    def __init__(self, element: Element, attribute_name: str, expected_value: Optional[str] = None, 
                 timeout: Optional[int] = None):
        self.element = element
        self.attribute_name = attribute_name
        self.expected_value = expected_value
        self.timeout = timeout
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute attribute assertion"""
        try:
            actual_value = await self.element.get_attribute(self.attribute_name, timeout=self.timeout)
            
            if self.expected_value is None:
                # Only check if attribute exists
                if actual_value is not None:
                    self.logger.info(f"Assertion passed: Attribute '{self.attribute_name}' exists")
                    return True
                else:
                    self.logger.error(f"Assertion failed: Attribute '{self.attribute_name}' does not exist")
                    return False
            else:
                # Check attribute value
                if actual_value == self.expected_value:
                    self.logger.info(f"Assertion passed: Attribute '{self.attribute_name}' value matches '{self.expected_value}'")
                    return True
                else:
                    self.logger.error(f"Assertion failed: Expected value '{self.expected_value}', Actual value '{actual_value}'")
                    return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False


class ShouldHaveCount:
    """Element should have specified count assertion"""
    
    def __init__(self, element: Element, expected_count: int):
        self.element = element
        self.expected_count = expected_count
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute count assertion"""
        try:
            actual_count = await self.element.count()
            if actual_count == self.expected_count:
                self.logger.info(f"Assertion passed: Element count matches {self.expected_count}")
                return True
            else:
                self.logger.error(f"Assertion failed: Expected count {self.expected_count}, Actual count {actual_count}")
                return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False
