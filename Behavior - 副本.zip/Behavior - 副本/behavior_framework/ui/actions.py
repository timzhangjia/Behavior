"""
UI Action Behaviors Module - Provides predefined user behavior actions
"""

from typing import Optional, Union
from .element import Element
from .page import Page
from ..utils.logger import Logger


class Click:
    """Click behavior"""
    
    def __init__(self, element: Element, force: bool = False):
        self.element = element
        self.force = force
        self.logger = Logger()
    
    async def execute(self) -> None:
        """Execute click action"""
        await self.element.click(force=self.force)
        self.logger.info("Click behavior executed")


class Type:
    """Type behavior"""
    
    def __init__(self, element: Element, text: str, slow: bool = False, delay: int = 100):
        self.element = element
        self.text = text
        self.slow = slow
        self.delay = delay
        self.logger = Logger()
    
    async def execute(self) -> None:
        """Execute type action"""
        if self.slow:
            await self.element.type_slowly(self.text, delay=self.delay)
        else:
            await self.element.type(self.text)
        self.logger.info(f"Type behavior executed: {self.text}")


class Wait:
    """Wait behavior"""
    
    def __init__(self, element: Optional[Element] = None, page: Optional[Page] = None, 
                 state: str = "visible", timeout: Optional[int] = None):
        self.element = element
        self.page = page
        self.state = state
        self.timeout = timeout
        self.logger = Logger()
    
    async def execute(self) -> None:
        """Execute wait action"""
        if self.element:
            await self.element.wait_for(state=self.state, timeout=self.timeout)
            self.logger.info(f"Element state wait: {self.state}")
        elif self.page:
            await self.page.wait_for_load_state(self.state)
            self.logger.info(f"Page state wait: {self.state}")


class Navigate:
    """Navigate behavior"""
    
    def __init__(self, page: Page, url: str, wait_until: str = "domcontentloaded"):
        self.page = page
        self.url = url
        self.wait_until = wait_until
        self.logger = Logger()
    
    async def execute(self) -> None:
        """Execute navigate action"""
        await self.page.goto(self.url, wait_until=self.wait_until)
        self.logger.info(f"Navigate behavior executed: {self.url}")


class Clear:
    """Clear behavior"""
    
    def __init__(self, element: Element):
        self.element = element
        self.logger = Logger()
    
    async def execute(self) -> None:
        """Execute clear action"""
        await self.element.clear()
        self.logger.info("Clear behavior executed")


class Hover:
    """Hover behavior"""
    
    def __init__(self, element: Element):
        self.element = element
        self.logger = Logger()
    
    async def execute(self) -> None:
        """Execute hover action"""
        await self.element.hover()
        self.logger.info("Hover behavior executed")


class Select:
    """Select behavior (dropdown)"""
    
    def __init__(self, element: Element, value: Union[str, int, list]):
        self.element = element
        self.value = value
        self.logger = Logger()
    
    async def execute(self) -> None:
        """Execute select action"""
        await self.element.locator.select_option(self.value)
        self.logger.info(f"Select behavior executed: {self.value}")


class Scroll:
    """Scroll behavior"""
    
    def __init__(self, element: Optional[Element] = None, page: Optional[Page] = None,
                 direction: str = "down", amount: int = 300):
        self.element = element
        self.page = page
        self.direction = direction
        self.amount = amount
        self.logger = Logger()
    
    async def execute(self) -> None:
        """Execute scroll action"""
        if self.element:
            if self.direction == "down":
                await self.element.locator.scroll_into_view_if_needed()
            else:
                await self.element.locator.scroll_into_view_if_needed()
        elif self.page:
            if self.direction == "down":
                await self.page.page.evaluate(f"window.scrollBy(0, {self.amount})")
            else:
                await self.page.page.evaluate(f"window.scrollBy(0, -{self.amount})")
        
        self.logger.info(f"Scroll behavior executed: {self.direction}")
