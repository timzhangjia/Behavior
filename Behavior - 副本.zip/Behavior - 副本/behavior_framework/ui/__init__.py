"""UI Testing Module - Browser automation and UI testing components"""
