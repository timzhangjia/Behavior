"""
API Response Module - Response handling and parsing
"""

import json
from typing import Optional, Dict, Any, Union
from ..utils.logger import Logger


class Response:
    """Response wrapper class"""
    
    def __init__(self, status: int, headers: Dict[str, str], content: bytes, 
                 text: str, url: str):
        self.status = status
        self.headers = headers
        self.content = content
        self.text = text
        self.url = url
        self.logger = Logger()
        
        # Parse JSON if possible
        self._json_data = None
        try:
            if self.text and self.is_json():
                self._json_data = json.loads(self.text)
        except json.JSONDecodeError:
            pass
    
    def is_json(self) -> bool:
        """Check if response is JSON"""
        content_type = self.headers.get('content-type', '').lower()
        return 'application/json' in content_type
    
    def json(self) -> Optional[Dict[str, Any]]:
        """Get JSON data"""
        return self._json_data
    
    def get_header(self, name: str) -> Optional[str]:
        """Get header value by name (case insensitive)"""
        name_lower = name.lower()
        for header_name, value in self.headers.items():
            if header_name.lower() == name_lower:
                return value
        return None
    
    def get_json_value(self, key: str, default: Any = None) -> Any:
        """Get value from JSON response by key"""
        if self._json_data is None:
            return default
        
        keys = key.split('.')
        value = self._json_data
        
        try:
            for k in keys:
                if isinstance(value, dict):
                    value = value[k]
                else:
                    return default
            return value
        except (KeyError, TypeError):
            return default
    
    def is_success(self) -> bool:
        """Check if response is successful (2xx status)"""
        return 200 <= self.status < 300
    
    def is_client_error(self) -> bool:
        """Check if response is client error (4xx status)"""
        return 400 <= self.status < 500
    
    def is_server_error(self) -> bool:
        """Check if response is server error (5xx status)"""
        return 500 <= self.status < 600
    
    def size(self) -> int:
        """Get response size in bytes"""
        return len(self.content)
    
    def __repr__(self) -> str:
        return f"Response(status={self.status}, url='{self.url}')"
