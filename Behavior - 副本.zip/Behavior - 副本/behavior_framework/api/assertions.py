"""
API Assertion Module - Provides predefined API response assertions
"""

from typing import Optional, Union, Dict, Any
from .response import Response
from ..utils.logger import Logger


class ShouldHaveStatus:
    """Response should have specified status code assertion"""
    
    def __init__(self, response: Response, expected_status: Union[int, list]):
        self.response = response
        self.expected_status = expected_status if isinstance(expected_status, list) else [expected_status]
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute status assertion"""
        try:
            if self.response.status in self.expected_status:
                self.logger.info(f"Assertion passed: Status code {self.response.status} matches expected {self.expected_status}")
                return True
            else:
                self.logger.error(f"Assertion failed: Expected status {self.expected_status}, Actual status {self.response.status}")
                return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False


class ShouldHaveHeader:
    """Response should have specified header assertion"""
    
    def __init__(self, response: Response, header_name: str, expected_value: Optional[str] = None):
        self.response = response
        self.header_name = header_name
        self.expected_value = expected_value
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute header assertion"""
        try:
            actual_value = self.response.get_header(self.header_name)
            
            if self.expected_value is None:
                # Only check if header exists
                if actual_value is not None:
                    self.logger.info(f"Assertion passed: Header '{self.header_name}' exists")
                    return True
                else:
                    self.logger.error(f"Assertion failed: Header '{self.header_name}' does not exist")
                    return False
            else:
                # Check header value
                if actual_value == self.expected_value:
                    self.logger.info(f"Assertion passed: Header '{self.header_name}' value matches '{self.expected_value}'")
                    return True
                else:
                    self.logger.error(f"Assertion failed: Expected value '{self.expected_value}', Actual value '{actual_value}'")
                    return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False


class ShouldHaveJson:
    """Response should have specified JSON value assertion"""
    
    def __init__(self, response: Response, key: str, expected_value: Any = None):
        self.response = response
        self.key = key
        self.expected_value = expected_value
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute JSON assertion"""
        try:
            if not self.response.is_json():
                self.logger.error("Assertion failed: Response is not JSON")
                return False
            
            actual_value = self.response.get_json_value(self.key)
            
            if self.expected_value is None:
                # Only check if key exists
                if actual_value is not None:
                    self.logger.info(f"Assertion passed: JSON key '{self.key}' exists")
                    return True
                else:
                    self.logger.error(f"Assertion failed: JSON key '{self.key}' does not exist")
                    return False
            else:
                # Check JSON value
                if actual_value == self.expected_value:
                    self.logger.info(f"Assertion passed: JSON key '{self.key}' value matches expected")
                    return True
                else:
                    self.logger.error(f"Assertion failed: Expected value '{self.expected_value}', Actual value '{actual_value}'")
                    return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False


class ShouldHaveText:
    """Response should contain specified text assertion"""
    
    def __init__(self, response: Response, expected_text: str, exact: bool = False):
        self.response = response
        self.expected_text = expected_text
        self.exact = exact
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute text assertion"""
        try:
            if self.exact:
                is_match = self.response.text == self.expected_text
            else:
                is_match = self.expected_text in self.response.text
            
            if is_match:
                self.logger.info(f"Assertion passed: Response text matches '{self.expected_text}'")
                return True
            else:
                self.logger.error(f"Assertion failed: Expected text '{self.expected_text}' not found in response")
                return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False


class ShouldBeSuccess:
    """Response should be successful (2xx status) assertion"""
    
    def __init__(self, response: Response):
        self.response = response
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute success assertion"""
        try:
            if self.response.is_success():
                self.logger.info(f"Assertion passed: Response is successful (status {self.response.status})")
                return True
            else:
                self.logger.error(f"Assertion failed: Response is not successful (status {self.response.status})")
                return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False


class ShouldBeClientError:
    """Response should be client error (4xx status) assertion"""
    
    def __init__(self, response: Response):
        self.response = response
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute client error assertion"""
        try:
            if self.response.is_client_error():
                self.logger.info(f"Assertion passed: Response is client error (status {self.response.status})")
                return True
            else:
                self.logger.error(f"Assertion failed: Response is not client error (status {self.response.status})")
                return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False


class ShouldBeServerError:
    """Response should be server error (5xx status) assertion"""
    
    def __init__(self, response: Response):
        self.response = response
        self.logger = Logger()
    
    async def execute(self) -> bool:
        """Execute server error assertion"""
        try:
            if self.response.is_server_error():
                self.logger.info(f"Assertion passed: Response is server error (status {self.response.status})")
                return True
            else:
                self.logger.error(f"Assertion failed: Response is not server error (status {self.response.status})")
                return False
        except Exception as e:
            self.logger.error(f"Assertion execution failed: {str(e)}")
            return False
