"""
API Action Behaviors Module - Provides predefined API request actions
"""

from typing import Optional, Dict, Any, Union
from .client import APIClient
from .response import Response
from ..utils.logger import Logger


class Get:
    """GET request action"""
    
    def __init__(self, client: APIClient, endpoint: str, params: Optional[Dict] = None, 
                 headers: Optional[Dict] = None):
        self.client = client
        self.endpoint = endpoint
        self.params = params or {}
        self.headers = headers or {}
        self.logger = Logger()
    
    async def execute(self) -> Response:
        """Execute GET request"""
        try:
            response = await self.client.get(
                self.endpoint,
                params=self.params,
                headers=self.headers
            )
            self.logger.info(f"GET request executed: {self.endpoint}")
            return response
        except Exception as e:
            self.logger.error(f"GET request failed: {str(e)}")
            raise


class Post:
    """POST request action"""
    
    def __init__(self, client: APIClient, endpoint: str, data: Optional[Union[Dict, str]] = None,
                 json: Optional[Dict] = None, params: Optional[Dict] = None,
                 headers: Optional[Dict] = None):
        self.client = client
        self.endpoint = endpoint
        self.data = data
        self.json = json
        self.params = params or {}
        self.headers = headers or {}
        self.logger = Logger()
    
    async def execute(self) -> Response:
        """Execute POST request"""
        try:
            response = await self.client.post(
                self.endpoint,
                data=self.data,
                json=self.json,
                params=self.params,
                headers=self.headers
            )
            self.logger.info(f"POST request executed: {self.endpoint}")
            return response
        except Exception as e:
            self.logger.error(f"POST request failed: {str(e)}")
            raise


class Put:
    """PUT request action"""
    
    def __init__(self, client: APIClient, endpoint: str, data: Optional[Union[Dict, str]] = None,
                 json: Optional[Dict] = None, params: Optional[Dict] = None,
                 headers: Optional[Dict] = None):
        self.client = client
        self.endpoint = endpoint
        self.data = data
        self.json = json
        self.params = params or {}
        self.headers = headers or {}
        self.logger = Logger()
    
    async def execute(self) -> Response:
        """Execute PUT request"""
        try:
            response = await self.client.put(
                self.endpoint,
                data=self.data,
                json=self.json,
                params=self.params,
                headers=self.headers
            )
            self.logger.info(f"PUT request executed: {self.endpoint}")
            return response
        except Exception as e:
            self.logger.error(f"PUT request failed: {str(e)}")
            raise


class Delete:
    """DELETE request action"""
    
    def __init__(self, client: APIClient, endpoint: str, params: Optional[Dict] = None,
                 headers: Optional[Dict] = None):
        self.client = client
        self.endpoint = endpoint
        self.params = params or {}
        self.headers = headers or {}
        self.logger = Logger()
    
    async def execute(self) -> Response:
        """Execute DELETE request"""
        try:
            response = await self.client.delete(
                self.endpoint,
                params=self.params,
                headers=self.headers
            )
            self.logger.info(f"DELETE request executed: {self.endpoint}")
            return response
        except Exception as e:
            self.logger.error(f"DELETE request failed: {str(e)}")
            raise


class Patch:
    """PATCH request action"""
    
    def __init__(self, client: APIClient, endpoint: str, data: Optional[Union[Dict, str]] = None,
                 json: Optional[Dict] = None, params: Optional[Dict] = None,
                 headers: Optional[Dict] = None):
        self.client = client
        self.endpoint = endpoint
        self.data = data
        self.json = json
        self.params = params or {}
        self.headers = headers or {}
        self.logger = Logger()
    
    async def execute(self) -> Response:
        """Execute PATCH request"""
        try:
            response = await self.client.patch(
                self.endpoint,
                data=self.data,
                json=self.json,
                params=self.params,
                headers=self.headers
            )
            self.logger.info(f"PATCH request executed: {self.endpoint}")
            return response
        except Exception as e:
            self.logger.error(f"PATCH request failed: {str(e)}")
            raise
