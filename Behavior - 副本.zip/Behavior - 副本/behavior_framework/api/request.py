"""
API Request Module - Request configuration and building
"""

from typing import Optional, Dict, Any, Union, List
import json
from ..utils.logger import Logger


class Request:
    """Request configuration class"""
    
    def __init__(self, method: str, endpoint: str, **kwargs):
        self.method = method.upper()
        self.endpoint = endpoint
        self.headers = kwargs.get('headers', {})
        self.params = kwargs.get('params', {})
        self.data = kwargs.get('data', None)
        self.json = kwargs.get('json', None)
        self.timeout = kwargs.get('timeout', None)
        self.logger = Logger()
    
    def add_header(self, key: str, value: str) -> "Request":
        """Add header to request"""
        self.headers[key] = value
        return self
    
    def add_param(self, key: str, value: Union[str, int, float, List]) -> "Request":
        """Add query parameter to request"""
        self.params[key] = value
        return self
    
    def set_json(self, data: Dict[str, Any]) -> "Request":
        """Set JSON data for request"""
        self.json = data
        return self
    
    def set_data(self, data: Union[str, bytes, Dict]) -> "Request":
        """Set form data for request"""
        self.data = data
        return self
    
    def set_timeout(self, timeout: float) -> "Request":
        """Set request timeout"""
        self.timeout = timeout
        return self
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert request to dictionary"""
        request_dict = {
            "method": self.method,
            "endpoint": self.endpoint,
            "headers": self.headers,
            "params": self.params
        }
        
        if self.data is not None:
            request_dict["data"] = self.data
        if self.json is not None:
            request_dict["json"] = self.json
        if self.timeout is not None:
            request_dict["timeout"] = self.timeout
            
        return request_dict
    
    def __repr__(self) -> str:
        return f"Request(method='{self.method}', endpoint='{self.endpoint}')"
