"""API Testing Module - HTTP client and API testing components"""
