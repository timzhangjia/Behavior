"""
API Client Module - HTTP client management and configuration
"""

import asyncio
from typing import Optional, Dict, Any, Union
import aiohttp
from .request import Request
from .response import Response
from ..config.settings import Settings
from ..utils.logger import Logger


class APIClient:
    """API client manager, wraps aiohttp client operations"""
    
    def __init__(self, settings: Optional[Settings] = None, base_url: Optional[str] = None):
        self.settings = settings or Settings()
        self.base_url = base_url or self.settings.base_url
        self.session: Optional[aiohttp.ClientSession] = None
        self.logger = Logger()
        
        # Default headers
        self.default_headers = {
            "Content-Type": "application/json",
            "User-Agent": "Behavior-Framework/1.0.0"
        }
        
        # Default timeout
        self.timeout = aiohttp.ClientTimeout(total=self.settings.timeout.default_timeout / 1000)
    
    async def start(self) -> None:
        """Start HTTP client session"""
        try:
            connector = aiohttp.TCPConnector(limit=100, limit_per_host=30)
            self.session = aiohttp.ClientSession(
                connector=connector,
                timeout=self.timeout,
                headers=self.default_headers
            )
            self.logger.info("API client started")
        except Exception as e:
            self.logger.error(f"Failed to start API client: {str(e)}")
            raise
    
    async def close(self) -> None:
        """Close HTTP client session"""
        try:
            if self.session:
                await self.session.close()
            self.logger.info("API client closed")
        except Exception as e:
            self.logger.error(f"Error closing API client: {str(e)}")
    
    async def __aenter__(self):
        """Async context manager entry"""
        await self.start()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.close()
    
    def _build_url(self, endpoint: str) -> str:
        """Build full URL from endpoint"""
        if endpoint.startswith(("http://", "https://")):
            return endpoint
        return f"{self.base_url.rstrip('/')}/{endpoint.lstrip('/')}"
    
    async def _make_request(self, method: str, endpoint: str, **kwargs) -> Response:
        """Make HTTP request"""
        if not self.session:
            raise RuntimeError("API client not started, please call start() method first")
        
        url = self._build_url(endpoint)
        
        try:
            self.logger.info(f"{method.upper()} request to: {url}")
            
            async with self.session.request(method, url, **kwargs) as http_response:
                # Read response content
                content = await http_response.read()
                text = content.decode('utf-8', errors='ignore')
                
                # Create response object
                response = Response(
                    status=http_response.status,
                    headers=dict(http_response.headers),
                    content=content,
                    text=text,
                    url=str(http_response.url)
                )
                
                self.logger.info(f"Response received: {http_response.status}")
                return response
                
        except Exception as e:
            self.logger.error(f"Request failed: {str(e)}")
            raise
    
    async def get(self, endpoint: str, **kwargs) -> Response:
        """Make GET request"""
        return await self._make_request("GET", endpoint, **kwargs)
    
    async def post(self, endpoint: str, **kwargs) -> Response:
        """Make POST request"""
        return await self._make_request("POST", endpoint, **kwargs)
    
    async def put(self, endpoint: str, **kwargs) -> Response:
        """Make PUT request"""
        return await self._make_request("PUT", endpoint, **kwargs)
    
    async def delete(self, endpoint: str, **kwargs) -> Response:
        """Make DELETE request"""
        return await self._make_request("DELETE", endpoint, **kwargs)
    
    async def patch(self, endpoint: str, **kwargs) -> Response:
        """Make PATCH request"""
        return await self._make_request("PATCH", endpoint, **kwargs)
    
    def set_header(self, key: str, value: str) -> None:
        """Set default header"""
        self.default_headers[key] = value
        if self.session:
            self.session.headers.update({key: value})
    
    def set_auth(self, auth_type: str, credentials: Union[str, tuple]) -> None:
        """Set authentication"""
        if auth_type.lower() == "bearer":
            self.set_header("Authorization", f"Bearer {credentials}")
        elif auth_type.lower() == "basic":
            import base64
            if isinstance(credentials, tuple):
                username, password = credentials
                encoded = base64.b64encode(f"{username}:{password}".encode()).decode()
                self.set_header("Authorization", f"Basic {encoded}")
        elif auth_type.lower() == "api_key":
            if isinstance(credentials, tuple):
                key, value = credentials
                self.set_header(key, value)
