"""
Behavior Framework - Python UI and API Automation Testing Framework

A clean and powerful framework for both UI and API automation testing.
"""

__version__ = "1.0.0"
__author__ = "Behavior Framework Team"

# UI Testing Components
from .ui.browser import Browser
from .ui.page import Page
from .ui.element import Element
from .ui.actions import Click, Type, Wait, Navigate
from .ui.assertions import ShouldBeVisible, ShouldHaveText, ShouldBeEnabled

# API Testing Components
from .api.client import APIClient
from .api.request import Request
from .api.response import Response
from .api.actions import Get, Post, Put, Delete
from .api.assertions import ShouldHaveStatus, ShouldHaveHeader, ShouldHaveJson, ShouldBeSuccess

# Common Components
from .config.settings import Settings
from .utils.logger import Logger

__all__ = [
    # UI Testing
    "Browser",
    "Page", 
    "Element",
    "Click",
    "Type",
    "Wait",
    "Navigate",
    "ShouldBeVisible",
    "ShouldHaveText",
    "ShouldBeEnabled",
    
    # API Testing
    "APIClient",
    "Request",
    "Response",
    "Get",
    "Post",
    "Put",
    "Delete",
    "ShouldHaveStatus",
    "ShouldHaveHeader",
    "ShouldHaveJson",
    "ShouldBeSuccess",
    
    # Common
    "Settings",
    "Logger"
]