"""
Test Runner - Provides test execution and report generation functionality
"""

import asyncio
import os
from typing import List, Dict, Any, Optional
from pathlib import Path
from .config.settings import Settings
from .utils.logger import Logger


class TestRunner:
    """Test runner"""
    
    def __init__(self, settings: Optional[Settings] = None):
        self.settings = settings or Settings()
        self.logger = Logger()
        self.test_results: List[Dict[str, Any]] = []
    
    async def run_single_test(self, test_function) -> Dict[str, Any]:
        """Run single test"""
        test_name = test_function.__name__
        self.logger.info(f"Starting test execution: {test_name}")
        
        result = {
            "name": test_name,
            "status": "unknown",
            "start_time": None,
            "end_time": None,
            "duration": None,
            "error": None,
            "screenshot": None
        }
        
        try:
            import time
            result["start_time"] = time.time()
            
            # Execute test function
            if asyncio.iscoroutinefunction(test_function):
                await test_function()
            else:
                test_function()
            
            result["end_time"] = time.time()
            result["duration"] = result["end_time"] - result["start_time"]
            result["status"] = "passed"
            
            self.logger.success(f"Test passed: {test_name}")
            
            # Success screenshot
            if self.settings.screenshot.on_success:
                screenshot_path = await self._take_screenshot(test_name, "success")
                result["screenshot"] = screenshot_path
            
        except Exception as e:
            result["end_time"] = time.time()
            result["duration"] = result["end_time"] - result["start_time"]
            result["status"] = "failed"
            result["error"] = str(e)
            
            self.logger.error(f"Test failed: {test_name} - {str(e)}")
            
            # Failure screenshot
            if self.settings.screenshot.on_failure:
                screenshot_path = await self._take_screenshot(test_name, "failure")
                result["screenshot"] = screenshot_path
        
        self.test_results.append(result)
        return result
    
    async def run_test_suite(self, test_functions: List[callable]) -> List[Dict[str, Any]]:
        """Run test suite"""
        self.logger.info(f"Starting test suite execution, total {len(test_functions)} tests")
        
        results = []
        for test_func in test_functions:
            result = await self.run_single_test(test_func)
            results.append(result)
        
        # Generate test report
        await self._generate_report()
        
        return results
    
    async def run_test_file(self, test_file_path: str) -> Dict[str, Any]:
        """Run specified test file"""
        import importlib.util
        
        try:
            # Dynamically import test file
            spec = importlib.util.spec_from_file_location("test_module", test_file_path)
            test_module = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(test_module)
            
            # Find all test functions
            test_functions = []
            for attr_name in dir(test_module):
                attr = getattr(test_module, attr_name)
                if (callable(attr) and 
                    attr_name.startswith('test_') and 
                    not attr_name.startswith('run_')):
                    test_functions.append((attr_name, attr))
            
            if not test_functions:
                self.logger.warning(f"No test functions found in {test_file_path}")
                return {"status": "no_tests", "results": []}
            
            # Run test functions
            results = []
            for test_name, test_func in test_functions:
                result = await self.run_single_test(test_func)
                result["name"] = test_name
                results.append(result)
            
            return {"status": "completed", "results": results}
            
        except Exception as e:
            self.logger.error(f"Failed to run test file: {str(e)}")
            return {"status": "error", "error": str(e), "results": []}
    
    async def _take_screenshot(self, test_name: str, status: str) -> str:
        """Take test screenshot"""
        try:
            # Ensure screenshot directory exists
            screenshot_dir = Path(self.settings.screenshot.directory)
            screenshot_dir.mkdir(parents=True, exist_ok=True)
            
            # Generate screenshot filename
            import time
            timestamp = time.strftime("%Y%m%d_%H%M%S")
            filename = f"{test_name}_{status}_{timestamp}.png"
            screenshot_path = screenshot_dir / filename
            
            # Here we need to access the current page object for screenshot
            # In actual usage, page object or browser object needs to be passed
            self.logger.info(f"Screenshot saved: {screenshot_path}")
            
            return str(screenshot_path)
        except Exception as e:
            self.logger.error(f"Screenshot failed: {str(e)}")
            return ""
    
    async def _generate_report(self):
        """Generate test report"""
        if not self.test_results:
            return
        
        try:
            # Ensure report directory exists
            os.makedirs(self.settings.reports_dir, exist_ok=True)
            
            # Generate simple HTML report
            report_path = os.path.join(self.settings.reports_dir, "test_report.html")
            
            with open(report_path, "w", encoding="utf-8") as f:
                f.write(self._generate_html_report())
            
            self.logger.info(f"Test report generated: {report_path}")
            
        except Exception as e:
            self.logger.error(f"Failed to generate test report: {str(e)}")
    
    def _generate_html_report(self) -> str:
        """Generate HTML format test report"""
        total_tests = len(self.test_results)
        passed_tests = len([r for r in self.test_results if r["status"] == "passed"])
        failed_tests = len([r for r in self.test_results if r["status"] == "failed"])
        
        html = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>Test Report</title>
            <meta charset="utf-8">
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .header {{ background-color: #f0f0f0; padding: 20px; border-radius: 5px; }}
                .summary {{ margin: 20px 0; }}
                .test-item {{ margin: 10px 0; padding: 10px; border: 1px solid #ddd; border-radius: 5px; }}
                .passed {{ background-color: #d4edda; border-color: #c3e6cb; }}
                .failed {{ background-color: #f8d7da; border-color: #f5c6cb; }}
                .screenshot {{ margin-top: 10px; }}
                .screenshot img {{ max-width: 300px; border: 1px solid #ccc; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>Behavior Framework Test Report</h1>
                <p>Generated at: {self._get_current_time()}</p>
            </div>
            
            <div class="summary">
                <h2>Test Summary</h2>
                <p>Total Tests: {total_tests}</p>
                <p>Passed: {passed_tests}</p>
                <p>Failed: {failed_tests}</p>
                <p>Success Rate: {(passed_tests/total_tests*100):.1f}%</p>
            </div>
            
            <div class="tests">
                <h2>Test Details</h2>
        """
        
        for result in self.test_results:
            status_class = "passed" if result["status"] == "passed" else "failed"
            duration = result["duration"]
            
            html += f"""
                <div class="test-item {status_class}">
                    <h3>{result['name']}</h3>
                    <p>Status: {result['status']}</p>
                    <p>Duration: {duration:.2f} seconds</p>
            """
            
            if result["error"]:
                html += f'<p>Error: {result["error"]}</p>'
            
            if result["screenshot"]:
                html += f"""
                    <div class="screenshot">
                        <p>Screenshot:</p>
                        <img src="{result['screenshot']}" alt="Test Screenshot">
                    </div>
                """
            
            html += "</div>"
        
        html += """
            </div>
        </body>
        </html>
        """
        
        return html
    
    def _get_current_time(self) -> str:
        """Get current time string"""
        import time
        return time.strftime("%Y-%m-%d %H:%M:%S")
