"""Core module - Provides basic functionality for browser, page and element"""
