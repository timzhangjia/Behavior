"""
Browser Management Module - Handles browser startup, configuration and lifecycle management
"""

from typing import Optional, Dict, Any
from playwright.async_api import async_playwright, Browser as PlaywrightBrowser, BrowserContext
from .page import Page
from ..config.settings import Settings
from ..utils.logger import Logger


class Browser:
    """Browser manager, wraps Playwright browser operations"""
    
    def __init__(self, settings: Optional[Settings] = None):
        self.settings = settings or Settings()
        self.playwright = None
        self.browser: Optional[PlaywrightBrowser] = None
        self.context: Optional[BrowserContext] = None
        self.logger = Logger()
        
    async def start(self, headless: Optional[bool] = None, browser_type: str = "chromium") -> None:
        """Start browser"""
        try:
            self.playwright = await async_playwright().start()
            
            # Select browser type
            if browser_type.lower() == "firefox":
                browser_launcher = self.playwright.firefox
            elif browser_type.lower() == "webkit":
                browser_launcher = self.playwright.webkit
            else:
                browser_launcher = self.playwright.chromium
            
            # Launch browser
            self.browser = await browser_launcher.launch(
                headless=headless if headless is not None else self.settings.headless,
                args=self.settings.browser_args
            )
            
            # Create browser context
            self.context = await self.browser.new_context(
                viewport={
                    "width": self.settings.viewport.width,
                    "height": self.settings.viewport.height
                },
                user_agent=self.settings.user_agent,
                locale=self.settings.locale,
                timezone_id=self.settings.timezone
            )
            
            self.logger.info(f"Browser started: {browser_type}")
            
        except Exception as e:
            self.logger.error(f"Failed to start browser: {str(e)}")
            raise
    
    async def new_page(self) -> Page:
        """Create new page"""
        if not self.context:
            raise RuntimeError("Browser not started, please call start() method first")
        
        playwright_page = await self.context.new_page()
        page = Page(playwright_page, self.settings)
        self.logger.info("New page created")
        return page
    
    async def close(self) -> None:
        """Close browser"""
        try:
            if self.context:
                await self.context.close()
            if self.browser:
                await self.browser.close()
            if self.playwright:
                await self.playwright.stop()
            self.logger.info("Browser closed")
        except Exception as e:
            self.logger.error(f"Error closing browser: {str(e)}")
    
    async def __aenter__(self):
        """Async context manager entry"""
        await self.start()
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        await self.close()
