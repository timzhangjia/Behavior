"""
UI Example Tests - Demonstrates how to use Behavior Framework for UI testing
"""

import asyncio
from behavior_framework import Browser, Page, Click, Type, Navigate, ShouldBeVisible, ShouldHaveText


async def test_google_search():
    """Test Google search functionality"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigate to Google
        navigate = Navigate(page, "https://www.google.com")
        await navigate.execute()
        
        # Wait for search box to be visible
        search_box = page.get_element("input[name='q']")
        should_be_visible = ShouldBeVisible(search_box)
        result = await should_be_visible.execute()
        print(f"Search box visibility check: {'✅ Passed' if result else '❌ Failed'}")
        
        # Type search keyword
        type_action = Type(search_box, "Behavior Framework")
        await type_action.execute()
        
        # Click search button
        search_button = page.get_element("input[name='btnK']")
        click_action = Click(search_button)
        await click_action.execute()
        
        # Verify search results
        results = page.get_element("#search")
        should_be_visible = ShouldBeVisible(results)
        result = await should_be_visible.execute()
        print(f"Search results verification: {'✅ Passed' if result else '❌ Failed'}")


async def test_form_interaction():
    """Test form interaction"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigate to test page
        navigate = Navigate(page, "https://httpbin.org/forms/post")
        await navigate.execute()
        
        # Fill form fields
        customer_name = page.get_element("input[name='custname']")
        type_action = Type(customer_name, "John Doe")
        await type_action.execute()
        
        email = page.get_element("input[name='email']")
        type_action = Type(email, "john@example.com")
        await type_action.execute()
        
        # Select radio button
        size_radio = page.get_element("input[name='size'][value='medium']")
        click_action = Click(size_radio)
        await click_action.execute()
        
        # Submit form
        submit_button = page.get_element("input[type='submit']")
        click_action = Click(submit_button)
        await click_action.execute()
        
        # Wait for page load to complete
        await page.wait_for_load_state("networkidle")
        print("✅ Form submission completed")


async def test_simple_navigation():
    """Simple navigation test"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigate to web page
        await page.goto("https://example.com")
        
        # Verify page title
        title = await page.title()
        print(f"Page title: {title}")
        
        # Verify page content
        heading = page.get_element("h1")
        should_have_text = ShouldHaveText(heading, "Example")
        result = await should_have_text.execute()
        print(f"Page content verification: {'✅ Passed' if result else '❌ Failed'}")


async def test_element_interactions():
    """Element interaction test"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigate to test page
        await page.goto("https://httpbin.org/html")
        
        # Test text retrieval
        heading = page.get_element("h1")
        text = await heading.text_content()
        print(f"Heading text: {text}")
        
        # Test attribute retrieval
        title_attr = await heading.get_attribute("class")
        print(f"Heading attribute: {title_attr}")
        
        # Test element counting
        paragraphs = page.get_element("p")
        count = await paragraphs.count()
        print(f"Paragraph count: {count}")


async def test_baidu_search():
    """Baidu search test"""
    browser = Browser()
    try:
        await browser.start()
        page = await browser.new_page()
        
        await page.goto("https://www.baidu.com")
        title = await page.title()
        print(f"Baidu page title: {title}")
        
        # Search box input
        search_box = page.get_element("#kw")
        type_action = Type(search_box, "Python automation")
        await type_action.execute()
        
        # Click search button
        search_button = page.get_element("#su")
        click_action = Click(search_button)
        await click_action.execute()
        
        # Wait for search results
        await page.wait_for_load_state("networkidle")
        print("✅ Baidu search completed")
        
    finally:
        await browser.close()


async def run_all_ui_tests():
    """Run all UI tests"""
    print("🚀 Starting Behavior Framework UI Test Suite")
    print("=" * 50)
    
    tests = [
        ("Simple Navigation Test", test_simple_navigation),
        ("Element Interaction Test", test_element_interactions),
        ("Baidu Search Test", test_baidu_search),
        ("Form Interaction Test", test_form_interaction),
        ("Google Search Test", test_google_search),
    ]
    
    for test_name, test_func in tests:
        print(f"\n🧪 Running test: {test_name}")
        try:
            await test_func()
            print(f"✅ {test_name} completed")
        except Exception as e:
            print(f"❌ {test_name} failed: {str(e)}")
        print("-" * 30)
    
    print("\n🎉 All UI tests completed!")


# Run tests if file is executed directly
if __name__ == "__main__":
    asyncio.run(run_all_ui_tests())
