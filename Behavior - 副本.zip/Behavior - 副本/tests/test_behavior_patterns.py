"""
行为模式测试用例 - 测试各种行为操作
"""

import asyncio
from behavior_framework import (
    Browser, Page, Click, Type, Wait, Navigate, Clear, Hover, 
    ShouldBeVisible, ShouldHaveText, ShouldBeEnabled, ShouldBeDisabled
)


async def test_click_behavior():
    """测试点击行为"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigated to测试页面
        navigate = Navigate(page, "https://httpbin.org/html")
        await navigate.execute()
        
        # 获取一个可点击的元素
        link = page.get_element("a")
        
        # 验证Element is visible
        should_be_visible = ShouldBeVisible(link)
        result = await should_be_visible.execute()
        print(f"链接可见性检查: {'✅ 通过' if result else '❌ 失败'}")
        
        # 执行点击
        click_action = Click(link)
        await click_action.execute()
        print("✅ 点击操作完成")


async def test_type_behavior():
    """测试输入行为"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigated to表单页面
        navigate = Navigate(page, "https://httpbin.org/forms/post")
        await navigate.execute()
        
        # 获取输入框
        input_field = page.get_element("input[name='custname']")
        
        # 测试普通输入
        type_action = Type(input_field, "测试用户")
        await type_action.execute()
        
        # 验证输入内容
        value = await input_field.get_attribute("value")
        print(f"输入验证: {'✅ 通过' if value == '测试用户' else '❌ 失败'}")
        
        # 测试清空
        clear_action = Clear(input_field)
        await clear_action.execute()
        
        # 验证清空结果
        value = await input_field.get_attribute("value")
        print(f"清空验证: {'✅ 通过' if value == '' else '❌ 失败'}")
        
        # 测试缓慢输入
        type_slowly = Type(input_field, "慢速输入", slow=True, delay=50)
        await type_slowly.execute()
        print("✅ 缓慢输入完成")


async def test_wait_behavior():
    """测试Wait behavior"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigated to页面
        navigate = Navigate(page, "https://httpbin.org/html")
        await navigate.execute()
        
        # 等待Element is visible
        heading = page.get_element("h1")
        wait_action = Wait(element=heading, state="visible")
        await wait_action.execute()
        print("✅ 元素等待完成")
        
        # 等待页面加载
        wait_page = Wait(page=page, state="domcontentloaded")
        await wait_page.execute()
        print("✅ 页面加载等待完成")


async def test_hover_behavior():
    """测试Hover behavior"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigated to页面
        navigate = Navigate(page, "https://httpbin.org/html")
        await navigate.execute()
        
        # 获取可悬停的元素
        element = page.get_element("h1")
        
        # 执行悬停
        hover_action = Hover(element)
        await hover_action.execute()
        print("✅ 悬停操作完成")


async def test_assertion_behaviors():
    """测试断言行为"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigated to页面
        navigate = Navigate(page, "https://httpbin.org/html")
        await navigate.execute()
        
        # Get element by selector
        heading = page.get_element("h1")
        
        # 测试可见性断言
        should_be_visible = ShouldBeVisible(heading)
        result = await should_be_visible.execute()
        print(f"可见性断言: {'✅ 通过' if result else '❌ 失败'}")
        
        # 测试文本断言
        should_have_text = ShouldHaveText(heading, "Herman Melville")
        result = await should_have_text.execute()
        print(f"文本断言: {'✅ 通过' if result else '❌ 失败'}")
        
        # 测试启用状态断言
        should_be_enabled = ShouldBeEnabled(heading)
        result = await should_be_enabled.execute()
        print(f"启用状态断言: {'✅ 通过' if result else '❌ 失败'}")


async def test_multiple_elements():
    """测试多元素操作"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigated to页面
        navigate = Navigate(page, "https://httpbin.org/html")
        await navigate.execute()
        
        # 获取多个段落
        paragraphs = page.get_element("p")
        count = await paragraphs.count()
        print(f"段落数量: {count}")
        
        # 操作第一个段落
        first_paragraph = paragraphs.first()
        text = await first_paragraph.text_content()
        print(f"第一个段落文本: {text[:50]}..." if text else "无文本")
        
        # 操作最后一个段落
        last_paragraph = paragraphs.last()
        text = await last_paragraph.text_content()
        print(f"最后一个段落文本: {text[:50]}..." if text else "无文本")


async def test_element_chaining():
    """测试元素链式操作"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigated to页面
        navigate = Navigate(page, "https://httpbin.org/html")
        await navigate.execute()
        
        # 链式操作：Get element by selector -> 验证可见 -> 获取文本
        heading = page.get_element("h1")
        
        # 等待可见
        wait_action = Wait(element=heading, state="visible")
        await wait_action.execute()
        
        # 获取文本
        text = await heading.text_content()
        print(f"标题文本: {text}")
        
        # 验证文本内容
        should_have_text = ShouldHaveText(heading, "Herman Melville")
        result = await should_have_text.execute()
        print(f"文本验证: {'✅ 通过' if result else '❌ 失败'}")


async def run_behavior_tests():
    """运行所有行为测试"""
    print("🎭 开始运行 Behavior Patterns 测试套件")
    print("=" * 50)
    
    tests = [
        ("点击行为测试", test_click_behavior),
        ("输入行为测试", test_type_behavior),
        ("Wait behavior测试", test_wait_behavior),
        ("Hover behavior测试", test_hover_behavior),
        ("断言行为测试", test_assertion_behaviors),
        ("多元素操作测试", test_multiple_elements),
        ("元素链式操作测试", test_element_chaining),
    ]
    
    for test_name, test_func in tests:
        print(f"\n🧪 运行测试: {test_name}")
        try:
            await test_func()
            print(f"✅ {test_name} 完成")
        except Exception as e:
            print(f"❌ {test_name} 失败: {str(e)}")
        print("-" * 30)
    
    print("\n🎉 所有行为模式测试运行完成!")


# 如果直接运行此文件
if __name__ == "__main__":
    asyncio.run(run_behavior_tests())
