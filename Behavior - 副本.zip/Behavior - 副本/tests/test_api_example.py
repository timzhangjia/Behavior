"""
API Example Tests - Demonstrates how to use Behavior Framework for API testing
"""

import asyncio
from behavior_framework import APIClient, Get, Post, Put, Delete, ShouldHaveStatus, ShouldHaveJson, ShouldBeSuccess


async def test_get_request():
    """Test GET request"""
    async with APIClient(base_url="https://jsonplaceholder.typicode.com") as client:
        # Make GET request
        get_action = Get(client, "posts/1")
        response = await get_action.execute()
        
        # Verify response status
        should_have_status = ShouldHaveStatus(response, 200)
        result = await should_have_status.execute()
        print(f"GET request status check: {'✅ Passed' if result else '❌ Failed'}")
        
        # Verify JSON response
        should_have_json = ShouldHaveJson(response, "id", 1)
        result = await should_have_json.execute()
        print(f"GET request JSON check: {'✅ Passed' if result else '❌ Failed'}")
        
        # Print response data
        json_data = response.json()
        print(f"Response data: {json_data.get('title', 'No title')}")


async def test_post_request():
    """Test POST request"""
    async with APIClient(base_url="https://jsonplaceholder.typicode.com") as client:
        # Prepare POST data
        post_data = {
            "title": "Test Post",
            "body": "This is a test post",
            "userId": 1
        }
        
        # Make POST request
        post_action = Post(client, "posts", json=post_data)
        response = await post_action.execute()
        
        # Verify response status
        should_be_success = ShouldBeSuccess(response)
        result = await should_be_success.execute()
        print(f"POST request status check: {'✅ Passed' if result else '❌ Failed'}")
        
        # Verify response contains created data
        should_have_json = ShouldHaveJson(response, "title", "Test Post")
        result = await should_have_json.execute()
        print(f"POST request data check: {'✅ Passed' if result else '❌ Failed'}")


async def test_put_request():
    """Test PUT request"""
    async with APIClient(base_url="https://jsonplaceholder.typicode.com") as client:
        # Prepare PUT data
        put_data = {
            "id": 1,
            "title": "Updated Post",
            "body": "This is an updated post",
            "userId": 1
        }
        
        # Make PUT request
        put_action = Put(client, "posts/1", json=put_data)
        response = await put_action.execute()
        
        # Verify response status
        should_have_status = ShouldHaveStatus(response, 200)
        result = await should_have_status.execute()
        print(f"PUT request status check: {'✅ Passed' if result else '❌ Failed'}")
        
        # Verify response contains updated data
        should_have_json = ShouldHaveJson(response, "title", "Updated Post")
        result = await should_have_json.execute()
        print(f"PUT request data check: {'✅ Passed' if result else '❌ Failed'}")


async def test_delete_request():
    """Test DELETE request"""
    async with APIClient(base_url="https://jsonplaceholder.typicode.com") as client:
        # Make DELETE request
        delete_action = Delete(client, "posts/1")
        response = await delete_action.execute()
        
        # Verify response status
        should_have_status = ShouldHaveStatus(response, 200)
        result = await should_have_status.execute()
        print(f"DELETE request status check: {'✅ Passed' if result else '❌ Failed'}")


async def test_httpbin_get():
    """Test GET request with httpbin"""
    async with APIClient(base_url="https://httpbin.org") as client:
        # Make GET request with query parameters
        get_action = Get(client, "get", params={"param1": "value1", "param2": "value2"})
        response = await get_action.execute()
        
        # Verify response status
        should_be_success = ShouldBeSuccess(response)
        result = await should_be_success.execute()
        print(f"HTTPBin GET request status: {'✅ Passed' if result else '❌ Failed'}")
        
        # Verify query parameters in response
        should_have_json = ShouldHaveJson(response, "args.param1", "value1")
        result = await should_have_json.execute()
        print(f"HTTPBin GET params check: {'✅ Passed' if result else '❌ Failed'}")


async def test_httpbin_post():
    """Test POST request with httpbin"""
    async with APIClient(base_url="https://httpbin.org") as client:
        # Prepare POST data
        post_data = {"message": "Hello from Behavior Framework"}
        
        # Make POST request
        post_action = Post(client, "post", json=post_data)
        response = await post_action.execute()
        
        # Verify response status
        should_be_success = ShouldBeSuccess(response)
        result = await should_be_success.execute()
        print(f"HTTPBin POST request status: {'✅ Passed' if result else '❌ Failed'}")
        
        # Verify request data in response
        should_have_json = ShouldHaveJson(response, "json.message", "Hello from Behavior Framework")
        result = await should_have_json.execute()
        print(f"HTTPBin POST data check: {'✅ Passed' if result else '❌ Failed'}")


async def test_authentication():
    """Test API with authentication"""
    async with APIClient(base_url="https://httpbin.org") as client:
        # Set authentication
        client.set_auth("bearer", "test-token-123")
        
        # Make authenticated request
        get_action = Get(client, "bearer")
        response = await get_action.execute()
        
        # Verify response status
        should_be_success = ShouldBeSuccess(response)
        result = await should_be_success.execute()
        print(f"Authentication request status: {'✅ Passed' if result else '❌ Failed'}")
        
        # Verify authentication in response
        should_have_json = ShouldHaveJson(response, "token", "test-token-123")
        result = await should_have_json.execute()
        print(f"Authentication token check: {'✅ Passed' if result else '❌ Failed'}")


async def run_all_api_tests():
    """Run all API tests"""
    print("🚀 Starting Behavior Framework API Test Suite")
    print("=" * 50)
    
    tests = [
        ("GET Request Test", test_get_request),
        ("POST Request Test", test_post_request),
        ("PUT Request Test", test_put_request),
        ("DELETE Request Test", test_delete_request),
        ("HTTPBin GET Test", test_httpbin_get),
        ("HTTPBin POST Test", test_httpbin_post),
        ("Authentication Test", test_authentication),
    ]
    
    for test_name, test_func in tests:
        print(f"\n🧪 Running test: {test_name}")
        try:
            await test_func()
            print(f"✅ {test_name} completed")
        except Exception as e:
            print(f"❌ {test_name} failed: {str(e)}")
        print("-" * 30)
    
    print("\n🎉 All API tests completed!")


# Run tests if file is executed directly
if __name__ == "__main__":
    asyncio.run(run_all_api_tests())
