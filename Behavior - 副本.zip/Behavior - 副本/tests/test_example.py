"""
示例测试用例 - 展示如何使用 Behavior Framework
"""

import asyncio
from behavior_framework import Browser, Page, Click, Type, Navigate, ShouldBeVisible, ShouldHaveText


async def test_google_search():
    """测试 Google 搜索功能"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigated to Google
        navigate = Navigate(page, "https://www.google.com")
        await navigate.execute()
        
        # 等待搜索框可见
        search_box = page.get_element("input[name='q']")
        should_be_visible = ShouldBeVisible(search_box)
        result = await should_be_visible.execute()
        print(f"搜索框可见性检查: {'✅ 通过' if result else '❌ 失败'}")
        
        # 输入搜索关键词
        type_action = Type(search_box, "Behavior Framework")
        await type_action.execute()
        
        # 点击搜索按钮
        search_button = page.get_element("input[name='btnK']")
        click_action = Click(search_button)
        await click_action.execute()
        
        # 验证搜索结果
        results = page.get_element("#search")
        should_be_visible = ShouldBeVisible(results)
        result = await should_be_visible.execute()
        print(f"搜索结果验证: {'✅ 通过' if result else '❌ 失败'}")


async def test_form_interaction():
    """测试表单交互"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigated to测试页面
        navigate = Navigate(page, "https://httpbin.org/forms/post")
        await navigate.execute()
        
        # 填写表单字段
        customer_name = page.get_element("input[name='custname']")
        type_action = Type(customer_name, "张三")
        await type_action.execute()
        
        email = page.get_element("input[name='email']")
        type_action = Type(email, "zhangsan@example.com")
        await type_action.execute()
        
        # 选择单选按钮
        size_radio = page.get_element("input[name='size'][value='medium']")
        click_action = Click(size_radio)
        await click_action.execute()
        
        # 提交表单
        submit_button = page.get_element("input[type='submit']")
        click_action = Click(submit_button)
        await click_action.execute()
        
        # 等待页面加载完成
        await page.wait_for_load_state("networkidle")
        print("✅ 表单提交完成")


async def test_simple_navigation():
    """简单的导航测试"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigated to网页
        await page.goto("https://example.com")
        
        # 验证页面标题
        title = await page.title()
        print(f"页面标题: {title}")
        
        # 验证页面内容
        heading = page.get_element("h1")
        should_have_text = ShouldHaveText(heading, "Example")
        result = await should_have_text.execute()
        print(f"页面内容验证: {'✅ 通过' if result else '❌ 失败'}")


async def test_element_interactions():
    """元素交互测试"""
    async with Browser() as browser:
        page = await browser.new_page()
        
        # Navigated to测试页面
        await page.goto("https://httpbin.org/html")
        
        # 测试文本获取
        heading = page.get_element("h1")
        text = await heading.text_content()
        print(f"标题文本: {text}")
        
        # 测试Attribute获取
        title_attr = await heading.get_attribute("class")
        print(f"标题Attribute: {title_attr}")
        
        # 测试元素计数
        paragraphs = page.get_element("p")
        count = await paragraphs.count()
        print(f"段落数量: {count}")


async def test_baidu_search():
    """百度搜索测试"""
    browser = Browser()
    try:
        await browser.start()
        page = await browser.new_page()
        
        await page.goto("https://www.baidu.com")
        title = await page.title()
        print(f"百度页面标题: {title}")
        
        # 搜索框输入
        search_box = page.get_element("#kw")
        type_action = Type(search_box, "Python自动化")
        await type_action.execute()
        
        # 点击搜索按钮
        search_button = page.get_element("#su")
        click_action = Click(search_button)
        await click_action.execute()
        
        # 等待搜索结果
        await page.wait_for_load_state("networkidle")
        print("✅ 百度搜索完成")
        
    finally:
        await browser.close()


async def run_all_tests():
    """运行所有测试"""
    print("🚀 开始运行 Behavior Framework 测试套件")
    print("=" * 50)
    
    tests = [
        ("简单导航测试", test_simple_navigation),
        ("元素交互测试", test_element_interactions),
        ("百度搜索测试", test_baidu_search),
        ("表单交互测试", test_form_interaction),
        ("Google搜索测试", test_google_search),
    ]
    
    for test_name, test_func in tests:
        print(f"\n🧪 运行测试: {test_name}")
        try:
            await test_func()
            print(f"✅ {test_name} 完成")
        except Exception as e:
            print(f"❌ {test_name} 失败: {str(e)}")
        print("-" * 30)
    
    print("\n🎉 所有测试运行完成!")


# 如果直接运行此文件
if __name__ == "__main__":
    asyncio.run(run_all_tests())
