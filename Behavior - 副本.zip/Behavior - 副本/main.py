"""
Behavior Framework Main Entry Point
"""

import asyncio
from behavior_framework import Browser, Page, Navigate, Click, Type, ShouldBeVisible, ShouldHaveText
from behavior_framework import APIClient, Get, ShouldHaveStatus


async def demo_ui_test():
    """Demo UI test - Shows basic framework usage"""
    print("🚀 Starting Behavior Framework UI Demo")
    
    # Create browser instance
    async with Browser() as browser:
        # Create new page
        page = await browser.new_page()
        
        print("📄 New page created")
        
        # Navigate to test page
        navigate = Navigate(page, "https://httpbin.org/html")
        await navigate.execute()
        
        print("🌐 Navigated to test page")
        
        # Wait for page title element to be visible
        title_element = page.get_element("h1")
        should_be_visible = ShouldBeVisible(title_element)
        is_visible = await should_be_visible.execute()
        
        if is_visible:
            print("✅ Page title element is visible")
            
            # Get and display title text
            title_text = await title_element.text_content()
            print(f"📝 Page title: {title_text}")
            
            # Verify title text
            should_have_text = ShouldHaveText(title_element, "Herman Melville")
            text_match = await should_have_text.execute()
            
            if text_match:
                print("✅ Title text verification passed")
            else:
                print("❌ Title text verification failed")
        else:
            print("❌ Page title element is not visible")
        
        # Take page screenshot
        await page.screenshot("demo_screenshot.png")
        print("📸 Page screenshot saved")
        
        print("🎉 UI demo test completed!")


async def demo_api_test():
    """Demo API test - Shows API testing capabilities"""
    print("🚀 Starting Behavior Framework API Demo")
    
    # Create API client instance
    async with APIClient(base_url="https://jsonplaceholder.typicode.com") as client:
        # Make GET request
        get_action = Get(client, "posts/1")
        response = await get_action.execute()
        
        print("📡 API request completed")
        
        # Verify response status
        should_have_status = ShouldHaveStatus(response, 200)
        status_check = await should_have_status.execute()
        
        if status_check:
            print("✅ API response status verification passed")
            
            # Get response data
            json_data = response.json()
            if json_data:
                print(f"📝 Response data: {json_data.get('title', 'No title')}")
            else:
                print("❌ No JSON data in response")
        else:
            print("❌ API response status verification failed")
        
        print("🎉 API demo test completed!")


async def run_example_tests():
    """Run example tests"""
    from tests.test_ui_example import run_all_ui_tests
    from tests.test_api_example import run_all_api_tests
    
    print("🧪 Running UI example tests")
    await run_all_ui_tests()
    print("✅ UI example tests completed")
    
    print("\n" + "=" * 50)
    
    print("🧪 Running API example tests")
    await run_all_api_tests()
    print("✅ API example tests completed")


def main():
    """Main function"""
    print("=" * 50)
    print("🎭 Behavior Framework - Python UI and API Automation Testing Framework")
    print("=" * 50)
    
    # Run demo tests
    asyncio.run(demo_ui_test())
    
    print("\n" + "=" * 50)
    
    asyncio.run(demo_api_test())
    
    print("\n" + "=" * 50)
    
    # Run example tests
    asyncio.run(run_example_tests())
    
    print("\n" + "=" * 50)
    print("✨ All tests completed! Framework is working properly")
    print("📚 Check tests/ directory for more test examples")
    print("🔧 Check behavior_framework/ directory for framework structure")
    print("🌐 UI testing: behavior_framework.ui")
    print("📡 API testing: behavior_framework.api")


if __name__ == "__main__":
    main()