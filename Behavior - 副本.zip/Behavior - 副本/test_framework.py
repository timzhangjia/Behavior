"""
Simple test script to verify Behavior Framework functionality
"""

import asyncio
from behavior_framework import Browser, APIClient, Get, ShouldHaveStatus


async def test_api():
    """Test API functionality"""
    print("Testing API functionality...")
    
    try:
        async with APIClient(base_url="https://jsonplaceholder.typicode.com") as client:
            get_action = Get(client, "posts/1")
            response = await get_action.execute()
            
            should_have_status = ShouldHaveStatus(response, 200)
            result = await should_have_status.execute()
            
            if result:
                print("API test: PASSED")
                json_data = response.json()
                print(f"Response data: {json_data.get('title', 'No title')}")
            else:
                print("API test: FAILED")
                
    except Exception as e:
        print(f"API test failed with error: {str(e)}")


async def test_ui():
    """Test UI functionality"""
    print("Testing UI functionality...")
    
    try:
        async with Browser() as browser:
            page = await browser.new_page()
            await page.goto("https://example.com")
            
            title = await page.title()
            print(f"Page title: {title}")
            
            if "Example" in title:
                print("UI test: PASSED")
            else:
                print("UI test: FAILED")
                
    except Exception as e:
        print(f"UI test failed with error: {str(e)}")


async def main():
    """Main test function"""
    print("Behavior Framework Test")
    print("=" * 30)
    
    await test_api()
    print()
    await test_ui()
    
    print("\nTest completed!")


if __name__ == "__main__":
    asyncio.run(main())
