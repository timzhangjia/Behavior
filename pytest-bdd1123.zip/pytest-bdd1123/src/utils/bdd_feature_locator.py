from __future__ import annotations
"""
BDD feature path locator utilities.

Given a test step module path, resolve the matching .feature file path under
features/test_case/<subdir>/.
"""
from pathlib import Path


def feature_path_for(module_file: str) -> str:
    module_path = Path(module_file).resolve()
    project_root = module_path.parents[3]
    features_root = project_root / "features"
    feature_subdir = module_path.parent.name
    search_dir = features_root / "test_case" / feature_subdir
    if not search_dir.exists():
        raise FileNotFoundError(f"Feature directory '{search_dir}' does not exist")

    token = module_path.stem
    if token.startswith("test_"):
        token = token[len("test_") :]
    if token.endswith("_steps"):
        token = token[: -len("_steps")]

    candidates = sorted(search_dir.glob(f"*{token}*.feature"))
    if not candidates:
        available = ", ".join(p.name for p in search_dir.glob("*.feature")) or "<none>"
        raise FileNotFoundError(
            f"No feature file matching token '{token}' under '{search_dir}'. Available: {available}"
        )

    return str(candidates[0].relative_to(features_root))

