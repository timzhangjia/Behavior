from abc import ABCMeta, abstractmethod
import json
import logging
from typing import Dict, List, Tuple, Any, Optional

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

class DatabaseService(metaclass=ABCMeta):
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.connection = None
    
    @abstractmethod
    def connect(self) -> Any:
        pass
    
    @abstractmethod
    def disconnect(self) -> None:
        pass
    
    @abstractmethod
    def execute_query(self, sql: str, params: Optional[Tuple] = None) -> List[Dict]:
        pass
    
    @abstractmethod
    def execute_update(self, sql: str, params: Optional[Tuple] = None) -> int:
        pass
    
    @abstractmethod
    def execute_procedure(self, proc_name: str, params: Optional[Tuple] = None) -> Any:
        pass
    
    def __enter__(self):
        self.connect()
        return self
    
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.disconnect()

class DatabaseException(Exception):
    pass

class SQLServerService(DatabaseService):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self._ensure_pyodbc()
    
    def _ensure_pyodbc(self):
        try:
            global pyodbc
            import pyodbc
        except ImportError:
            raise ImportError("pyodbc module not installed, please use 'pip install pyodbc'")
    
    def connect(self) -> Any:
        try:
            driver = self.config.get('driver', '{ODBC Driver 17 for SQL Server}')
            conn_str = (
                f"DRIVER={driver};"
                f"SERVER={self.config['server']};"
                f"DATABASE={self.config['database']};"
                f"UID={self.config['username']};"
                f"PWD={self.config['password']}"
            )
            self.connection = pyodbc.connect(conn_str)
            logger.info(f"Successfully connected to SQL Server database: {self.config['server']}/{self.config['database']}")
            return self.connection
        except Exception as e:
            logger.error(f"SQL Server connection failed: {str(e)}")
            raise DatabaseException(f"SQL Server connection failed: {str(e)}")
    
    def disconnect(self) -> None:
        if self.connection:
            try:
                self.connection.close()
                logger.info("SQL Server connection closed")
            except Exception as e:
                logger.error(f"Error closing SQL Server connection: {str(e)}")
            finally:
                self.connection = None
    
    def execute_query(self, sql: str, params: Optional[Tuple] = None) -> List[Dict]:
        if not self.connection:
            self.connect()
        try:
            cursor = self.connection.cursor()
            if params:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)
            columns = [column[0] for column in cursor.description]
            
            results = []
            for row in cursor.fetchall():
                results.append(dict(zip(columns, row)))
            cursor.close()
            logger.info(f"SQL query executed successfully, returned {len(results)} records")
            return results
        except Exception as e:
            logger.error(f"SQL query execution failed: {str(e)}")
            raise DatabaseException(f"SQL query execution failed: {str(e)}")
    
    def execute_update(self, sql: str, params: Optional[Tuple] = None) -> int:
        if not self.connection:
            self.connect()
        
        try:
            cursor = self.connection.cursor()
            if params:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)
            
            affected_rows = cursor.rowcount
            self.connection.commit()
            cursor.close()
            
            logger.info(f"SQL update executed successfully, affected {affected_rows} rows")
            return affected_rows
        except Exception as e:
            if self.connection:
                self.connection.rollback()
            logger.error(f"SQL update execution failed: {str(e)}")
            raise DatabaseException(f"SQL update execution failed: {str(e)}")
    
    def execute_procedure(self, proc_name: str, params: Optional[Tuple] = None) -> Any:
        if not self.connection:
            self.connect()
        try:
            cursor = self.connection.cursor()
            
            if params:
                result = cursor.execute(f"EXEC {proc_name}", params)
            else:
                result = cursor.execute(f"EXEC {proc_name}")
            
            results = []
            while result:
                columns = [column[0] for column in result.description]
                rows = []
                for row in result.fetchall():
                    rows.append(dict(zip(columns, row)))
            results.append(rows)
            result.nextset()
            
            cursor.close()
            logger.info(f"Stored procedure {proc_name} executed successfully")
            return results if results else None
        except Exception as e:
            logger.error(f"Stored procedure execution failed: {str(e)}")
            raise DatabaseException(f"Stored procedure execution failed: {str(e)}")

class OracleService(DatabaseService):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self._ensure_oracledb()
    
    def _ensure_oracledb(self):
        try:
            global oracledb
            import oracledb
        except ImportError:
            raise ImportError("oracledb module not installed, please use 'pip install oracledb'")
    
    def connect(self) -> Any:
        try:
            # Ensure oracledb is imported when actually used
            if 'oracledb' not in globals():
                self._ensure_oracledb()
            dsn = oracledb.makedsn(
                self.config['dsn'].split(':')[0],
                self.config['dsn'].split(':')[1].split('/')[0],
                service_name=self.config['dsn'].split('/')[1]
            )
            self.connection = oracledb.connect(
                user=self.config['username'],
                password=self.config['password'],
                dsn=dsn
            )
            logger.info(f"Successfully connected to Oracle database: {self.config['dsn']}")
            return self.connection
        except Exception as e:
            logger.error(f"Oracle connection failed: {str(e)}")
            raise DatabaseException(f"Oracle connection failed: {str(e)}")
    
    def disconnect(self) -> None:
        if self.connection:
            try:
                self.connection.close()
                logger.info("Oracle connection closed")
            except Exception as e:
                logger.error(f"Error closing Oracle connection: {str(e)}")
            finally:
                self.connection = None
    
    def execute_query(self, sql: str, params: Optional[Tuple] = None) -> List[Dict]:
        if not self.connection:
            self.connect()
        try:
            cursor = self.connection.cursor()
            if params:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)
            columns = [col[0] for col in cursor.description]
            
            results = []
            for row in cursor.fetchall():
                results.append(dict(zip(columns, row)))
            cursor.close()
            logger.info(f"Oracle query executed successfully, returned {len(results)} records")
            return results
        except Exception as e:
            logger.error(f"Oracle query execution failed: {str(e)}")
            raise DatabaseException(f"Oracle query execution failed: {str(e)}")
    
    def execute_update(self, sql: str, params: Optional[Tuple] = None) -> int:
        if not self.connection:
            self.connect()
        
        try:
            cursor = self.connection.cursor()
            if params:
                cursor.execute(sql, params)
            else:
                cursor.execute(sql)
            
            affected_rows = cursor.rowcount
            self.connection.commit()
            cursor.close()
            
            logger.info(f"Oracle update executed successfully, affected {affected_rows} rows")
            return affected_rows
        except Exception as e:
            if self.connection:
                self.connection.rollback()
            logger.error(f"Oracle update execution failed: {str(e)}")
            raise DatabaseException(f"Oracle update execution failed: {str(e)}")
    
    def execute_procedure(self, proc_name: str, params: Optional[Tuple] = None) -> Any:
        if not self.connection:
            self.connect()
        
        try:
            cursor = self.connection.cursor()
            
            if params:
                # oracledb is compatible with cx_Oracle for stored procedure parameters
                cursor.callproc(proc_name, params)
            else:
                cursor.callproc(proc_name)
            
            results = []
            if cursor.description:
                columns = [col[0] for col in cursor.description]
                for row in cursor.fetchall():
                    results.append(dict(zip(columns, row)))
            cursor.close()
            logger.info(f"Oracle stored procedure {proc_name} executed successfully")
            return results if results else None
        except Exception as e:
            logger.error(f"Oracle stored procedure execution failed: {str(e)}")
            raise DatabaseException(f"Oracle stored procedure execution failed: {str(e)}")

class MySQLService(DatabaseService):
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self._ensure_pymysql()
    
    def _ensure_pymysql(self):
        try:
            global pymysql
            import pymysql
        except ImportError:
            raise ImportError("pymysql module not installed, please use 'pip install pymysql'")
    
    def connect(self) -> Any:
        try:
            self.connection = pymysql.connect(
                host=self.config['host'],
                port=self.config.get('port', 3306),
                user=self.config['username'],
                password=self.config['password'],
                database=self.config['database'],
                charset=self.config.get('charset', 'utf8mb4'),
                cursorclass=pymysql.cursors.DictCursor
            )
            logger.info(f"Successfully connected to MySQL database: {self.config['host']}/{self.config['database']}")
            return self.connection
        except Exception as e:
            logger.error(f"MySQL connection failed: {str(e)}")
            raise DatabaseException(f"MySQL connection failed: {str(e)}")
    
    def disconnect(self) -> None:
        if self.connection:
            try:
                self.connection.close()
                logger.info("MySQL connection closed")
            except Exception as e:
                logger.error(f"Error closing MySQL connection: {str(e)}")
            finally:
                self.connection = None
    
    def execute_query(self, sql: str, params: Optional[Tuple] = None) -> List[Dict]:
        if not self.connection:
            self.connect()
        try:
            with self.connection.cursor() as cursor:
                if params:
                    cursor.execute(sql, params)
                else:
                    cursor.execute(sql)
                results = cursor.fetchall()
                logger.info(f"MySQL query executed successfully, returned {len(results)} records")
                return results
        except Exception as e:
            logger.error(f"MySQL query execution failed: {str(e)}")
            raise DatabaseException(f"MySQL query execution failed: {str(e)}")
    
    def execute_update(self, sql: str, params: Optional[Tuple] = None) -> int:
        if not self.connection:
            self.connect()
        try:
            with self.connection.cursor() as cursor:
                if params:
                    cursor.execute(sql, params)
                else:
                    cursor.execute(sql)
                affected_rows = cursor.rowcount
                self.connection.commit()
                
                logger.info(f"MySQL update executed successfully, affected {affected_rows} rows")
                return affected_rows
        except Exception as e:
            if self.connection:
                self.connection.rollback()
            logger.error(f"MySQL update execution failed: {str(e)}")
            raise DatabaseException(f"MySQL update execution failed: {str(e)}")
    
    def execute_procedure(self, proc_name: str, params: Optional[Tuple] = None) -> Any:
        if not self.connection:
            self.connect()
        
        try:
            with self.connection.cursor() as cursor:
                if params:
                    cursor.callproc(proc_name, params)
                else:
                    cursor.callproc(proc_name)
                
                results = []
                result = cursor.fetchall()
                if result:
                    results.append(result)
                
                while cursor.nextset():
                    result = cursor.fetchall()
                    if result:
                        results.append(result)
                
                logger.info(f"MySQL stored procedure {proc_name} executed successfully")
                return results if results else None
        except Exception as e:
            logger.error(f"MySQL stored procedure execution failed: {str(e)}")
            raise DatabaseException(f"MySQL stored procedure execution failed: {str(e)}")

class DatabaseServiceFactory:
    @staticmethod
    def create_service(db_type: str, config: Dict[str, Any]) -> DatabaseService:
        db_type = db_type.lower()
        
        try:
            if db_type == 'sqlserver':
                return SQLServerService(config)
            elif db_type == 'oracle':
                # Oracle驱动可能无法安装，提供更友好的错误信息
                try:
                    return OracleService(config)
                except ImportError as e:
                    raise ImportError(
                    f"Oracle database support requires oracledb module: {str(e)}\n"
                    f"Please run: pip install oracledb"
                )
            elif db_type == 'mysql':
                return MySQLService(config)
            else:
                raise ValueError(f"Unsupported database type: {db_type}, supported types are: sqlserver, oracle, mysql")
        except Exception as e:
            if db_type == 'oracle' and 'oracledb' in str(e):
                raise
            raise DatabaseException(f"Failed to create {db_type} database service: {str(e)}")

def get_db_service(db_type: str, config: Dict[str, Any]) -> DatabaseService:
    return DatabaseServiceFactory.create_service(db_type, config)