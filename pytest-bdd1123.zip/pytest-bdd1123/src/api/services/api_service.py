"""API服务层模块，包含所有API请求和响应处理的业务逻辑。"""

import json
from typing import Dict, Any, Optional


class APIService:
    """API服务类，封装所有API相关的业务逻辑。"""
    
    @staticmethod
    def resolve_url(path: str, scenario_context: Dict[str, Any], app_config: Any, config_map: Dict[str, str]) -> str:
        """解析URL路径，处理绝对路径和相对路径。"""
        if path.startswith('http://') or path.startswith('https://'):
            return path
        
        base_key = scenario_context.get('request_base_key')
        base_url = None
        
        # 优先使用app_config中的API基础URL（可能是mock服务）
        if isinstance(app_config, dict) and app_config.get('api_base_url'):
            base_url = app_config.get('api_base_url')
        
        # 其次使用配置映射中的URL
        if not base_url:
            base_url = config_map.get(base_key)
        
        # 最后再次尝试app_config
        if not base_url and isinstance(app_config, dict):
            base_url = app_config.get('api_base_url')
        
        if not base_url:
            raise ValueError(f"No base URL found for base_key '{base_key}'")
        
        # 构建完整URL
        full_url = f"{base_url.rstrip('/')}/{path.lstrip('/')}"
        return full_url
    
    @staticmethod
    def prepare_payload(payload: Dict[str, Any]) -> Dict[str, Any]:
        """准备请求载荷，确保包含必要的字段。"""
        data_payload = dict(payload)
        
        # 确保同时包含username和email字段，以兼容不同的API
        if 'username' in data_payload and 'email' not in data_payload:
            data_payload['email'] = data_payload.get('username')
        if 'email' in data_payload and 'username' not in data_payload:
            data_payload['username'] = data_payload.get('email')
        
        return data_payload
    
    @staticmethod
    def create_admin_payload(app_config: Any) -> Dict[str, Any]:
        """创建包含管理员凭证的请求载荷。"""
        admin = app_config.get('users', {}).get('admin', {})
        username = admin.get('username')
        password = admin.get('password')
        
        if not username or not password:
            raise ValueError("Admin credentials not configured in config")
        
        # 同时包含username和email，以兼容不同的API
        return {"username": username, "email": username, "password": password}
    
    @staticmethod
    def execute_get_request(api_request_context: Any, url: str):
        """执行GET请求。"""
        return api_request_context.get(url)
    
    @staticmethod
    def execute_post_request(api_request_context: Any, url: str, payload: Dict[str, Any]):
        """执行POST请求。"""
        return api_request_context.post(url, data=json.dumps(payload))


# 创建服务实例供外部使用
api_service = APIService()