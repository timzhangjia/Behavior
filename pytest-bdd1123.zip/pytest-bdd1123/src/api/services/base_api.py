from __future__ import annotations

import json
from typing import Any

import allure
from playwright.sync_api import APIRequestContext, APIResponse


class BaseAPI:
    """Wrapper around Playwright's APIRequestContext with Allure reporting."""

    def __init__(self, request: APIRequestContext, base_url: str):
        self.request = request
        self.base_url = base_url.rstrip("/")

    def _full_url(self, path: str) -> str:
        path = path if path.startswith("/") else f"/{path}"
        return f"{self.base_url}{path}"

    def _attach_request_details(self, method: str, url: str, **kwargs) -> None:
        """Attach API request details to Allure report."""
        request_info = {
            "method": method,
            "url": url,
            "headers": kwargs.get("headers", {}),
        }
        
        # Add request body if present
        if "data" in kwargs:
            try:
                request_info["body"] = json.loads(kwargs["data"]) if isinstance(kwargs["data"], str) else kwargs["data"]
            except (json.JSONDecodeError, TypeError):
                request_info["body"] = str(kwargs["data"])
        
        # Add query parameters if present
        if "params" in kwargs:
            request_info["params"] = kwargs["params"]
        
        allure.attach(
            json.dumps(request_info, indent=2, ensure_ascii=False),
            name=f"Request: {method} {url}",
            attachment_type=allure.attachment_type.JSON
        )

    def _attach_response_details(self, response: APIResponse) -> None:
        """Attach API response details to Allure report."""
        response_info = {
            "status": response.status,
            "status_text": response.status_text,
            "headers": dict(response.headers),
        }
        
        # Add response body
        try:
            response_body = response.json()
            response_info["body"] = response_body
        except Exception:
            try:
                response_info["body"] = response.text()
            except Exception:
                response_info["body"] = "<binary data>"
        
        allure.attach(
            json.dumps(response_info, indent=2, ensure_ascii=False),
            name=f"Response: {response.status} {response.status_text}",
            attachment_type=allure.attachment_type.JSON
        )

    def get(self, path: str, **kwargs) -> APIResponse:
        url = self._full_url(path)
        self._attach_request_details("GET", url, **kwargs)
        response = self.request.get(url, **kwargs)
        self._attach_response_details(response)
        return response

    def post(self, path: str, **kwargs) -> APIResponse:
        url = self._full_url(path)
        self._attach_request_details("POST", url, **kwargs)
        response = self.request.post(url, **kwargs)
        self._attach_response_details(response)
        return response

    def put(self, path: str, **kwargs) -> APIResponse:
        url = self._full_url(path)
        self._attach_request_details("PUT", url, **kwargs)
        response = self.request.put(url, **kwargs)
        self._attach_response_details(response)
        return response

    def delete(self, path: str, **kwargs) -> APIResponse:
        url = self._full_url(path)
        self._attach_request_details("DELETE", url, **kwargs)
        response = self.request.delete(url, **kwargs)
        self._attach_response_details(response)
        return response
