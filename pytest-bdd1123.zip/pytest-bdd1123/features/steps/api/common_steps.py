from __future__ import annotations

import json
import allure
import pytest
from pytest_bdd import given, when, then, parsers

from features.test_data.api import load_payload, get_base_path, CONFIG_MAP
from src.api.services.api_service import api_service


@given(parsers.parse('I set the API request path to "{path}"'))
def set_request_path(scenario_context, path: str):
    """Store the request path in the scenario context."""
    scenario_context['request_path'] = path


@given(parsers.parse('我将测试项目设置为 "{project_name}"'))
def set_current_project(scenario_context, project_name: str):
    """Save current project name into scenario context."""
    scenario_context['project_name'] = project_name


@given(parsers.parse('我基于路径引用 "{url_key}" 拼接动作 "{suffix}"'))
def set_path_ultimate(scenario_context, url_key: str, suffix: str):
    """Compose request_path by looking up `url_key` in YAML and appending `suffix`."""
    try:
        base_path = get_base_path(url_key)
    except Exception as e:
        pytest.fail(f"Config Error: {str(e)}")

    # If suffix is empty, use base_path as-is; otherwise join with a single '/'
    if not suffix:
        full_path = base_path
    else:
        full_path = f"{base_path.rstrip('/')}/{suffix.lstrip('/')}"

    scenario_context['request_path'] = full_path


@given(parsers.parse('I set the API request path from combined "{combined}" and base "{base_key}"'))
def set_path_from_combined_and_base(scenario_context, combined: str, base_key: str, app_config):
    """Compose request path when feature provides a combined token (e.g. "auth/login")

    Behavior:
      - `combined` can be like "auth/login" or "auth".
      - The first segment is used as the url_key to lookup a relative base path via `get_base_path(url_key)`.
      - Remaining segments are treated as suffix and appended.
      - `base_key` is looked up in test-data `CONFIG_MAP` (e.g. `bases.yaml`) for the base URL.
      - If `app_config` indicates a running mock (`use_mock_api` true and `api_base_url` present), the mock base
        will be preferred so local dev runs use the mock server.
    """
    parts = [p for p in combined.split('/') if p]
    if not parts:
        pytest.fail("Error: combined path is empty")

    url_key = parts[0]
    suffix = '/'.join(parts[1:]) if len(parts) > 1 else ''

    # Prefer an explicit mapping for the url_key (legacy support). If no mapping
    # exists, treat `combined` directly as the relative path (e.g. 'auth/login').
    try:
        rel_base = get_base_path(url_key)
        if suffix:
            rel_path = f"{rel_base.rstrip('/')}/{suffix.lstrip('/')}"
        else:
            rel_path = rel_base
    except KeyError:
        # No mapping for url_key; use the whole combined string as relative path.
        rel_path = combined.lstrip('/')

    # Determine base URL priority:
    # 1) Prefer the test-data mapping for the requested base_key (CONFIG_MAP)
    # 2) If a mock server is enabled (`use_mock_api` true) and provides `api_base_url`, override with mock
    # 3) Fallback to any `app_config['api_base_url']` if still not found
    base_url = CONFIG_MAP.get(base_key)

    try:
        if isinstance(app_config, dict) and app_config.get('use_mock_api') and app_config.get('api_base_url'):
            # override to mock base so local dev uses mock server
            base_url = app_config.get('api_base_url')
    except Exception:
        pass

    if not base_url and isinstance(app_config, dict):
        base_url = app_config.get('api_base_url')

    if not base_url:
        pytest.fail(f"No base URL found for base_key '{base_key}', and no app_config api_base_url present.")

    # Store the relative path and the base key; resolution into a full URL
    # happens when the request is sent so mock/app_config override can apply.
    scenario_context['request_path'] = rel_path
    scenario_context['request_base_key'] = base_key


@given(parsers.parse('我基于路径引用 "{url_key}"'))
def set_path_from_key(scenario_context, url_key: str):
    """Set request_path directly from a configured base path key (no suffix)."""
    try:
        base_path = get_base_path(url_key)
        scenario_context['request_path'] = base_path
    except KeyError:
        # If no mapping exists, treat the provided key as a relative path
        # (backward-compatible behavior), e.g. 'health' -> '/health' or 'health'.
        scenario_context['request_path'] = url_key


# English aliases for the Chinese Given steps


@given(parsers.parse('I set the test project to "{project_name}"'))
def set_current_project_en(scenario_context, project_name: str):
    return set_current_project(scenario_context, project_name)


@given(parsers.parse('I compose the request path from "{url_key}" with suffix "{suffix}"'))
def set_path_ultimate_en(scenario_context, url_key: str, suffix: str):
    return set_path_ultimate(scenario_context, url_key, suffix)


@given(parsers.parse('I compose the request path from "{url_key}"'))
def set_path_from_key_en(scenario_context, url_key: str):
    return set_path_from_key(scenario_context, url_key)


@given(parsers.parse('I load the payload named "{payload_name}"'))
def load_request_payload(scenario_context, payload_name: str):
    """Load JSON payload via `load_payload` and save it to scenario context."""
    payload_data = load_payload(payload_name)
    scenario_context['payload'] = payload_data
    return payload_data


@given(parsers.parse('I set payload field "{key}" to "{value}"'))
def set_payload_field(scenario_context, key: str, value: str):
    """修改已加载的payload中的字段值。

    - `key` 支持使用点分隔的嵌套键路径，例如 "user.email"。
    - `value` 会尝试转换为适当的类型，否则保持为字符串。
    """
    # 从上下文获取payload
    payload = scenario_context.get('payload')

    # 处理嵌套键路径
    keys = key.split('.')
    current = payload
    
    # 遍历除最后一个键外的所有键，确保中间路径存在
    for k in keys[:-1]:
        if k not in current or not isinstance(current[k], dict):
            current[k] = {}
        current = current[k]
    
    # 直接解析并设置最终值
    parsed_value = json.loads(value.strip())
    current[keys[-1]] = parsed_value
    
    # 返回修改后的payload（字典是可变对象，修改已生效）
    return payload


@when('I send a GET request')
def send_get_request(api_request_context, scenario_context, app_config):
    """Send a GET request and save the response."""
    path = scenario_context.get('request_path')
    if path is None:
        pytest.fail("Error: request path not set")

    try:
        # 使用服务层解析URL并执行请求
        url = api_service.resolve_url(path, scenario_context, app_config, CONFIG_MAP)
        response = api_service.execute_get_request(api_request_context, url)
        scenario_context['response'] = response
        return response
    except ValueError as e:
        pytest.fail(str(e))


@when('I send a POST request')
def send_post_request(api_request_context, scenario_context, app_config):
    """Send a POST request using the payload stored in context."""
    path = scenario_context.get('request_path')
    payload = scenario_context.get('payload')

    if path is None:
        pytest.fail("Error: POST request path not set")
    if payload is None:
        pytest.fail("Error: POST payload not loaded")

    try:
        # 使用服务层准备载荷、解析URL并执行请求
        prepared_payload = api_service.prepare_payload(payload)
        url = api_service.resolve_url(path, scenario_context, app_config, CONFIG_MAP)
        response = api_service.execute_post_request(api_request_context, url, prepared_payload)
        scenario_context['response'] = response
        return response
    except ValueError as e:
        pytest.fail(str(e))


@when('I send a POST request with admin credentials')
def send_post_with_admin(api_request_context, scenario_context, app_config):
    """Send a POST request using admin credentials from `app_config`."""
    path = scenario_context.get('request_path')
    if path is None:
        pytest.fail("Error: POST request path not set")

    try:
        # 使用服务层创建管理员载荷、解析URL并执行请求
        payload = api_service.create_admin_payload(app_config)
        url = api_service.resolve_url(path, scenario_context, app_config, CONFIG_MAP)
        response = api_service.execute_post_request(api_request_context, url, payload)
        scenario_context['response'] = response
        return response
    except ValueError as e:
        pytest.fail(str(e))


@then(parsers.parse('the response status code should be {status_code:d}'))
def check_status_code(scenario_context, status_code: int):
    response = scenario_context.get('response')
    assert response is not None, "Response object was not saved"
    if response.status != status_code:
        # Try to get a useful body representation for debugging
        try:
            body_text = response.text()
        except Exception:
            try:
                body_text = response.json()
            except Exception:
                body_text = "<unable to read body>"

        print(f"[DEBUG] Response status={response.status}, expected={status_code}")
        print(f"[DEBUG] Response body: {body_text}")
        pytest.fail(f"Expected status code {status_code}, got {response.status}. Body: {body_text}")


@then(parsers.parse('the response JSON "{key}" should be {value:d}'))
def check_response_body_integer(scenario_context, key: str, value: int):
    response = scenario_context.get('response')
    assert response is not None, "Response object was not saved"
    response_json = response.json()
    assert key in response_json, f"Key '{key}' not found in response JSON"
    actual_value = response_json.get(key)
    assert actual_value == value, f"Expected '{key}' to be {value}, got {actual_value}"


@then(parsers.parse('the response "{resp_key}" should match payload "{payload_key}"'))
def check_response_matches_payload(scenario_context, resp_key: str, payload_key: str):
    response = scenario_context.get('response')
    payload = scenario_context.get('payload')
    assert response is not None, "Response object was not saved"
    assert payload is not None, "Payload was not saved"
    response_json = response.json()
    assert resp_key in response_json, f"Key '{resp_key}' not found in response JSON"
    assert payload_key in payload, f"Key '{payload_key}' not found in payload"
    actual_value = response_json.get(resp_key)
    expected_value = payload.get(payload_key)
    assert actual_value == expected_value, (
        f"Expected response['{resp_key}'] == payload['{payload_key}'] ({expected_value}), got {actual_value}"
    )


@then(parsers.parse('the response JSON should contain "{key}"'))
def assert_key_present(scenario_context, key: str):
    response = scenario_context.get('response')
    assert response is not None, "Response object was not saved"
    response_json = response.json()
    assert key in response_json, f"Response JSON missing key: '{key}'"
