from pytest_bdd import given, when, then
from config.settings import get_settings
from api.services.db_service import DatabaseServiceFactory


@given('a database connection is established using configuration from "<environment>" environment')
def establish_database_connection(environment, request):
    """Establish database connection using configuration from specified environment."""
    # Load database configuration from settings
    settings = get_settings(environment)
    
    if not settings.database:
        raise ValueError(f"Database configuration not found in {environment} environment")
    
    # Create database service using configuration
    db_config = settings.database
    # Convert DatabaseConfig object to dict format expected by create_service
    config_dict = {
        'host': db_config.host,
        'port': db_config.port,
        'database': db_config.database,
        'username': db_config.username,
        'password': db_config.password,
        'charset': db_config.charset,
        'connect_timeout': db_config.connect_timeout
    }
    db_service = DatabaseServiceFactory.create_service(
        db_type=db_config.db_type,
        config=config_dict
    )
    
    # Connect to database
    db_service.connect()
    
    # Store db_service in pytest context for later use
    request.cls.db_service = db_service
    
    # Add teardown to disconnect after test
    def disconnect_db():
        db_service.disconnect()
    request.addfinalizer(disconnect_db)


@when('I execute SQL query "<sql_query>"')
def execute_sql_query(sql_query, request):
    """Execute SQL query using the established database connection."""
    # Get database service from pytest context
    db_service = request.cls.db_service
    
    # Execute query
    results = db_service.execute_query(sql_query)
    
    # Store results in pytest context for later validation
    request.cls.query_results = results
    
    # Also store column names if results are available
    if results:
        request.cls.result_columns = list(results[0].keys()) if isinstance(results[0], dict) else []


@then('I should get query results with more than 0 rows')
def verify_query_results_count(request):
    """Verify that the query returned results."""
    # Get query results from pytest context
    results = request.cls.query_results
    
    # Assert that results is not None and contains at least one row
    assert results is not None, "Query returned None results"
    assert len(results) > 0, "Query returned 0 rows"


@then('I should be able to access database columns like "<columns>"')
def verify_query_result_columns(columns, request):
    """Verify that specific columns are available in the query results."""
    # Get result columns from pytest context
    result_columns = getattr(request.cls, 'result_columns', [])
    
    # Split the comma-separated column names
    expected_columns = [col.strip() for col in columns.split(',')]
    
    # Check each expected column
    for column in expected_columns:
        assert column in result_columns, f"Column '{column}' not found in query results"