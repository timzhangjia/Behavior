from __future__ import annotations

import allure
from pytest_bdd import given, scenarios, then, when
from playwright.sync_api import Page, expect

from src.ui.templates import load_template
from src.utils.bdd_feature_locator import feature_path_for

scenarios(feature_path_for(__file__))

_TEMPLATE_NAME = "search_sample.html"


@given("the user opens the sample search page", target_fixture="search_page")
def open_sample_search(page: Page) -> Page:
    page.set_content(load_template(_TEMPLATE_NAME))
    page.take_screenshot("Given the user opens the sample search page")
    return page


@when('the user searches for "Playwright"')
def search_keyword(search_page: Page):
    search_page.fill("#query", "Playwright")
    search_page.take_screenshot('When the user searches for "Playwright" - before click')
    search_page.click("#search-button")


@then('the search results contain "Playwright"')
def verify_results(search_page: Page):
    expect(search_page.locator(".result__title")).to_be_visible()
    search_page.take_screenshot('Then the search results contain "Playwright"')
    expect(search_page.locator("#links")).to_contain_text("Playwright", ignore_case=True)
