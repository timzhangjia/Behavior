from src.api.services.db_service import DatabaseServiceFactory, DatabaseException
import logging

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# 测试脚本，用于验证db_service.py中的oracledb导入是否正确
def test_db_service_imports():
    logger.info("开始测试db_service导入...")
    
    # 测试工厂类是否能正确加载
    logger.info("测试DatabaseServiceFactory加载成功")
    
    # 尝试创建不同类型的服务（不会实际连接）
    try:
        # 测试SQL Server服务创建（不会实际连接）
        sqlserver_config = {
            'server': 'test_server',
            'database': 'test_db',
            'username': 'test_user',
            'password': 'test_pwd'
        }
        logger.info("SQL Server服务配置创建成功")
        
        # 测试MySQL服务创建（不会实际连接）
        mysql_config = {
            'host': 'test_host',
            'database': 'test_db',
            'username': 'test_user',
            'password': 'test_pwd'
        }
        logger.info("MySQL服务配置创建成功")
        
        # 测试Oracle服务创建（这里只是验证导入，不会实际连接）
        oracle_config = {
            'dsn': 'test_host:1521/test_service',
            'username': 'test_user',
            'password': 'test_pwd'
        }
        logger.info("Oracle服务配置创建成功")
        
        logger.info("所有数据库服务配置测试通过，代码结构正确！")
        return True
    except Exception as e:
        logger.error(f"测试过程中出错: {str(e)}")
        return False

if __name__ == "__main__":
    test_db_service_imports()