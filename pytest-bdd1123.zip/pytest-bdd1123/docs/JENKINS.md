# Jenkins 集成指南

> 5 分钟快速配置 Jenkins 运行测试并发送报告

---

## 前置要求

### Jenkins 插件
- ✅ **Allure Jenkins Plugin** - 报告展示
- ✅ **Email Extension Plugin** - 邮件发送
- ✅ **Pipeline Plugin** - Pipeline 支持
- ✅ **Git Plugin** - 代码拉取

### Jenkins 配置
- ✅ 配置 SMTP 服务器
- ✅ 安装 Python 3.8+
- ✅ 安装 Allure CLI（或使用项目自带的 `tools/allure/`）

---

## 方式一：Pipeline（推荐）⭐

### 1. 创建 Pipeline Job
1. Jenkins → **New Item**
2. 输入名称：`Pytest-BDD-Tests`
3. 选择：**Pipeline**
4. 点击：**OK**

### 2. 配置 Pipeline
**Pipeline 部分：**
- **Definition**: `Pipeline script from SCM`
- **SCM**: `Git`
- **Repository URL**: `你的仓库地址`
- **Script Path**: `pytest-bdd/Jenkinsfile`

### 3. 构建
点击 **Build with Parameters**，选择：
- **ENVIRONMENT**: `sit`, `uat`, `prod`
- **TEST_MARKER**: `all`, `api`, `ui`, `smoke`
- **EMAIL_RECIPIENTS**: `team@example.com`

点击 **Build** 开始运行！

---

## 方式二：Freestyle Project

### 1. 创建 Freestyle Job
1. Jenkins → **New Item**
2. 输入名称：`Pytest-BDD-Tests`
3. 选择：**Freestyle project**
4. 点击：**OK**

### 2. 添加构建参数
勾选 **This project is parameterized**，添加：

**参数 1：ENVIRONMENT**
- 类型：`Choice Parameter`
- Choices:
  ```
  sit
  uat
  prod
  ```

**参数 2：TEST_MARKER**
- 类型：`Choice Parameter`
- Choices:
  ```
  all
  api
  ui
  smoke
  ```

**参数 3：EMAIL_RECIPIENTS**
- 类型：`String Parameter`
- Default: `team@example.com`

### 3. 配置 Git
**Source Code Management** → **Git**
- Repository URL: `你的仓库地址`
- Credentials: 配置凭据（如需要）

### 4. 添加构建步骤
**Windows:**
添加 **Execute Windows batch command**：
```batch
cd pytest-bdd
python -m pip install -r requirements.txt

if "%TEST_MARKER%"=="all" (
    python run.py --ci --env %ENVIRONMENT%
) else (
    python run.py --ci --env %ENVIRONMENT% -m %TEST_MARKER%
)
```

**Linux/Mac:**
添加 **Execute shell**：
```bash
cd pytest-bdd
python3 -m pip install -r requirements.txt

if [ "$TEST_MARKER" = "all" ]; then
    python3 run.py --ci --env $ENVIRONMENT
else
    python3 run.py --ci --env $ENVIRONMENT -m "$TEST_MARKER"
fi
```

### 5. 配置 Post-build Actions

#### a) Allure Report
添加 **Allure Report**：
- **Path**: `pytest-bdd/reports/temp/allure-results`

#### b) Email Notification
添加 **Editable Email Notification**：

**基本配置：**
- **Project Recipient List**: `$EMAIL_RECIPIENTS`
- **Content Type**: `HTML (text/html)`
- **Default Subject**:
  ```
  测试报告 - $BUILD_STATUS - $ENVIRONMENT - Build #$BUILD_NUMBER
  ```

**Default Content**:
```html
<html>
<body>
<h2>测试执行完成</h2>
<p><strong>环境：</strong> $ENVIRONMENT</p>
<p><strong>测试标记：</strong> $TEST_MARKER</p>
<p><strong>构建状态：</strong> $BUILD_STATUS</p>
<p><strong>构建编号：</strong> #$BUILD_NUMBER</p>
<hr>
<p>详细报告请查看附件或 Jenkins 中的 Allure Report。</p>
<p><a href="$BUILD_URL">点击查看构建详情</a></p>
</body>
</html>
```

**Attachments**:
```
pytest-bdd/reports/history/*/shareable-report.html
```

**Advanced Settings**:
- 点击 **Advanced Settings**
- 添加 Trigger: **Always**
- 添加 Trigger: **Failure - Any**

### 6. 保存并构建
点击 **Save** → **Build with Parameters** → 选择参数 → **Build**

---

## 邮件配置（SMTP）

### Gmail 配置示例
1. **Jenkins** → **Manage Jenkins** → **Configure System**
2. 找到 **Extended E-mail Notification**
3. 配置：
```
SMTP server: smtp.gmail.com
SMTP Port: 587
```
4. 点击 **Advanced**：
```
☑️ Use SMTP Authentication
Username: your-email@gmail.com
Password: [应用专用密码]
☑️ Use TLS
Default Content Type: HTML (text/html)
```
5. 点击 **Test Configuration** 验证

### 获取 Gmail 应用专用密码
1. Google 账户 → **安全性**
2. 启用 **两步验证**
3. **应用专用密码** → 生成新密码
4. 在 Jenkins 中使用生成的密码

---

## 查看报告

### 方式 1：邮件中查看
收件人会收到邮件，附件中包含 `shareable-report.html`：
- **直接双击打开**（无需服务器）
- 包含所有测试结果、日志、截图
- 可离线查看

### 方式 2：Jenkins 中查看
1. 点击构建编号
2. 点击左侧 **Allure Report**
3. 在线查看交互式报告

### 方式 3：下载查看
1. 点击构建编号
2. 点击 **Workspace**
3. 下载 `reports/history/[时间戳]/shareable-report.html`
4. 双击打开

---

## 定时构建

### 配置定时任务
**Build Triggers** → **Build periodically**
```
# 每天凌晨 2 点运行
H 2 * * *

# 每周一到周五早上 8 点运行
H 8 * * 1-5

# 每 4 小时运行一次
H */4 * * *
```

### Cron 语法
```
分钟 小时 日 月 星期

示例：
H 2 * * *        # 每天 2 点
H 8 * * 1-5      # 工作日 8 点
H */4 * * *      # 每 4 小时
H H(0-7) * * *   # 每天 0-7 点之间随机
```

---

## 常见问题

### Q1: 邮件未发送？
**检查清单：**
```bash
# 1. 验证 SMTP 配置
Jenkins → Configure System → Extended E-mail Notification
→ Test Configuration

# 2. 检查邮件地址格式
team@example.com,user1@example.com  # 逗号分隔

# 3. 查看 Jenkins 日志
Jenkins → Manage Jenkins → System Log
```

### Q2: 测试未运行？
**检查清单：**
```bash
# 1. 验证 Python 安装
python --version  # 应该是 3.8+

# 2. 检查依赖
pip list | grep pytest

# 3. 本地测试
cd pytest-bdd
python run.py --ci -m api
```

### Q3: Allure 报告为空？
**检查清单：**
```bash
# 1. 验证 Allure 插件
Manage Jenkins → Manage Plugins → Installed
→ 搜索 "Allure"

# 2. 检查结果目录
ls pytest-bdd/reports/temp/allure-results/

# 3. 验证路径配置
Post-build Actions → Allure Report
→ Path: pytest-bdd/reports/temp/allure-results
```

### Q4: 附件太大无法发送？
**解决方案：**
```bash
# 方案 1：使用 Jenkins 归档
Post-build Actions → Archive the artifacts
→ Files to archive: pytest-bdd/reports/history/**/*

# 方案 2：邮件中提供下载链接
邮件内容：
<a href="${BUILD_URL}artifact/pytest-bdd/reports/history/">
  点击下载报告
</a>

# 方案 3：上传到文件服务器
添加构建步骤上传到 S3/OSS/网盘
```

### Q5: 如何并行运行测试？
**方法：**
```bash
# 安装 pytest-xdist
pip install pytest-xdist

# 修改构建命令
python run.py --ci -m api -- -n auto

# 或指定进程数
python run.py --ci -m api -- -n 4
```

---

## 最佳实践

### 1. 分环境创建 Job
```
Pytest-BDD-SIT   → 运行 SIT 测试
Pytest-BDD-UAT   → 运行 UAT 测试
Pytest-BDD-PROD  → 运行 PROD 测试（仅冒烟）
```

### 2. 配置不同的邮件列表
```
SIT:  dev-team@example.com
UAT:  qa-team@example.com
PROD: all-team@example.com
```

### 3. 保留构建历史
```
Discard Old Builds:
☑️ Days to keep builds: 30
☑️ Max # of builds to keep: 50
```

### 4. 失败时发送通知
```
Post-build Actions → Editable Email Notification
→ Advanced Settings
→ Triggers:
  ☑️ Failure - Any
  ☑️ Unstable - Any
```

### 5. 使用 Pipeline 多阶段
```groovy
pipeline {
    stages {
        stage('Smoke Tests') {
            steps {
                sh 'python run.py --ci -m smoke'
            }
        }
        stage('API Tests') {
            when { expression { params.RUN_FULL_SUITE } }
            steps {
                sh 'python run.py --ci -m api'
            }
        }
        stage('UI Tests') {
            when { expression { params.RUN_FULL_SUITE } }
            steps {
                sh 'python run.py --ci -m ui'
            }
        }
    }
}
```

---

## 命令速查
```bash
# 基本命令
python run.py --ci --env sit                    # SIT 所有测试
python run.py --ci --env uat -m api             # UAT API 测试
python run.py --ci --env prod -m smoke          # PROD 冒烟测试

# 高级选项
python run.py --ci -m api -v                    # 详细输出
python run.py --ci -m api --tb=short            # 简短错误信息
python run.py --ci -m api -k "login"            # 关键字过滤
python run.py --ci -m api -- -n auto            # 并行运行
```

---

## 相关资源
- **[README.md](README.md)** - 框架使用文档
- **[Jenkinsfile](Jenkinsfile)** - Pipeline 示例
- **[run.py](run.py)** - 主运行脚本

---

## 支持
遇到问题？
1. 查看 Jenkins 控制台输出
2. 检查 `pytest-bdd/reports/temp/allure-results/` 日志
3. 本地测试命令：`python run.py --ci -m api`
4. 联系 DevOps 团队

---

**Jenkins 集成完成！[object Object]

开始构建：**Build with Parameters** → 选择参数 → **Build**
