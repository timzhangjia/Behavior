# Pytest-BDD Playwright Framework

> **🚀 第一次使用？** 查看 **[快速开始.md](快速开始.md)** - 只需 3 步！

## 目录
- [快速开始](#快速开始)
- [报告管理](#报告管理)
- [Jenkins 集成](#jenkins-集成)
- [项目结构](#项目结构)
- [常用命令速查](#常用命令速查)
- [扩展框架](#扩展框架)
- [故障排查](#故障排查)
- [Git 操作指南](#git-操作指南)
- [常见问题](#常见问题)

---

## 快速开始

### 1. 安装依赖
   ```bash
   pip install -r requirements.txt
   playwright install
   ```

### 2. 运行测试
```bash
# 运行所有测试（默认 SIT 环境）
python run.py

# 运行特定类型的测试
python run.py -m api                    # API 测试
python run.py -m ui                     # UI 测试
python run.py -m smoke                  # 冒烟测试

# 切换环境
python run.py -m api --env uat          # UAT 环境
python run.py -m api --env prod         # 生产环境

# 组合条件
python run.py -m "api and smoke"        # API + 冒烟测试
python run.py -k "login"                # 包含 login 关键字的测试

# 不打开浏览器
python run.py -m api --no-open

# 不保存历史报告
python run.py -m api --no-save
```

### 3. 查看报告
测试完成后会自动生成并打开报告。报告保存在：
- **临时报告**：`reports/temp/shareable-report.html`（每次运行前清理）
- **历史报告**：`reports/history/[时间戳]_[环境]_[标记]/shareable-report.html`

**直接双击 HTML 文件即可查看**，无需启动服务器！

---

## 报告管理
**report.html** 是一个完全自包含的单文件报告：
- ✅ **包含所有内容**：测试结果、日志、截图、样式
- ✅ **无需服务器**：直接双击打开
- ✅ **可离线查看**：所有数据已嵌入
- ✅ **易于分享**：通过邮件或网盘分享
- ✅ **文件大小**：通常 2-3 MB

## Jenkins 集成

详细配置请查看 **[JENKINS.md](JENKINS.md)**

### 快速命令
```bash
# CI/CD 模式（非交互式）
python run.py --ci --env sit -m api

# 这会自动：
# ✅ 运行测试
# ✅ 生成 Allure 报告
# ✅ 生成单文件 HTML 报告
# ✅ 保存到历史记录
# ✅ 返回正确的退出码
```

### Jenkins 构建参数
- **ENVIRONMENT**: `sit`, `uat`, `prod`
- **TEST_MARKER**: `all`, `api`, `ui`, `smoke`
- **EMAIL_RECIPIENTS**: 邮件接收人（逗号分隔）

---

## 项目结构
```
pytest-bdd/
├── config/                    # 环境配置
│   ├── env_sit.yaml          # SIT 配置
│   ├── env_uat.yaml          # UAT 配置
│   └── settings.py           # 配置加载器
├── features/
│   ├── test_case/            # Feature 文件（Gherkin）
│   │   ├── api/             # API 测试场景
│   │   └── ui/              # UI 测试场景
│   ├── steps/               # 步骤定义
│   │   ├── api/            # API 步骤实现
│   │   ├── ui/             # UI 步骤实现
│   │   └── common/         # 公共步骤
│   └── test_data/          # 测试数据
├── src/
│   ├── api/                 # API 服务层
│   └── ui/                  # UI 页面对象
├── utils/                   # 工具函数
├── tools/allure/           # Allure CLI
├── reports/                # 测试报告（gitignored）
├── run.py                  # 主运行脚本 ⭐
├── package_report.py       # 报告打包脚本
├── Jenkinsfile            # Jenkins Pipeline
├── pytest.ini             # Pytest 配置
└── conftest.py            # Pytest fixtures
```

---

## 常用命令速查
```bash
# 本地开发
python run.py                          # 运行所有测试
python run.py -m api                   # API 测试
python run.py -m ui                    # UI 测试
python run.py -m smoke --env uat       # UAT 冒烟测试
python run.py --help                   # 查看帮助

# CI/CD
python run.py --ci -m api              # 非交互模式
python run.py --ci --env uat -m smoke  # UAT 冒烟测试

# 报告控制
python run.py -m api --no-open         # 不打开浏览器
python run.py -m api --no-save         # 不保存历史
```

---

## 扩展框架

### 添加新的测试标记
编辑 `pytest.ini`：
```ini
markers =
    api: API 测试
    ui: UI 测试
    smoke: 冒烟测试
    regression: 回归测试  # 新增
```

### 添加新环境
创建 `config/env_prod.yaml`：
```yaml
base_url: "https://prod.example.com"
api_base_url: "https://api.prod.example.com"
timeout: 30000
```
使用：
```bash
python run.py --env prod
```

### 添加新的测试场景
1. 在 `features/test_case/` 创建 `.feature` 文件
2. 在 `features/steps/` 实现步骤定义
3. 运行 `python run.py`

---

## 故障排查

### 测试未运行
```bash
# 检查标记是否存在
python run.py -m api  # 使用有效的标记
```

### Allure 报告未生成
```bash
# 检查 Allure CLI
ls tools/allure/bin/

# 重新下载：https://github.com/allure-framework/allure2/releases
```

### 截图未显示
截图已嵌入到 `shareable-report.html` 中，直接双击打开即可查看。


## 技术栈
- **Python 3.8+** - 编程语言
- **Pytest** - 测试框架
- **Pytest-BDD** - BDD 支持
- **Playwright** - UI 自动化
- **Requests** - API 测试
- **Allure** - 测试报告
- **PyYAML** - 配置管理


## 最佳实践
- ✅ 使用标记组织测试（`-m api`, `-m smoke`）
- ✅ 提交前运行冒烟测试
- ✅ 定期清理历史报告
- ✅ CI/CD 中使用 `--ci` 模式
- ✅ 保持 Feature 文件简洁易读
- ✅ 复用步骤定义

---

---

## Git 操作指南

### 📋 当前状态
您的项目现在有两个版本：
1. **原始项目**：`Behavior/` - 使用自定义框架
2. **新项目**：`pytest-bdd/` - 使用 Pytest-BDD 框架

**Git 状态**：所有改动已恢复，但未提交

### 🎯 提交改动

#### 选项 1：提交新框架（推荐）⭐
```bash
# 1. 查看改动摘要
git status

# 2. 添加所有改动
git add .

# 3. 提交改动
git commit -m "feat: 迁移到 Pytest-BDD 框架

主要改动：
- 删除旧的 behavior_framework
- 新增 pytest-bdd 框架
- 新增 Allure 报告系统
- 新增 Jenkins 集成
- 优化文档结构
- 简化配置管理

详见：changes.md
"

# 4. 推送到远程
git push
```

#### 选项 2：创建备份分支
```bash
# 1. 创建备份分支（保存原始代码）
git branch backup-original-framework

# 2. 推送备份分支
git push origin backup-original-framework

# 3. 回到主分支继续工作
git checkout master

# 4. 提交新框架
git add .
git commit -m "feat: 迁移到 Pytest-BDD 框架"
git push
```

#### 选项 3：撤销改动
如果您想恢复到原始状态：
```bash
# 撤销所有未提交的改动
git checkout .

# 删除所有未跟踪的文件
git clean -fd

# 确认状态
git status
```

### 💾 备份策略

#### Git 分支备份（推荐）
```bash
# 创建备份分支
git branch backup-$(date +%Y%m%d)
git push origin backup-$(date +%Y%m%d)
```

#### 文件系统备份
```bash
# 复制整个项目
cp -r ../Behavior ../Behavior_backup_$(date +%Y%m%d)

# 或者打包
tar -czf Behavior_backup_$(date +%Y%m%d).tar.gz ../Behavior
```

### 🔍 查看改动详情

#### 查看具体文件改动
```bash
# README.md 的改动
git diff Behavior/README.md

# main.py 的改动
git diff Behavior/main.py

# requirements.txt 的改动
git diff Behavior/requirements.txt

# 查看改动统计
git diff --stat
```

#### 查看删除的文件内容
```bash
# 查看被删除文件的最后版本
git show HEAD:Behavior/run_tests.py

# 恢复某个被删除的文件
git checkout HEAD -- Behavior/run_tests.py
```

### 📊 改动文件清单

#### 已修改的文件（3 个）
```
M  Behavior/README.md           # 完全重写
M  Behavior/main.py             # 调整入口
M  Behavior/requirements.txt    # 更新依赖
```

#### 已删除的文件（66 个）
```
D  Behavior/behavior_framework/  # 整个旧框架
D  Behavior/tests/               # 旧的测试文件
D  Behavior/run_tests.py         # 旧的运行脚本
D  Behavior/test_framework.py    # 旧的框架测试
D  Behavior/demo_screenshot.png  # 演示截图
D  Behavior/env.example          # 旧的配置示例
```

#### 新增的文件（13+ 个）
```
?? Behavior/features/            # BDD 场景和步骤
?? Behavior/src/                 # 服务层和页面对象
?? Behavior/data/                # 配置和数据
?? Behavior/run.py               # 新的运行脚本
?? Behavior/Jenkinsfile          # CI/CD 配置
?? pytest-bdd/                   # 完整的新框架
```

---

## 常见问题

### Q1: 如何查看被删除文件的内容？
```bash
# 查看文件历史
git log -- Behavior/run_tests.py

# 查看最后一次提交时的内容
git show HEAD:Behavior/run_tests.py

# 恢复文件
git checkout HEAD -- Behavior/run_tests.py
```

### Q2: 如何撤销某个文件的改动？
```bash
# 撤销单个文件
git checkout -- Behavior/README.md

# 撤销所有改动
git checkout .
```

### Q3: 如何只提交部分文件？
```bash
# 只添加特定文件
git add pytest-bdd/README.md
git add pytest-bdd/JENKINS.md

# 提交
git commit -m "docs: 优化文档"
```

### Q4: 如何对比两个项目？
```bash
# 使用 diff 命令
diff -r ../Behavior pytest-bdd --brief

# 或使用 Git
git diff --no-index ../Behavior pytest-bdd
```

### Q5: 如何恢复到原始状态？
```bash
# 方案 A：使用 Git
git checkout .
git clean -fd

# 方案 B：从备份分支恢复
git checkout backup-original-framework
git checkout -b restore-original
```

### Q6: 测试未运行怎么办？
```bash
# 检查标记是否存在
python run.py -m api  # 使用有效的标记
```

### Q7: Allure 报告未生成？
   ```bash
# 检查 Allure CLI
ls tools/allure/bin/

# 重新下载：https://github.com/allure-framework/allure2/releases
```

### Q8: 截图未显示？
截图已嵌入到 `shareable-report.html` 中，直接双击打开即可查看。

---

## 相关文档
- **[JENKINS.md](JENKINS.md)** - Jenkins 配置指南
- **[changes.md](changes.md)** - 详细变更记录与文件对比
- **[Pytest-BDD 文档](https://pytest-bdd.readthedocs.io/)**
- **[Allure 文档](https://docs.qameta.io/allure/)**
- **[Playwright 文档](https://playwright.dev/python/)**