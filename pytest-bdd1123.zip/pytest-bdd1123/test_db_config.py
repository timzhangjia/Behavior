#!/usr/bin/env python3
"""
Test script to verify database configuration and connection functionality.
"""

import sys
import os

# Add project root to Python path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from config.settings import get_settings
from src.api.services.db_service import DatabaseServiceFactory


def test_database_config():
    """Test loading database configuration and creating database service."""
    print("Testing database configuration loading...")
    
    try:
        # Load settings from 'sit' environment
        settings = get_settings('sit')
        
        # Check if database configuration exists
        if not settings.database:
            print("Error: Database configuration not found in SIT environment")
            return False
        
        # Print database configuration (mask password for security)
        db_config = settings.database
        print(f"Database configuration loaded successfully:")
        print(f"  DB Type: {db_config.db_type}")
        print(f"  Host: {db_config.host}")
        print(f"  Port: {db_config.port}")
        print(f"  Database: {db_config.database}")
        print(f"  Username: {db_config.username}")
        print(f"  Password: {'*' * len(db_config.password)}")
        print(f"  Charset: {db_config.charset}")
        print(f"  Connect Timeout: {db_config.connect_timeout}")
        
        # Create database service
        print("\nCreating database service...")
        # Convert DatabaseConfig object to dict format expected by create_service
        config_dict = {
            'host': db_config.host,
            'port': db_config.port,
            'database': db_config.database,
            'username': db_config.username,
            'password': db_config.password,
            'charset': db_config.charset,
            'connect_timeout': db_config.connect_timeout
        }
        db_service = DatabaseServiceFactory.create_service(
            db_type=db_config.db_type,
            config=config_dict
        )
        
        print(f"Database service created: {db_service.__class__.__name__}")
        print("\nTest passed! Database configuration and service creation works correctly.")
        print("Note: Actual database connection is not tested in this script to avoid connection errors.")
        return True
        
    except Exception as e:
        print(f"Error during test: {str(e)}")
        import traceback
        traceback.print_exc()
        return False


if __name__ == "__main__":
    success = test_database_config()
    exit(0 if success else 1)