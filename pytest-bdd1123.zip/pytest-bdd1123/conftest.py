from __future__ import annotations

pytest_plugins = [
    "features.steps.api.common_steps",
    "features.steps.common.config_steps",
]

import pytest
from _pytest.config import Config
from _pytest.nodes import Item


def pytest_addoption(parser: pytest.Parser) -> None:
    parser.addoption(
        "--env",
        action="store",
        default="sit",
        help="Target environment configuration to load (e.g. sit, uat)",
    )


def pytest_configure(config: Config) -> None:
    """Configure pytest to hide setup and teardown fixtures in Allure reports."""
    # Set Allure to not display fixtures in the report
    config.option.allure_report_dir = config.getoption("--alluredir")
    

def pytest_bdd_apply_tag(tag, function):
    """A hook to apply tags from feature files to test functions."""
    # This hook is called for every tag in a feature file.
    # We can get the pytest marker from the tag and apply it to the test function.
    marker = getattr(pytest.mark, tag)
    marker(function)


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item: Item, call):
    """Hook to modify test report and hide fixture information from Allure."""
    outcome = yield
    report = outcome.get_result()
    
    # Hide setup and teardown from Allure reports
    if report.when in ("setup", "teardown"):
        # Mark these phases to be hidden in Allure
        if hasattr(report, "wasxfail"):
            # Keep xfail information
            pass
        else:
            # Suppress fixture details for setup/teardown
            report.sections = []
