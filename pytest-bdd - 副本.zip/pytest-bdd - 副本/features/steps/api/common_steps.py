from __future__ import annotations

import json
import allure
import pytest
from pytest_bdd import given, when, then, parsers

from features.test_data.api import load_payload


@given(parsers.parse('I set the API request path to "{path}"'))
def set_request_path(scenario_context, path: str):
    """Store the request path in the scenario context."""
    scenario_context['request_path'] = path


@given(parsers.parse('I load the payload named "{payload_name}"'))
def load_request_payload(scenario_context, payload_name: str):
    """Load JSON payload via `load_payload` and save it to scenario context."""
    payload_data = load_payload(payload_name)
    scenario_context['payload'] = payload_data
    return payload_data


@when('I send a GET request')
def send_get_request(api_request_context, scenario_context):
    """Send a GET request and save the response."""
    path = scenario_context.get('request_path')
    if path is None:
        pytest.fail("Error: request path not set")

    response = api_request_context.get(path)
    scenario_context['response'] = response
    return response


@when('I send a POST request')
def send_post_request(api_request_context, scenario_context):
    """Send a POST request using the payload stored in context."""
    path = scenario_context.get('request_path')
    payload = scenario_context.get('payload')

    if path is None:
        pytest.fail("Error: POST request path not set")
    if payload is None:
        pytest.fail("Error: POST payload not loaded")

    # Ensure payload contains both 'username' and 'email' when appropriate so
    # it works with both the local mock server (expects 'username') and
    # external test APIs like reqres.in (expect 'email').
    data_payload = dict(payload)
    if 'username' in data_payload and 'email' not in data_payload:
        data_payload['email'] = data_payload.get('username')
    if 'email' in data_payload and 'username' not in data_payload:
        data_payload['username'] = data_payload.get('email')

    response = api_request_context.post(path, data=json.dumps(data_payload))
    scenario_context['response'] = response
    return response


@when('I send a POST request with admin credentials')
def send_post_with_admin(api_request_context, scenario_context, app_config):
    """Send a POST request using admin credentials from `app_config`."""
    path = scenario_context.get('request_path')
    if path is None:
        pytest.fail("Error: POST request path not set")

    admin = app_config.get('users', {}).get('admin', {})
    username = admin.get('username')
    password = admin.get('password')
    if not username or not password:
        pytest.fail("Error: admin credentials not configured in config")

    # Include both 'username' and 'email' so the request works against
    # both the mock server (which checks 'username') and external APIs
    # that expect 'email'.
    payload = {"username": username, "email": username, "password": password}
    response = api_request_context.post(path, data=json.dumps(payload))
    scenario_context['response'] = response
    return response


@then(parsers.parse('the response status code should be {status_code:d}'))
def check_status_code(scenario_context, status_code: int):
    response = scenario_context.get('response')
    assert response is not None, "Response object was not saved"
    if response.status != status_code:
        # Try to get a useful body representation for debugging
        try:
            body_text = response.text()
        except Exception:
            try:
                body_text = response.json()
            except Exception:
                body_text = "<unable to read body>"

        print(f"[DEBUG] Response status={response.status}, expected={status_code}")
        print(f"[DEBUG] Response body: {body_text}")
        pytest.fail(f"Expected status code {status_code}, got {response.status}. Body: {body_text}")


@then(parsers.parse('the response JSON "{key}" should be {value:d}'))
def check_response_body_integer(scenario_context, key: str, value: int):
    response = scenario_context.get('response')
    assert response is not None, "Response object was not saved"
    response_json = response.json()
    assert key in response_json, f"Key '{key}' not found in response JSON"
    actual_value = response_json.get(key)
    assert actual_value == value, f"Expected '{key}' to be {value}, got {actual_value}"


@then(parsers.parse('the response "{resp_key}" should match payload "{payload_key}"'))
def check_response_matches_payload(scenario_context, resp_key: str, payload_key: str):
    response = scenario_context.get('response')
    payload = scenario_context.get('payload')
    assert response is not None, "Response object was not saved"
    assert payload is not None, "Payload was not saved"
    response_json = response.json()
    assert resp_key in response_json, f"Key '{resp_key}' not found in response JSON"
    assert payload_key in payload, f"Key '{payload_key}' not found in payload"
    actual_value = response_json.get(resp_key)
    expected_value = payload.get(payload_key)
    assert actual_value == expected_value, (
        f"Expected response['{resp_key}'] == payload['{payload_key}'] ({expected_value}), got {actual_value}"
    )


@then(parsers.parse('the response JSON should contain "{key}"'))
def assert_key_present(scenario_context, key: str):
    response = scenario_context.get('response')
    assert response is not None, "Response object was not saved"
    response_json = response.json()
    assert key in response_json, f"Response JSON missing key: '{key}'"
