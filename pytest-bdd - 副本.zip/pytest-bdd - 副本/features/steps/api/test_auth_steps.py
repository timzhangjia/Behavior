from __future__ import annotations

from pytest_bdd import scenarios

from features.steps.api import common_steps  # noqa: F401
from src.utils.bdd_feature_locator import feature_path_for

# Ensure path uses forward slashes for pytest-bdd compatibility on Windows
scenarios(feature_path_for(__file__).replace('\\', '/'))
