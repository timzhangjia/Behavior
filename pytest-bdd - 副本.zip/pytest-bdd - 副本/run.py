"""
This runner executes tests, generates an Allure web report, and then packages it
into a single self-contained HTML file (TestReport_*.html).

Usage examples:
  python run.py                 # Run all tests in SIT, produce final report
  python run.py -m api          # Run only API tests
  python run.py -m smoke --env uat
  python run.py --no-report     # Run tests only (no reports)
  python run.py --no-open       # Do not open the final report after generation
  python run.py --ci            # CI mode (non-interactive, implies --no-open)
"""
import argparse
import json
import shutil
import subprocess
import sys
import webbrowser
from datetime import datetime
from pathlib import Path

# --- Configuration ---
from config.settings import get_project_config

PROJECT_ROOT = Path(__file__).parent.resolve()
_project_config = get_project_config()
_paths_config = _project_config.get("paths", {})
_report_config = _project_config.get("report", {})

REPORTS_DIR = PROJECT_ROOT / _paths_config.get("reports_dir", "reports")
RESULTS_DIR = REPORTS_DIR / _paths_config.get("allure_results_dir", "allure-results")
WEB_REPORT_DIR = REPORTS_DIR / _paths_config.get("allure_report_dir", "allure-report")
ALLURE_CLI_PATH = PROJECT_ROOT / _paths_config.get("allure_cli_path", "tools/allure/bin/allure")

REPORT_PREFIX = _report_config.get("report_prefix", "TestReport_")


class Colors:
    HEADER = "\033[95m"
    OKCYAN = "\033[96m"
    OKGREEN = "\033[92m"
    WARNING = "\033[93m"
    FAIL = "\033[91m"
    ENDC = "\033[0m"
    BOLD = "\033[1m"


def print_header(message: str) -> None:
    print(f"\n{Colors.HEADER}{Colors.BOLD}{'='*60}{Colors.ENDC}")
    print(f"{Colors.HEADER}{Colors.BOLD}{message}{Colors.ENDC}")
    print(f"{Colors.HEADER}{Colors.BOLD}{'='*60}{Colors.ENDC}")


def print_success(message: str) -> None:
    try:
        print(f"{Colors.OKGREEN}✓ {message}{Colors.ENDC}")
    except UnicodeEncodeError:
        print(f"{Colors.OKGREEN}[OK] {message}{Colors.ENDC}")


def print_warning(message: str) -> None:
    try:
        print(f"{Colors.WARNING}⚠ {message}{Colors.ENDC}")
    except UnicodeEncodeError:
        print(f"{Colors.WARNING}[WARN] {message}{Colors.ENDC}")


def print_error(message: str) -> None:
    try:
        print(f"{Colors.FAIL}✗ {message}{Colors.ENDC}")
    except UnicodeEncodeError:
        print(f"{Colors.FAIL}[ERROR] {message}{Colors.ENDC}")


def run_command(command: list, cwd: Path = PROJECT_ROOT, check: bool = False) -> int:
    print(f"\n{Colors.OKCYAN}> Running: {' '.join(str(c) for c in command)}{Colors.ENDC}")
    use_shell = sys.platform == "win32"
    try:
        process = subprocess.run(command, cwd=cwd, shell=use_shell, check=check, capture_output=False)
        return process.returncode
    except subprocess.CalledProcessError as e:
        print_warning(f"Command failed with exit code {e.returncode}")
        return e.returncode
    except FileNotFoundError:
        print_error(f"Command not found: {command[0]}")
        return 1


def clean_temp_reports() -> None:
    print_header("Step 1: Cleaning Temporary Files")

    if RESULTS_DIR.exists():
        print(f"Removing results directory: {RESULTS_DIR}")
        shutil.rmtree(RESULTS_DIR)

    if WEB_REPORT_DIR.exists():
        print(f"Removing report directory: {WEB_REPORT_DIR}")
        shutil.rmtree(WEB_REPORT_DIR)

    REPORTS_DIR.mkdir(exist_ok=True)
    print_success("Report directories are ready.")


def clean_final_temp_files() -> None:
    print_header("Step 7: Cleaning Temporary Files")

    temp = []
    if RESULTS_DIR.exists():
        shutil.rmtree(RESULTS_DIR)
        temp.append("allure-results/")
    if WEB_REPORT_DIR.exists():
        shutil.rmtree(WEB_REPORT_DIR)
        temp.append("allure-report/")

    if temp:
        print_success(f"Cleaned temporary files: {', '.join(temp)}")
    else:
        print_success("No temporary files to clean")


def run_tests(env: str, marker: str | None, pytest_args: list | None, no_report: bool) -> int:
    print_header("Step 2: Running Tests")

    cmd = ["pytest", f"--env={env}"]
    if not no_report:
        cmd.extend([f"--alluredir={RESULTS_DIR}", "--clean-alluredir"])
    if marker:
        cmd.extend(["-m", marker])
        print(f"Marker filter: {marker}")
    if pytest_args:
        cmd.extend(pytest_args)

    print(f"Environment: {env}")
    code = run_command(cmd)

    if not no_report:
        if not RESULTS_DIR.exists() or not any(RESULTS_DIR.glob("*-result.json")):
            print_error("No test results were generated!")
            print("Possible reasons:")
            print("  - No tests matched the specified marker")
            print("  - All tests were skipped")
            print("  - Pytest failed to collect tests")
            return 1

    if code == 0:
        print_success("All tests passed!")
    else:
        print_warning("Some tests failed (report will still be generated)" if not no_report else "Some tests failed")
    return code


def clean_allure_fixtures() -> None:
    print_header("Step 3: Post-Processing Results")

    if not RESULTS_DIR.is_dir():
        print_warning("No results directory found to clean")
        return

    cleaned = 0
    for file_path in RESULTS_DIR.glob("*-result.json"):
        try:
            with open(file_path, "r+", encoding="utf-8") as f:
                data = json.load(f)
                if data.get("beforeStages") or data.get("afterStages"):
                    data["beforeStages"] = []
                    data["afterStages"] = []
                    f.seek(0)
                    json.dump(data, f, ensure_ascii=False, indent=2)
                    f.truncate()
                    cleaned += 1
        except (json.JSONDecodeError, OSError):
            continue

    for file_path in RESULTS_DIR.glob("*-container.json"):
        try:
            with open(file_path, "r+", encoding="utf-8") as f:
                data = json.load(f)
                if data.get("befores") or data.get("afters"):
                    data["befores"] = []
                    data["afters"] = []
                    f.seek(0)
                    json.dump(data, f, ensure_ascii=False, indent=2)
                    f.truncate()
                    cleaned += 1
        except (json.JSONDecodeError, OSError):
            continue

    print_success(f"Cleaned fixture details from {cleaned} files")


def generate_allure_report() -> int:
    print_header("Step 4: Generating Allure Web Report")

    if not ALLURE_CLI_PATH.exists() and not (ALLURE_CLI_PATH.parent / "allure.bat").exists():
        print_error(f"Allure CLI not found at: {ALLURE_CLI_PATH}")
        print_error("Please install Allure to tools/allure/ directory")
        return 1

    cmd = [str(ALLURE_CLI_PATH), "generate", str(RESULTS_DIR), "-o", str(WEB_REPORT_DIR), "--clean"]
    code = run_command(cmd)
    if code == 0:
        print_success(f"Report generated: {WEB_REPORT_DIR / 'index.html'}")
    else:
        print_error("Failed to generate Allure report")
    return code


def build_final_report_path(env: str, marker: str | None) -> Path:
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    if marker:
        m = marker.replace(" ", "_").replace('"', '').replace("'", "").replace("/", "_").replace("\\", "_")
        suffix = f"_{m}"
    else:
        suffix = "_all"
    return REPORTS_DIR / f"{REPORT_PREFIX}{ts}_{env}{suffix}.html"


def generate_single_file_report(final_output: Path) -> Path | None:
    """Package Allure web report into a single HTML file at final_output."""
    print_header("Step 5: Generating Single-File Report")

    packager_script = PROJECT_ROOT / "src" / "utils" / "allure_report_builder.py"
    if not packager_script.exists():
        print_error(f"Packager script not found: {packager_script}")
        return None

    REPORTS_DIR.mkdir(exist_ok=True)

    cmd = [sys.executable, str(packager_script), str(WEB_REPORT_DIR), str(final_output)]
    code = run_command(cmd)

    if code == 0 and final_output.exists():
        size_mb = final_output.stat().st_size / (1024 * 1024)
        print_success(f"Final report generated: {final_output}")
        print(f"File size: {size_mb:.2f} MB")
        return final_output
    print_error("Failed to generate single-file report")
    return None


def open_report(file_path: Path) -> None:
    print_header("Opening Report")
    try:
        webbrowser.open_new_tab(file_path.as_uri())
    except Exception as e:
        print_warning(f"Unable to open browser automatically: {e}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Unified test runner and single-file report generator",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=(
            "Examples:\n"
            "  python run.py                 # Run all tests, produce final report\n"
            "  python run.py -m api          # Run API tests only\n"
            "  python run.py -m smoke --env uat\n"
            "  python run.py --no-report     # Run tests only (no reports)\n"
            "  python run.py --no-open       # Do not open the final report\n"
            "  python run.py --ci            # CI mode (non-interactive)\n"
        ),
    )

    parser.add_argument("-m", "--marker", help="Pytest marker expression (e.g., 'api', 'smoke', 'ui')")
    parser.add_argument("--env", default="sit", help="Target environment (default: sit)")
    parser.add_argument("pytest_args", nargs=argparse.REMAINDER, help="Additional pytest arguments")

    parser.add_argument("--no-report", action="store_true", help="Don't generate any reports (only run tests)")
    parser.add_argument("--no-open", action="store_true", help="Don't open report after generation")
    parser.add_argument("--ci", action="store_true", help="CI mode (non-interactive)")

    args = parser.parse_args()

    if args.ci:
        args.no_open = True
        print_header("Running in CI/CD Mode")

    try:
        clean_temp_reports()
        test_exit = run_tests(args.env, args.marker, args.pytest_args, args.no_report)

        if args.no_report:
            print_header("Execution Complete")
            print_success("All tests passed!" if test_exit == 0 else "Some tests failed")
            clean_final_temp_files()
            sys.exit(test_exit)

        clean_allure_fixtures()
        if generate_allure_report() != 0:
            sys.exit(1)

        final_path = build_final_report_path(args.env, args.marker)
        generated = generate_single_file_report(final_path)
        if not generated:
            sys.exit(1)

        if not args.no_open:
            open_report(final_path)

        print_header("Execution Complete")
        print_success(f"Final Report: {final_path}")

        clean_final_temp_files()
        sys.exit(test_exit)

    except KeyboardInterrupt:
        print_error("\nExecution interrupted by user")
        sys.exit(130)
    except Exception as e:
        print_error(f"Unexpected error: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
