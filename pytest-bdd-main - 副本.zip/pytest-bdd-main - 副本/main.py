from __future__ import annotations
import sys
from src.runner import main_entry

# Used only when no CLI args are provided
DEBUG_RUN = {
    "env": "SIT",
    "tags": "ui,smoke",      # comma => AND; or "(ui) and (smoke)"
    "features": ["features"],# extra paths; 'src' is added automatically
    "allure": True,
    "clean": True,
    "pytest_extra": []
}

if __name__ == "__main__":
    sys.exit(main_entry(DEBUG_RUN))