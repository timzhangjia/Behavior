"""
UI Test Steps - Google login & search demo powered by Page Objects.
"""

from __future__ import annotations

from typing import Dict

from pytest_bdd import given, then, when

from src.ui.pages import (
    GoogleLoginPage,
    GoogleSearchPage,
    PlaywrightSession,
    SessionOptions,
)


def _get_google_cfg(context) -> Dict:
    if not hasattr(context, "google_config"):
        context.google_config = context.config.get_ui("google", {})
    return context.google_config


@given("I launch the Playwright browser")
def launch_browser(context):
    options = context.config.browser_options()
    session_options = SessionOptions(
        headless=options.headless,
        slow_mo=options.slow_mo,
        viewport=options.viewport,
    )
    session = getattr(context, "ui_session", None)
    if session is None:
        session = PlaywrightSession(session_options)
        session.start()
        context.ui_session = session
    else:
        session.start()


@given("I open the Google login page")
def open_google_login(context):
    google_cfg = _get_google_cfg(context)
    selectors = google_cfg.get("selectors", {})
    context.google_login_page = GoogleLoginPage(context.ui_session, selectors)
    login_url = google_cfg.get("login_url")
    if not login_url:
        raise ValueError("Missing 'login_url' in google UI configuration.")
    context.google_login_page.load(login_url)


@when("I fill the Google login email from configuration")
def fill_google_email(context):
    google_cfg = _get_google_cfg(context)
    credentials = google_cfg.get("credentials", {})
    email = credentials.get("email", "")
    context.google_login_page.enter_email(email)
    context.filled_google_email = email
    # Google may block automation past this step; clicking next is best-effort only.
    context.google_login_page.click_next()


@then("the login email field should contain the configured email")
def assert_google_email_prefilled(context):
    expected_email = context.filled_google_email
    assert context.google_login_page.is_email_prefilled(
        expected_email
    ), "Configured email not present in the login field."


@when("I open the Google search page")
def open_google_search(context):
    google_cfg = _get_google_cfg(context)
    selectors = google_cfg.get("selectors", {})
    context.google_search_page = GoogleSearchPage(context.ui_session, selectors)
    search_url = google_cfg.get("search_url")
    if not search_url:
        raise ValueError("Missing 'search_url' in google UI configuration.")
    context.google_search_page.load(search_url)


@when("I search Google for the configured keyword")
def search_google_keyword(context):
    google_cfg = _get_google_cfg(context)
    keyword = google_cfg.get("search_keyword", "Playwright")
    context.google_search_keyword = keyword
    context.google_search_page.search(keyword)


@then("the Google search results should mention the keyword")
def assert_google_search_results(context):
    keyword = context.google_search_keyword
    results = context.google_search_page.get_result_texts(limit=5)
    normalized = keyword.lower()
    assert any(
        normalized in (result or "").lower() for result in results
    ), f"Search results do not contain '{keyword}'."
