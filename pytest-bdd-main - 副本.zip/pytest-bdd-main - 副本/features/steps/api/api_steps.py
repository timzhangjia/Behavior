"""
API Test Steps - Config-driven API demo case.
"""

from __future__ import annotations

import asyncio
from typing import Dict

from pytest_bdd import given, parsers, then, when

from src.api.request import APIRequest


@given(parsers.parse('I prepare the API demo request "{request_name}"'))
def prepare_api_request(context, request_name):
    request_cfg = context.config.get_api_request(request_name)
    payload = context.config.load_api_payload(request_cfg["payload"])
    context.api_request_config = request_cfg
    context.api_request_payload = payload
    context.api_base_url = context.config.api.get("base_url", "")


@when("I send the configured API request")
def send_configured_api_request(context):
    request_cfg: Dict = context.api_request_config
    payload: Dict = context.api_request_payload

    async def _execute():
        client = APIRequest(base_url=context.api_base_url)
        await client.start()
        try:
            response = await client.request(
                method=request_cfg.get("method", "GET"),
                endpoint=request_cfg.get("endpoint", ""),
                json=payload,
            )
        finally:
            await client.close()
        return response

    context.api_response = asyncio.run(_execute())


@then(parsers.parse('the API response status should be "{expected_status}"'))
def assert_api_status(context, expected_status):
    response = context.api_response
    assert (
        response.status == int(expected_status)
    ), f"Expected status {expected_status}, got {response.status}"


@then("the API response should include the configured payload fields")
def assert_api_payload(context):
    expected_fields = context.api_request_config.get("expected", {})
    body = context.api_response.json() or {}
    for key, expected_value in expected_fields.items():
        actual_value = body.get(key)
        assert (
            actual_value == expected_value
        ), f"Expected response['{key}'] == {expected_value!r}, got {actual_value!r}"
