"""Reusable actions for API-related Behave steps (co-located with API client)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

from src.api.assertions import APIAssertions
from src.api.request import APIRequest
from src.utils.file_reader import FileReader
from src.utils.logger import Logger
from src.utils.helpers import get_value_from_yaml_path, run_in_loop

logger = Logger()
file_reader = FileReader()


def initialize_client(context, base_url: str) -> None:
    context.api_client = APIRequest(base_url=base_url)
    run_in_loop(context, context.api_client.start())
    logger.info(f"API client initialized with base URL: {base_url}")


def initialize_client_from_config(context, config_file: str, yaml_path: str) -> None:
    config_dir = Path(context.settings.api_config_dir)
    config_path = config_dir / config_file
    if not config_path.exists():
        raise FileNotFoundError(f"API config file not found: {config_path}")

    config_data = file_reader.read_yaml(str(config_path))
    base_url = get_value_from_yaml_path(config_data, yaml_path)
    if not base_url:
        raise ValueError(f"Value at path '{yaml_path}' is empty in '{config_file}'")

    context.api_config = config_data
    initialize_client(context, base_url)


def set_header(context, name: str, value: str) -> None:
    headers = getattr(context, "api_headers", {})
    headers[name] = value
    context.api_headers = headers
    logger.info(f"Set API header: {name} = {value}")


def set_auth(context, auth_type: str, credentials: str) -> None:
    if not hasattr(context, "api_client") or context.api_client is None:
        raise RuntimeError("API client is not initialised.")
    context.api_client.set_auth(auth_type, credentials)
    logger.info(f"Configured API authentication: {auth_type}")


def _resolve_payload_path(context, json_file: str) -> Path:
    payload_dir = Path(context.settings.api_payload_dir)
    json_path = payload_dir / json_file
    if not json_path.exists():
        raise FileNotFoundError(f"JSON payload file not found: {json_path}")
    return json_path


def load_json_payload(context, json_file: str) -> Dict[str, Any]:
    json_path = _resolve_payload_path(context, json_file)
    return file_reader.read_json(str(json_path))


def _build_full_url(context, endpoint: str, params: Optional[Dict[str, Any]] = None) -> str:
    full_url = context.api_client._build_url(endpoint)  # pylint: disable=protected-access
    if params:
        import urllib.parse
        full_url += "?" + urllib.parse.urlencode(params)
    return full_url


def _record_evidence(context, method: str, url: str, headers: Dict[str, str], request_body: Any, response) -> None:
    if not hasattr(context, "evidence_manager"):
        return
    response_body = response.json() if response.is_json() else response.text
    context.evidence_manager.add_api_request(
        method=method,
        url=url,
        headers=headers,
        body=request_body,
        response_status=response.status,
        response_headers=response.headers,
        response_body=response_body,
    )


def send_request(
    context,
    method: str,
    endpoint: str,
    *,
    params: Optional[Dict[str, Any]] = None,
    json_body: Optional[Any] = None,
    raw_body: Optional[Any] = None,
) -> None:
    if not hasattr(context, "api_client") or context.api_client is None:
        raise RuntimeError("API client is not initialised.")

    headers = getattr(context, "api_headers", {})
    params = params or getattr(context, "api_params", {})

    json_payload = json_body if isinstance(json_body, (dict, list)) else None
    raw_payload = raw_body
    if raw_payload is None and json_payload is None and json_body is not None:
        raw_payload = json_body

    response = run_in_loop(
        context,
        context.api_client.request(
            method=method,
            endpoint=endpoint,
            headers=headers,
            params=params,
            json=json_payload,
            data=raw_payload if raw_payload is not None and not isinstance(raw_payload, (dict, list)) else None,
        ),
    )

    context.response = response
    full_url = _build_full_url(context, endpoint, params)
    request_payload = json_body if json_body is not None else raw_body
    _record_evidence(context, method, full_url, headers, request_payload, response)
    logger.info(f"Sent {method} request to {endpoint}")


def send_request_with_json_file(context, method: str, endpoint: str, json_file: str) -> None:
    payload = load_json_payload(context, json_file)
    send_request(context, method, endpoint, json_body=payload)


def send_request_with_body_from_text(context, method: str, endpoint: str, body_text: str) -> None:
    try:
        parsed = json.loads(body_text)
    except json.JSONDecodeError:
        parsed = body_text
    send_request(context, method, endpoint, json_body=parsed)


def send_request_with_params_table(context, method: str, endpoint: str, table) -> None:
    params: Dict[str, Any] = {}
    for row in table:
        params[row["key"]] = row["value"]
    context.api_params = params
    send_request(context, method, endpoint, params=params)


def assert_status(context, expected_status: int) -> None:
    APIAssertions(context.response).assert_status(expected_status)


def assert_success(context) -> None:
    APIAssertions(context.response).assert_success()


def assert_header(context, header_name: str, expected_value: str) -> None:
    APIAssertions(context.response).assert_header(header_name, expected_value)


def assert_json_value(context, key: str, expected_value: Any) -> None:
    APIAssertions(context.response).assert_json(key, expected_value)


def assert_text_contains(context, expected_text: str) -> None:
    APIAssertions(context.response).assert_text(expected_text)


def assert_is_json(context) -> None:
    if not context.response.is_json():
        raise AssertionError("Response is not JSON format")


def save_json_value(context, key: str, variable_name: str) -> None:
    if not hasattr(context, "variables"):
        context.variables = {}
    value = context.response.get_json_value(key)
    context.variables[variable_name] = value
    logger.info(f"Saved variable: {variable_name} = {value}")


def parse_expected_value(raw_value: str) -> Any:
    lowered = raw_value.lower()
    if lowered in {"true", "false"}:
        return lowered == "true"
    try:
        if "." in raw_value:
            return float(raw_value)
        return int(raw_value)
    except ValueError:
        return raw_value

