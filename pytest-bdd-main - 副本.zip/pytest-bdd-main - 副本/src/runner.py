# src/utils/runner.py
from __future__ import annotations
import argparse
import os
import shutil
import subprocess
from pathlib import Path
from typing import List, Optional, Dict, Any

def run_with_pytest(env: str,
                    tags: Optional[str],
                    features: List[str],
                    allure: bool,
                    clean_results: bool,
                    pytest_extra: Optional[List[str]] = None) -> int:
    """
    Build and execute a pytest command. Always collect tests from src/
    (steps + auto-binding module), also include features/ by default,
    and ignore legacy tests/.
    """
    allure_results_dir = Path('./allure-results')
    if clean_results and allure_results_dir.exists():
        shutil.rmtree(allure_results_dir, ignore_errors=True)
    allure_results_dir.mkdir(parents=True, exist_ok=True)

    # Persist runtime env for downstream config readers, if any
    Path('.runtime_env').write_text(env.upper(), encoding='utf-8')
    os.environ["TEST_ENV"] = env.lower()

    cmd: List[str] = ['pytest', '-q', '--ignore=tests']

    # Single -m expression
    marker_expr = None
    if tags:
        # Allow raw expression; comma-separated list => AND
        if any(op in tags for op in (' and ', ' or ', ' not ')):
            marker_expr = tags.strip()
        else:
            parts = [t.strip() for t in tags.split(',') if t.strip()]
            if parts:
                marker_expr = ' and '.join(parts)
    if marker_expr:
        cmd += ['-m', marker_expr]

    # Always collect from src; also add features/ by default
    paths: List[str] = []
    # user-specified additional paths
    if features:
        paths.extend([p for p in features if p])

    # prepend src if not provided
    norm = [p.replace('\\', '/') for p in paths]
    if 'src' not in norm:
        paths.insert(0, 'src')
    # append features if not provided
    norm = [p.replace('\\', '/') for p in paths]
    if all('features' not in p for p in norm):
        paths.append('features')

    cmd += paths

    if allure:
        cmd += ['--alluredir', allure_results_dir.as_posix()]

    # Ensure project root is importable
    env_map = {**os.environ}
    env_map['PYTHONPATH'] = os.getcwd() + (os.pathsep + env_map['PYTHONPATH'] if 'PYTHONPATH' in env_map else '')

    print('Running:', ' '.join(cmd))
    return subprocess.run(cmd, env=env_map).returncode


def cli_main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="Execute pytest-bdd features from features/ (no tests/).")
    parser.add_argument('--env', default='SIT', help='SIT or UAT')
    parser.add_argument('-f', '--feature', help='A single feature file path; filtered via -k by file stem.')
    parser.add_argument('--features', default=None, help='Extra folders/files, comma separated.')
    parser.add_argument('-t', '--tags', default=None, help='Tag filter (raw -m expression or comma => AND).')
    parser.add_argument('--allure', action='store_true')
    parser.add_argument('--clean', dest='clean', action='store_true')
    args, unknown = parser.parse_known_args(argv)

    # Build extra paths
    paths: List[str] = []
    if args.features:
        paths = [p.strip() for p in args.features.split(',') if p.strip()]

    # If -f points to an existing .feature, filter by file stem using -k
    if args.feature:
        fpath = Path(args.feature)
        if not fpath.exists():
            raise FileNotFoundError(f'Feature file not found: {fpath}')
        unknown = ['-k', fpath.stem] + unknown

    return run_with_pytest(env=args.env,
                           tags=args.tags,
                           features=paths,
                           allure=args.allure,
                           clean_results=args.clean,
                           pytest_extra=unknown)


def debug_run(cfg: Dict[str, Any]) -> int:
    return run_with_pytest(env=cfg.get('env', 'SIT'),
                           tags=cfg.get('tags'),
                           features=cfg.get('features', []),
                           allure=bool(cfg.get('allure', True)),
                           clean_results=bool(cfg.get('clean', True)),
                           pytest_extra=cfg.get('pytest_extra', []))


def main_entry(debug_cfg: Dict[str, Any]) -> int:
    import sys
    if len(sys.argv) > 1:
        return cli_main(sys.argv[1:])
    return debug_run(debug_cfg)