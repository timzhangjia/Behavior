from __future__ import annotations

from typing import Dict, Optional

from playwright.sync_api import TimeoutError

from .base import BasePage, PlaywrightSession


class GoogleLoginPage(BasePage):
    """Page Object representing the Google login page."""

    def __init__(self, session: PlaywrightSession, selectors: Dict[str, str]):
        super().__init__(session)
        self._selectors = selectors

    @property
    def email_input(self) -> str:
        return self._selectors.get("email_input", 'input[type="email"]')

    @property
    def next_button(self) -> str:
        return self._selectors.get("next_button", 'button:has-text("Next")')

    def load(self, url: str) -> None:
        self.goto(url)

    def enter_email(self, email: str) -> None:
        self.fill(self.email_input, email)

    def click_next(self) -> None:
        if self.is_visible(self.next_button, timeout=2000):
            self.click(self.next_button)

    def is_email_prefilled(self, expected: str) -> bool:
        current_value = self.page.locator(self.email_input).input_value(timeout=2000)
        return current_value.strip() == expected.strip()


class GoogleSearchPage(BasePage):
    """Page Object representing Google search interactions."""

    def __init__(self, session: PlaywrightSession, selectors: Dict[str, str]):
        super().__init__(session)
        self._selectors = selectors

    @property
    def search_box(self) -> str:
        return self._selectors.get("search_box", 'input[name="q"]')

    @property
    def results_selector(self) -> str:
        return self._selectors.get("search_results", "div#search h3")

    def load(self, url: str) -> None:
        self.goto(url)
        self._accept_consent_if_present()

    def search(self, keyword: str) -> None:
        self.fill(self.search_box, keyword)
        self.page.keyboard.press("Enter")
        self.page.wait_for_selector(self.results_selector, timeout=10000)

    def get_result_texts(self, limit: Optional[int] = None) -> list[str]:
        texts = self.text_contents(self.results_selector)
        if limit:
            return texts[:limit]
        return texts

    def _accept_consent_if_present(self) -> None:
        candidates = [
            'button:has-text("Accept all")',
            'button:has-text("I agree")',
            'button:has-text("Accept")',
            'button:has-text("AGREE")',
            'button:has-text("Got it")',
        ]
        for selector in candidates:
            locator = self.page.locator(selector).first
            try:
                if locator.is_visible(timeout=2000):
                    locator.click()
                    self.page.wait_for_timeout(500)
                    break
            except TimeoutError:
                continue

