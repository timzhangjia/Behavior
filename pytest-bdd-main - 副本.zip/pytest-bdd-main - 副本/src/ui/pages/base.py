from __future__ import annotations

from dataclasses import dataclass
from typing import Optional, Tuple

from playwright.sync_api import Browser, BrowserContext, Page, TimeoutError, sync_playwright


@dataclass
class SessionOptions:
    headless: bool = True
    slow_mo: int = 0
    viewport: Optional[Tuple[int, int]] = None


class PlaywrightSession:
    """Thin wrapper around Playwright lifecycle management."""

    def __init__(self, options: SessionOptions | None = None):
        self.options = options or SessionOptions()
        self._playwright = None
        self.browser: Optional[Browser] = None
        self.context: Optional[BrowserContext] = None
        self.page: Optional[Page] = None

    def start(self) -> Page:
        if self.page:
            return self.page

        self._playwright = sync_playwright().start()
        launch_kwargs = {"headless": self.options.headless}
        if self.options.slow_mo:
            launch_kwargs["slow_mo"] = self.options.slow_mo

        self.browser = self._playwright.chromium.launch(**launch_kwargs)
        context_kwargs = {}
        if self.options.viewport:
            width, height = self.options.viewport
            context_kwargs["viewport"] = {"width": width, "height": height}
        self.context = self.browser.new_context(**context_kwargs)
        self.page = self.context.new_page()
        return self.page

    def stop(self) -> None:
        for handle in (self.page, self.context, self.browser):
            try:
                if handle:
                    handle.close()
            except Exception:
                # We deliberately swallow close errors to keep tear-down resilient.
                pass

        if self._playwright:
            try:
                self._playwright.stop()
            finally:
                self._playwright = None
        self.page = None
        self.context = None
        self.browser = None


class BasePage:
    """Base Page Object providing shared helpers."""

    def __init__(self, session: PlaywrightSession):
        self.session = session
        self.page = session.start()

    def goto(self, url: str, wait_for: str = "networkidle") -> None:
        self.page.goto(url, wait_until="domcontentloaded")
        if wait_for:
            try:
                self.page.wait_for_load_state(wait_for)
            except TimeoutError:
                # Page might not enter the desired state (e.g. streaming pages)
                pass

    def click(self, selector: str, *, timeout: int = 5000) -> None:
        self.page.locator(selector).first.click(timeout=timeout)

    def fill(self, selector: str, value: str, *, timeout: int = 5000, clear: bool = True) -> None:
        locator = self.page.locator(selector).first
        locator.wait_for(timeout=timeout)
        if clear:
            locator.fill(value, timeout=timeout)
        else:
            locator.type(value, timeout=timeout)

    def is_visible(self, selector: str, *, timeout: int = 2000) -> bool:
        locator = self.page.locator(selector).first
        try:
            return locator.is_visible(timeout=timeout)
        except TimeoutError:
            return False

    def text_contents(self, selector: str) -> list[str]:
        return [node.inner_text() for node in self.page.locator(selector).all()]

