"""UI Testing Module - Browser automation and UI testing components."""

from src.ui.pages import (
    BasePage,
    GoogleLoginPage,
    GoogleSearchPage,
    PlaywrightSession,
    SessionOptions,
)

__all__ = [
    "BasePage",
    "PlaywrightSession",
    "SessionOptions",
    "GoogleLoginPage",
    "GoogleSearchPage",
]