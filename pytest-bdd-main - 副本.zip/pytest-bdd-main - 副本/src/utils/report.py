"""Utilities for generating human-readable execution reports."""

from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Iterable, List, Mapping, Optional

from src.utils.logger import Logger

logger = Logger()

try:
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False
    logger.warning("python-docx not installed. Report generation will be disabled.")


def generate_report(results: Iterable[Mapping[str, object]], output_dir: Path) -> Optional[Path]:
    if not DOCX_AVAILABLE:
        logger.error("Cannot generate report without python-docx.")
        return None

    output_dir.mkdir(parents=True, exist_ok=True)
    results_list: List[Mapping[str, object]] = list(results)

    document = Document()
    title = document.add_heading("Test Execution Summary", 0)
    title.alignment = WD_ALIGN_PARAGRAPH.CENTER

    document.add_paragraph(f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    document.add_paragraph(f"Total Scenarios: {len(results_list)}")
    passed = sum(1 for item in results_list if item.get("status") == "passed")
    failed = sum(1 for item in results_list if item.get("status") == "failed")
    skipped = sum(1 for item in results_list if item.get("status") == "skipped")
    document.add_paragraph(f"Passed: {passed}  |  Failed: {failed}  |  Skipped: {skipped}")
    document.add_paragraph("")

    table = document.add_table(rows=1, cols=4)
    headers = table.rows[0].cells
    headers[0].text = "Feature"
    headers[1].text = "Scenario"
    headers[2].text = "Status"
    headers[3].text = "Evidence"

    for item in results_list:
        row = table.add_row().cells
        row[0].text = str(item.get("feature", ""))
        row[1].text = str(item.get("scenario", ""))
        row[2].text = str(item.get("status", "unknown"))
        evidence_path = item.get("evidence")
        row[3].text = str(evidence_path) if evidence_path else ""

    # Add detailed sections with embedded evidence (API/DB and screenshots)
    for item in results_list:
        document.add_page_break()
        feature = str(item.get("feature", ""))
        scenario = str(item.get("scenario", ""))
        document.add_heading(f"{feature} / {scenario}", level=1)
        data = item.get("data") or {}

        # API details
        api_requests = data.get("api_requests", [])
        if api_requests:
            document.add_heading("API Details", level=2)
            for idx, req in enumerate(api_requests, 1):
                document.add_heading(f"Request {idx}", level=3)
                document.add_paragraph(f"Method: {req.get('request', {}).get('method')}")
                document.add_paragraph(f"URL: {req.get('request', {}).get('url')}")
                status_code = req.get('response', {}).get('status_code')
                if status_code is not None:
                    document.add_paragraph(f"Status: {status_code}")

        # DB details
        db_queries = data.get("database_queries", [])
        if db_queries:
            document.add_heading("DB Details", level=2)
            for idx, q in enumerate(db_queries, 1):
                document.add_heading(f"Query {idx}", level=3)
                document.add_paragraph(f"SQL: {q.get('query')}")
                if q.get("error"):
                    document.add_paragraph(f"Error: {q.get('error')}")
                else:
                    document.add_paragraph(f"Rows: {q.get('row_count', 0)}")

        # UI screenshots
        screenshots = data.get("ui_screenshots", [])
        if screenshots:
            document.add_heading("UI Screenshots", level=2)
            for idx, shot in enumerate(screenshots, 1):
                document.add_paragraph(f"Screenshot {idx}: {shot.get('description','')}")
                img_path = Path(shot.get("path",""))
                if img_path.exists():
                    try:
                        paragraph = document.add_paragraph()
                        paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                        run = paragraph.add_run()
                        run.add_picture(str(img_path), width=Inches(6))
                    except Exception:
                        document.add_paragraph(f"[Image not embeddable: {img_path}]")

    report_path = output_dir / "report.docx"
    document.save(str(report_path))
    logger.info(f"Report generated at: {report_path}")
    # Additionally, generate a simple HTML report
    try:
        html_path = output_dir / "report.html"
        with open(html_path, "w", encoding="utf-8") as f:
            f.write("<html><head><meta charset='utf-8'><title>Test Report</title></head><body>")
            f.write("<h1>Test Execution Summary</h1>")
            f.write(f"<p>Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>")
            f.write("<table border='1' cellspacing='0' cellpadding='6'><tr><th>Feature</th><th>Scenario</th><th>Status</th></tr>")
            for item in results_list:
                f.write(f"<tr><td>{item.get('feature','')}</td><td>{item.get('scenario','')}</td><td>{item.get('status','unknown')}</td></tr>")
            f.write("</table>")
            for item in results_list:
                f.write("<hr/>")
                f.write(f"<h2>{item.get('feature','')} / {item.get('scenario','')}</h2>")
                data = item.get("data") or {}
                shots = data.get("ui_screenshots", [])
                if shots:
                    for shot in shots:
                        p = shot.get("path","")
                        desc = shot.get("description","")
                        if p and Path(p).exists():
                            # Use relative path from output_dir for portability
                            try:
                                rel = Path(p).resolve().relative_to(output_dir.resolve())
                                src = rel.as_posix()
                            except Exception:
                                src = Path(p).as_posix()
                            f.write(f"<div><p>{desc}</p><img src='{src}' style='max-width:800px;'/></div>")
            f.write("</body></html>")
        logger.info(f"HTML report generated at: {html_path}")
    except Exception as e:
        logger.warning(f"Failed to generate HTML report: {e}")
    return report_path

