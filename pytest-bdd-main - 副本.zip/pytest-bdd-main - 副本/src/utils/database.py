"""
Database Utility Module - Provides database reading and execution functionality
"""

import pymysql
import psycopg2
import sqlite3
from typing import Dict, Any, Optional, List, Union
from contextlib import contextmanager
from ..utils.logger import Logger


class Database:
    """Database operation utility class"""
    
    def __init__(self, db_type: str = "mysql", **kwargs):
        """
        Initialize database connection
        
        Args:
            db_type: Database type (mysql, postgresql, sqlite)
            **kwargs: Database connection parameters
        """
        self.db_type = db_type.lower()
        self.logger = Logger()
        self.connection_params = kwargs
    
    @contextmanager
    def _get_connection(self):
        """Get database connection context manager"""
        conn = None
        try:
            if self.db_type == "mysql":
                conn = pymysql.connect(**self.connection_params)
            elif self.db_type == "postgresql":
                conn = psycopg2.connect(**self.connection_params)
            elif self.db_type == "sqlite":
                db_path = self.connection_params.get("database", ":memory:")
                conn = sqlite3.connect(db_path)
                conn.row_factory = sqlite3.Row  # Enable access by column name
            else:
                raise ValueError(f"Unsupported database type: {self.db_type}")
            
            yield conn
            conn.commit()
        except Exception as e:
            if conn:
                conn.rollback()
            self.logger.error(f"Database operation failed: {str(e)}")
            raise
        finally:
            if conn:
                conn.close()
    
    def execute_query(self, sql: str, params: Optional[Union[tuple, dict]] = None) -> List[Dict[str, Any]]:
        """
        Execute query SQL statement
        
        Args:
            sql: SQL query statement
            params: SQL parameters (for parameterized queries, prevents SQL injection)
            
        Returns:
            Query result list, each element is a dictionary of row data
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(sql, params)
                
                # Get column names
                if self.db_type == "sqlite":
                    columns = [description[0] for description in cursor.description]
                else:
                    columns = [desc[0] for desc in cursor.description]
                
                # Get all results
                rows = cursor.fetchall()
                
                # Convert to dictionary list
                result = []
                for row in rows:
                    if self.db_type == "sqlite":
                        result.append(dict(row))
                    else:
                        result.append(dict(zip(columns, row)))
                
                cursor.close()
                self.logger.debug(f"Query executed successfully, returned {len(result)} records")
                return result
        except Exception as e:
            self.logger.error(f"Query execution failed: {str(e)}")
            raise
    
    def execute_update(self, sql: str, params: Optional[Union[tuple, dict]] = None) -> int:
        """
        Execute update SQL statement (INSERT, UPDATE, DELETE)
        
        Args:
            sql: SQL update statement
            params: SQL parameters
            
        Returns:
            Number of affected rows
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.execute(sql, params)
                affected_rows = cursor.rowcount
                cursor.close()
                self.logger.debug(f"Update executed successfully, affected {affected_rows} rows")
                return affected_rows
        except Exception as e:
            self.logger.error(f"Update execution failed: {str(e)}")
            raise
    
    def execute_many(self, sql: str, params_list: List[Union[tuple, dict]]) -> int:
        """
        Batch execute SQL statements
        
        Args:
            sql: SQL statement
            params_list: Parameter list
            
        Returns:
            Number of affected rows
        """
        try:
            with self._get_connection() as conn:
                cursor = conn.cursor()
                cursor.executemany(sql, params_list)
                affected_rows = cursor.rowcount
                cursor.close()
                self.logger.debug(f"Batch execution successful, affected {affected_rows} rows")
                return affected_rows
        except Exception as e:
            self.logger.error(f"Batch execution failed: {str(e)}")
            raise
    
    def get_one(self, sql: str, params: Optional[Union[tuple, dict]] = None) -> Optional[Dict[str, Any]]:
        """
        Get single record
        
        Args:
            sql: SQL query statement
            params: SQL parameters
            
        Returns:
            Single record dictionary, returns None if no record
        """
        results = self.execute_query(sql, params)
        return results[0] if results else None

# Behave-friendly action helpers (merged from db_actions)
import os

def connect_database(context, db_type: str) -> None:
    """Establish a database connection based on the requested type."""
    db_type_lower = db_type.lower()
    if db_type_lower == "mysql":
        db = Database(
            db_type="mysql",
            host=os.getenv("DB_HOST", "localhost"),
            port=int(os.getenv("DB_PORT", "3306")),
            user=os.getenv("DB_USER", "root"),
            password=os.getenv("DB_PASSWORD", ""),
            database=os.getenv("DB_NAME", "testdb"),
        )
    elif db_type_lower == "postgresql":
        db = Database(
            db_type="postgresql",
            host=os.getenv("DB_HOST", "localhost"),
            port=int(os.getenv("DB_PORT", "5432")),
            user=os.getenv("DB_USER", "postgres"),
            password=os.getenv("DB_PASSWORD", ""),
            database=os.getenv("DB_NAME", "testdb"),
        )
    elif db_type_lower == "sqlite":
        db = Database(db_type="sqlite", database=os.getenv("DB_NAME", ":memory:"))
    else:
        raise ValueError(f"Unsupported database type: {db_type}")
    context.database = db


def connect_configured_database(context) -> None:
    db_type = os.getenv("DB_TYPE", "mysql")
    connect_database(context, db_type)


def _substitute_variables(context, sql_query: str) -> str:
    query = sql_query
    for var_name, var_value in getattr(context, "variables", {}).items():
        query = query.replace(f"{{{var_name}}}", str(var_value))
    return query


def execute_query_action(context, sql_query: str) -> None:
    if not getattr(context, "database", None):
        raise RuntimeError("Database not connected. Please connect first.")
    query = _substitute_variables(context, sql_query)
    try:
        result = context.database.execute_query(query)
        context.query_result = result
        if hasattr(context, "evidence_manager"):
            context.evidence_manager.add_database_query(query=query, result=result, error=None)
    except Exception as exc:
        if hasattr(context, "evidence_manager"):
            context.evidence_manager.add_database_query(query=query, result=None, error=str(exc))
        raise


def execute_update_action(context, sql_query: str) -> None:
    if not getattr(context, "database", None):
        raise RuntimeError("Database not connected. Please connect first.")
    query = _substitute_variables(context, sql_query)
    try:
        affected = context.database.execute_update(query)
        context.affected_rows = affected
        if hasattr(context, "evidence_manager"):
            context.evidence_manager.add_database_query(query=query, result=[{"affected_rows": affected}], error=None)
    except Exception as exc:
        if hasattr(context, "evidence_manager"):
            context.evidence_manager.add_database_query(query=query, result=None, error=str(exc))
        raise


def assert_query_row_count_action(context, expected_count: int) -> None:
    if not hasattr(context, "query_result"):
        raise AssertionError("No query result available")
    actual = len(context.query_result)
    assert actual == expected_count, f"Expected {expected_count} rows, got {actual}"


def assert_query_value_action(context, row_index: int, column_name: str, expected_value: Any) -> None:
    if not hasattr(context, "query_result"):
        raise AssertionError("No query result available")
    if row_index >= len(context.query_result):
        raise AssertionError(f"Row index {row_index} out of range. Available rows: {len(context.query_result)}")
    row = context.query_result[row_index]
    actual_value = row.get(column_name) if isinstance(row, dict) else row[column_name]
    if isinstance(expected_value, str):
        expected_value = _coerce_value(expected_value)
    assert actual_value == expected_value, f"Expected '{expected_value}', got '{actual_value}'"


def assert_affected_rows_action(context, expected_count: int) -> None:
    if not hasattr(context, "affected_rows"):
        raise AssertionError("No update result available")
    actual = context.affected_rows
    assert actual == expected_count, f"Expected {expected_count} affected rows, got {actual}"


def _coerce_value(raw: str) -> Any:
    lowered = raw.lower()
    if lowered in {"true", "false"}:
        return lowered == "true"
    try:
        if "." in raw:
            return float(raw)
        return int(raw)
    except ValueError:
        return raw