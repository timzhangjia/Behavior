import os
import pandas as pd
import matplotlib.pyplot as plt
from jira import JIRA
from dotenv import load_dotenv
from datetime import datetime
from matplotlib.font_manager import FontProperties  # 解决中文显示问题
# 配置matplotlib中文显示
plt.rcParams["font.family"] = ["SimHei", "WenQuanYi Micro Hei", "Heiti TC"]
plt.rcParams["axes.unicode_minus"] = False  # 解决负号显示问题


load_dotenv()
class JiraTestReportGenerator:
    def __init__(self):
        # 连接 Jira
        default_options={
        "server": "http://localhost:2990/jira",
        "auth_url": "/rest/auth/1/session",
        "context_path": "/",
        "rest_path": "api",
        "rest_api_version": "2",
        "agile_rest_api_version": "1.0",
        "verify": False,
        "resilient": True,
        "async": False,
        "async_workers": 5,
        "client_cert": None,
        "check_update": False,
        # amount of seconds to wait for loading a resource after updating it
        # used to avoid server side caching issues, used to be 4 seconds.
        "delay_reload": 0,
        "headers": {
            "Cache-Control": "no-cache",
            # 'Accept': 'application/json;charset=UTF-8',  # default for REST
            "Content-Type": "application/json",  # ;charset=UTF-8',
            # 'Accept': 'application/json',  # default for REST
            # 'Pragma': 'no-cache',
            # 'Expires': 'Thu, 01 Jan 1970 00:00:00 GMT'
            "X-Atlassian-Token": "no-check",
        }
    }
        self.jira = JIRA(
            server=os.getenv("JIRA_URL"),
            basic_auth=(os.getenv("JIRA_USER"), os.getenv("JIRA_TOKEN")),options=default_options)

    def fetch_test_cases(self, project_key, **filters):
        """
        从 Jira 提取测试用例/测试执行结果
        :param project_key: Jira 项目密钥（如 TEST）
        :param filters: 筛选条件（支持 version/测试计划/状态等）
        :return: 结构化测试数据列表
        """
        # 构建 JQL 查询（按需求扩展）
        jql_parts = [f"project = {project_key}", "issuetype = test"]  # 默认为测试用例类型
        if filters.get("version"):
            jql_parts.append(f"fixVersion = {filters['version']}")
        if filters.get("test_plan"):
            jql_parts.append(f"Test Plan = {filters['test_plan']}")
        if filters.get("status"):
            jql_parts.append(f"status = {filters['status']}")

        jql = " AND ".join(jql_parts)
        print(f"执行 JQL 查询：{jql}")
        # 调用 Jira API 获取数据（分页处理，避免数据量过大）
        test_cases = []
        start_at = 0
        max_results = 100
        while True:
            issues = self.jira.search_issues(jql, startAt=start_at, maxResults=max_results, expand="fields")
            if not issues:
                break

            for issue in issues:
                # 提取核心字段（可按 Jira 自定义字段扩展）
                test_cases.append({
                    "用例ID": issue.key,
                    "用例标题": issue.fields.summary,
                    "项目": issue.fields.project.name,
                    "版本": issue.fields.fixVersions[0].name if issue.fields.fixVersions else "未指定",
                    "优先级": issue.fields.priority.name if issue.fields.priority else "未设置",
                    "状态": issue.fields.status.name,
                    "创建人": issue.fields.creator.displayName,
                    "创建时间": issue.fields.created[:10],  # 格式化时间（年月日）
                    "测试模块": issue.fields.customfield_10000 if hasattr(issue.fields, "customfield_10000") else "未分类",  # 自定义字段（需替换为实际字段ID）
                    "预期结果": issue.fields.description[:200] + "..." if issue.fields.description else "无",  # 截取描述作为预期结果
                    "实际执行结果": self._get_test_execution_result(issue.key)  # 提取测试执行结果（如通过/失败）
                })
            start_at += max_results
        return test_cases

    def _get_test_execution_result(self, test_case_key):
        """
        辅助方法：获取测试用例的最近执行结果（需 Jira 关联测试执行记录）
        """
        try:
            # 查询该用例关联的测试执行记录（JQL 需根据实际配置调整）
            exec_jql = f'issue in tests("{test_case_key}") AND issuetype = 测试执行'
            exec_issues = self.jira.search_issues(exec_jql, maxResults=1)
            if exec_issues:
                # 提取测试执行状态（如 "通过" "失败"，需匹配 Jira 自定义字段）
                execution_status = exec_issues[0].fields.customfield_10001  # 替换为实际测试结果字段ID
                return execution_status if execution_status else "未执行"
            return "未执行"
        except Exception as e:
            return f"查询失败：{str(e)[:50]}"

    def generate_charts(self, output_dir="report_assets"):
        """生成统计图表（饼图：结果分布；柱状图：模块用例数）"""
        if self.test_data is None or self.test_data.empty:
            return None

        os.makedirs(output_dir, exist_ok=True)
        charts = {}
        # 1. 测试结果分布饼图
        result_counts = self.test_data["测试结果"].value_counts()
        plt.figure(figsize=(8, 6))
        plt.pie(result_counts, labels=result_counts.index, autopct="%1.1f%%", startangle=90)
        plt.title("测试结果分布")
        pie_path = os.path.join(output_dir, "result_pie.png")
        plt.savefig(pie_path, bbox_inches="tight")
        charts["结果分布饼图"] = pie_path
        plt.close()
        # 2. 模块用例数量柱状图
        module_counts = self.test_data["测试模块"].value_counts()
        plt.figure(figsize=(10, 6))
        module_counts.plot(kind="bar")
        plt.title("各模块用例数量")
        plt.xticks(rotation=45, ha="right")
        plt.tight_layout()
        bar_path = os.path.join(output_dir, "module_bar.png")
        plt.savefig(bar_path)
        charts["模块用例柱状图"] = bar_path
        plt.close()
        return charts

    def generate_excel_report(self, report_name=None):
        """生成Excel报告（含统计汇总表+详细数据）"""
        if self.test_data is None or self.test_data.empty:
            print("无数据可生成Excel报告")
            return

        report_name = report_name or f"Jira测试报告_{datetime.now().strftime('%Y%m%d')}.xlsx"
        stats = self.generate_statistics()
        with pd.ExcelWriter(report_name, engine="openpyxl") as writer:
            # 1. 统计汇总表
            if stats:
                # 总览数据转DataFrame
                overview_df = pd.DataFrame([stats["总览"]])
                overview_df.to_excel(writer, sheet_name="统计汇总", index=False, startrow=0)
                # 模块统计
                stats["模块统计"].to_excel(writer, sheet_name="统计汇总", index=False, startrow=3)

            # 2. 详细用例数据
            self.test_data.to_excel(writer, sheet_name="用例详情", index=False)

            # 美化列宽
            for sheet_name in ["统计汇总", "用例详情"]:
                worksheet = writer.sheets[sheet_name]
                for column in worksheet.columns:
                    max_len = max(len(str(cell.value)) if cell.value else 0 for cell in column)
                    worksheet.column_dimensions[column[0].column_letter].width = min(max_len + 3, 50)
        print(f"Excel报告生成成功：{os.path.abspath(report_name)}")
        return report_name

    def generate_html_report(self, report_name=None):
        """生成HTML报告（含统计、图表、详细数据）"""
        if self.test_data is None or self.test_data.empty:
            print("无数据可生成HTML报告")
            return

        report_name = report_name or f"Jira测试报告_{datetime.now().strftime('%Y%m%d')}.html"
        stats = self.generate_statistics()
        charts = self.generate_charts()
        # HTML内容模板
        html_content = f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Jira测试报告 - {datetime.now().strftime('%Y-%m-%d')}</title>
            <style>
                body {{ font-family: Arial, sans-serif; margin: 20px; }}
                .summary {{ background-color: #f5f5f5; padding: 15px; margin: 10px 0; border-radius: 5px; }}
                .chart-container {{ display: flex; gap: 20px; margin: 20px 0; flex-wrap: wrap; }}
                .chart {{ flex: 1; min-width: 400px; }}
                table {{ width: 100%; border-collapse: collapse; margin: 20px 0; }}
                th, td {{ border: 1px solid #ddd; padding: 8px; text-align: left; }}
                th {{ background-color: #f2f2f2; }}
            </style>
        </head>
        <body>
            <h1>Jira测试报告</h1>
            <p>生成时间：{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>

            <h2>一、测试总览</h2>
            <div class="summary">
                <p>总用例数：{stats['总览']['总用例数']}</p>
                <p>通过数：{stats['总览']['通过数']} | 失败数：{stats['总览']['失败数']} | 未执行数：{stats['总览']['未执行数']}</p>
                <p>通过率：{stats['总览']['通过率']}</p>
            </div>

            <h2>二、统计图表</h2>
            <div class="chart-container">
                <div class="chart">
                    <h3>测试结果分布</h3>
                    <img src="{charts['结果分布饼图']}" alt="结果分布饼图" width="100%">
                </div>
                <div class="chart">
                    <h3>各模块用例数量</h3>
                    <img src="{charts['模块用例柱状图']}" alt="模块用例柱状图" width="100%">
                </div>
            </div>

            <h2>三、模块详细统计</h2>
            {stats['模块统计'].to_html(index=False)}

            <h2>四、用例详情</h2>
            {self.test_data.to_html(index=False)}
        </body>
        </html>
        """
        with open(report_name, "w", encoding="utf-8") as f:
            f.write(html_content)

        print(f"HTML报告生成成功：{os.path.abspath(report_name)}")
        return report_name

if __name__ == "__main__":
    # Initial Jira 
    generator = JiraTestReportGenerator()
    
    # 1. Set filter
    project_key = "TEST"  # Jira Project Key
    filters = {
        "version": "V1.0",  # 筛选指定版本（可选）
        "status": "已测试",  # 筛选指定状态（可选，如 "待测试" "已通过"）
        "test_plan": "测试计划-2024Q3"  # 筛选指定测试计划（可选，需 Jira 配置测试计划字段）
    }
    # 2. 从 Jira 提取测试数据
    print("开始从 Jira 提取数据...")
    test_data = generator.fetch_test_cases(project_key, **filters)
    print(f"共提取 {len(test_data)} 条测试用例数据")
    # 3. 生成 Excel 报告
    if test_data:
        generator.generate_excel_report(test_data, report_name=f"Jira测试报告_{datetime.now().strftime('%Y%m%d')}.xlsx")
    else:
        print("未提取到测试数据，请检查筛选条件或 Jira 连接配置")


