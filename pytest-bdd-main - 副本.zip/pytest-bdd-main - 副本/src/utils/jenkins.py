from __future__ import annotations

import os
from dataclasses import dataclass
from typing import Any, Dict, Optional

from jenkinsapi.jenkins import Jenkins

from .logger import Logger


@dataclass
class JenkinsCredentials:
    url: str
    username: Optional[str] = None
    password: Optional[str] = None
    api_token: Optional[str] = None

    @classmethod
    def from_env(cls) -> "JenkinsCredentials":
        return cls(
            url=os.getenv("JENKINS_URL", ""),
            username=os.getenv("JENKINS_USERNAME"),
            password=os.getenv("JENKINS_PASSWORD"),
            api_token=os.getenv("JENKINS_API_TOKEN"),
        )


class JenkinsClient:
    """Thin wrapper around jenkinsapi with lazy connection."""

    def __init__(self, credentials: Optional[JenkinsCredentials] = None) -> None:
        self.credentials = credentials or JenkinsCredentials.from_env()
        if not self.credentials.url:
            raise ValueError("Jenkins URL must be provided either via credentials or JENKINS_URL.")
        self.logger = Logger()
        self._client: Optional[Jenkins] = None

    @property
    def client(self) -> Jenkins:
        if not self._client:
            self._client = self._connect()
        return self._client

    def _connect(self) -> Jenkins:
        try:
            auth_kwargs: Dict[str, Any] = {"username": self.credentials.username}
            if self.credentials.api_token:
                auth_kwargs["password"] = self.credentials.api_token
            elif self.credentials.password:
                auth_kwargs["password"] = self.credentials.password
            else:
                auth_kwargs.clear()
            client = Jenkins(self.credentials.url, **auth_kwargs)
            self.logger.info(f"Connected to Jenkins at {self.credentials.url}")
            return client
        except Exception as exc:
            self.logger.error(f"Failed to connect to Jenkins: {exc}")
            raise

    def trigger(self, job_name: str, parameters: Optional[Dict[str, Any]] = None) -> int:
        job = self.client[job_name]
        build = job.invoke(build_params=parameters) if parameters else job.invoke()
        build_number = build.get_number()
        self.logger.info(f"Triggered Jenkins job '{job_name}', build #{build_number}")
        return build_number

    def build_status(self, job_name: str, build_number: int) -> str:
        job = self.client[job_name]
        status = job.get_build(build_number).get_status()
        self.logger.info(f"Jenkins job '{job_name}' build #{build_number} status: {status}")
        return status

    def build_details(self, job_name: str, build_number: int) -> Dict[str, Any]:
        job = self.client[job_name]
        build = job.get_build(build_number)
        return {
            "status": build.get_status(),
            "duration": build.get_duration(),
            "timestamp": build.get_timestamp(),
            "url": build.get_build_url(),
            "console": build.get_console(),
        }

