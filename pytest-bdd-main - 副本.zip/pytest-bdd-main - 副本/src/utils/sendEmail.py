"""common/email.py

EmailReporter - small helper class to send test reports by email.

Features:
- Send plain-text or HTML body
- Attach one or more files (auto-mime detection)
- Supports SMTP with STARTTLS or implicit SSL
- Reads defaults from environment variables: SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS, SMTP_FROM

Usage example:
    from common.email import EmailReporter

    er = EmailReporter()
    er.send_report(
        to_addrs=["qa@example.com"],
        subject="Daily Test Report",
        body="Please find the attached test report.",
        attachments=[r"reports\hk_bbp_bdd.xlsx"]
    )

"""
from __future__ import annotations
import os
import ssl
import mimetypes
from typing import List, Optional
from email.message import EmailMessage
import smtplib
from pathlib import Path


class EmailReporter:
    """Simple email reporter to send test reports with attachments.

    Initialization reads SMTP configuration from environment variables by default:
      - SMTP_HOST (required unless passed explicitly)
      - SMTP_PORT (default: 587)
      - SMTP_USER
      - SMTP_PASS
      - SMTP_FROM (defaults to SMTP_USER)

    Parameters
    ----------
    host: Optional[str]
        SMTP server host (overrides env SMTP_HOST)
    port: Optional[int]
        SMTP server port (overrides env SMTP_PORT)
    username: Optional[str]
        SMTP username (overrides env SMTP_USER)
    password: Optional[str]
        SMTP password (overrides env SMTP_PASS)
    use_ssl: bool
        If True, connect using SMTP_SSL (implicit SSL). If False, use STARTTLS.
    """

    def __init__(
        self,
        host: Optional[str] = None,
        port: Optional[int] = None,
        username: Optional[str] = None,
        password: Optional[str] = None,
        use_ssl: bool = False,
        default_from: Optional[str] = None,
    ) -> None:
        self.host = host or os.getenv("SMTP_HOST")
        self.port = int(port or os.getenv("SMTP_PORT") or (465 if use_ssl else 587))
        self.username = username or os.getenv("SMTP_USER")
        self.password = password or os.getenv("SMTP_PASS")
        self.use_ssl = use_ssl
        self.default_from = default_from or os.getenv("SMTP_FROM") or self.username

        if not self.host:
            raise ValueError("SMTP host is not configured (pass host or set SMTP_HOST)")

    def _build_message(
        self,
        to_addrs: List[str],
        subject: str,
        body: str,
        from_addr: Optional[str] = None,
        cc: Optional[List[str]] = None,
        bcc: Optional[List[str]] = None,
        html: bool = False,
        attachments: Optional[List[str]] = None,
    ) -> EmailMessage:
        msg = EmailMessage()
        msg["Subject"] = subject
        from_addr = from_addr or self.default_from
        msg["From"] = from_addr
        msg["To"] = ", ".join(to_addrs)
        if cc:
            msg["Cc"] = ", ".join(cc)
        # Set body
        if html:
            msg.add_alternative(body, subtype="html")
        else:
            msg.set_content(body)

        # Attach files
        if attachments:
            for p in attachments:
                path = Path(p)
                if not path.exists():
                    # skip missing attachments but warn
                    print(f"[warning] attachment not found: {p}")
                    continue
                ctype, encoding = mimetypes.guess_type(str(path))
                if ctype is None:
                    ctype = "application/octet-stream"
                maintype, subtype = ctype.split("/", 1)
                with path.open("rb") as f:
                    data = f.read()
                msg.add_attachment(data, maintype=maintype, subtype=subtype, filename=path.name)

        return msg

    def send_report(
        self,
        to_addrs: List[str],
        subject: str,
        body: str,
        from_addr: Optional[str] = None,
        cc: Optional[List[str]] = None,
        bcc: Optional[List[str]] = None,
        html: bool = False,
        attachments: Optional[List[str]] = None,
        timeout: int = 30,
    ) -> None:
        """Send an email report.

        to_addrs: list of recipient email addresses
        attachments: optional list of file paths to attach
        """
        if not to_addrs:
            raise ValueError("to_addrs must be a non-empty list")

        msg = self._build_message(to_addrs, subject, body, from_addr, cc, bcc, html, attachments)

        # Build final recipient list
        recipients = list(to_addrs)
        if cc:
            recipients.extend(cc)
        if bcc:
            recipients.extend(bcc)

        # Send via SMTP
        if self.use_ssl:
            context = ssl.create_default_context()
            with smtplib.SMTP_SSL(self.host, self.port, context=context, timeout=timeout) as server:
                if self.username and self.password:
                    server.login(self.username, self.password)
                server.send_message(msg, from_addr=msg["From"], to_addrs=recipients)
        else:
            with smtplib.SMTP(self.host, self.port, timeout=timeout) as server:
                server.ehlo()
                try:
                    server.starttls(context=ssl.create_default_context())
                    server.ehlo()
                except Exception:
                    # some servers may not accept STARTTLS
                    pass
                if self.username and self.password:
                    server.login(self.username, self.password)
                server.send_message(msg, from_addr=msg["From"], to_addrs=recipients)

    def send_report_file(
        self,
        report_path: str,
        to_addrs: List[str],
        subject: Optional[str] = None,
        body: Optional[str] = None,
        **kwargs,
    ) -> None:
        """Convenience wrapper to send a single file as attachment."""
        subject = subject or f"Test Report: {Path(report_path).name}"
        body = body or "Please find the attached test report."
        self.send_report(to_addrs=to_addrs, subject=subject, body=body, attachments=[report_path], **kwargs)


if __name__ == "__main__":
    # Quick demo when run directly (requires SMTP env vars or pass args)
# $env:SMTP_HOST = "smtp.example.com"
# $env:SMTP_PORT = "587"
# $env:SMTP_USER = "reporter@example.com"
# $env:SMTP_PASS = "your-app-password"
# $env:SMTP_FROM = "Automation <reporter@example.com>"
    try:
        er = EmailReporter(host="smtp.office365.com",port=587,username="liyuan.zhu@eastwestbank.com",password="",default_from="liyuan.zhu@eastwestbank.com")
    except Exception as e:
        print(f"EmailReporter not configured: {e}")
    else:
        # Example: send a report if 'allure-report/report.html' exists
        rpt = Path("reports/report.html")
        if rpt.exists():
            er.send_report_file(str(rpt), [os.getenv("REPORT_TO", "liyuan.zhu@eastwestbank.com")])
            print("Sent sample report")
        else:
            print("No sample report found")