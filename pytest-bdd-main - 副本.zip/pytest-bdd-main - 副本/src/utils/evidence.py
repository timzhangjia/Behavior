"""
Test Evidence Manager - Saves test execution evidence (API, DB, UI screenshots)
"""

from __future__ import annotations

import json
import os
import tempfile
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List, Optional

from .logger import Logger

logger = Logger()

try:
    from docx import Document
    from docx.enum.text import WD_ALIGN_PARAGRAPH
    from docx.shared import Inches
    DOCX_AVAILABLE = True
except ImportError:
    DOCX_AVAILABLE = False
    logger.warning("python-docx not installed. Word document generation will be disabled.")


class EvidenceManager:
    """Manager for saving test execution evidence."""

    def __init__(self, evidence_dir: str = "evidence") -> None:
        self.evidence_dir = Path(evidence_dir)
        self.evidence_dir.mkdir(parents=True, exist_ok=True)
        self.current_evidence: Dict[str, Any] = {}
        self._temp_dir: Optional[Path] = None
        self._temp_files: List[Path] = []
        self._scenario_identifier: str = ""

    def start_scenario(self, feature_name: str, scenario_name: str, tags: Optional[List[str]] = None) -> None:
        """Initialise capture for a new scenario."""
        safe_feature = self._sanitize_filename(feature_name)
        safe_scenario = self._sanitize_filename(scenario_name)
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

        self.current_evidence = {
            "feature": feature_name,
            "scenario": scenario_name,
            "timestamp": timestamp,
            "api_requests": [],
            "database_queries": [],
            "ui_screenshots": [],
            "tags": list(tags or []),
        }

        self._scenario_identifier = f"{safe_feature}_{safe_scenario}_{timestamp}"
        self._temp_dir = Path(tempfile.mkdtemp(prefix="evidence_"))
        self._temp_files = []

        logger.info(f"Evidence collection started for scenario: {scenario_name}")

    def prepare_screenshot_path(self, name_hint: str = "screenshot") -> Path:
        """Provide a temporary path for saving a screenshot."""
        if self._temp_dir is None:
            self._temp_dir = Path(tempfile.mkdtemp(prefix="evidence_"))
        safe_name = self._sanitize_filename(name_hint) or "screenshot"
        filename = f"{safe_name}_{datetime.now().strftime('%H%M%S_%f')}.png"
        path = self._temp_dir / filename
        self._temp_files.append(path)
        return path

    def add_api_request(
        self,
        method: str,
        url: str,
        headers: Optional[Dict[str, str]] = None,
        body: Optional[Any] = None,
        response_status: Optional[int] = None,
        response_headers: Optional[Dict[str, str]] = None,
        response_body: Optional[Any] = None,
    ) -> None:
        request_evidence = {
            "timestamp": datetime.now().isoformat(),
            "request": {
                "method": method,
                "url": url,
                "headers": headers or {},
                "body": self._serialize_body(body),
            },
            "response": {
                "status_code": response_status,
                "headers": response_headers or {},
                "body": self._serialize_body(response_body),
            },
        }
        self.current_evidence.setdefault("api_requests", []).append(request_evidence)
        logger.debug(f"API request evidence added: {method} {url}")

    def add_database_query(
        self,
        query: str,
        result: Optional[List[Dict[str, Any]]] = None,
        error: Optional[str] = None,
    ) -> None:
        query_evidence = {
            "timestamp": datetime.now().isoformat(),
            "query": query,
            "result": result or [],
            "row_count": len(result) if result else 0,
            "error": error,
        }
        self.current_evidence.setdefault("database_queries", []).append(query_evidence)
        logger.debug(f"Database query evidence added: {query}")

    def add_ui_screenshot(self, screenshot_path: str, description: str = "", page_url: str = "") -> None:
        screenshot_info = {
            "timestamp": datetime.now().isoformat(),
            "path": screenshot_path,
            "description": description,
            "page_url": page_url,
        }
        self.current_evidence.setdefault("ui_screenshots", []).append(screenshot_info)
        logger.debug(f"UI screenshot evidence added: {screenshot_path}")

    def save_evidence(self) -> Optional[Path]:
        if not self.current_evidence or not self.current_evidence.get("scenario"):
            return None
        if not DOCX_AVAILABLE:
            logger.error("python-docx is required to generate evidence documents.")
            return None

        safe_feature = self._sanitize_filename(self.current_evidence["feature"])
        feature_dir = self.evidence_dir / safe_feature
        feature_dir.mkdir(parents=True, exist_ok=True)

        evidence_path = feature_dir / f"{self._scenario_identifier}.docx"
        try:
            self._write_document(evidence_path)
            logger.info(f"Evidence saved to: {evidence_path}")
            return evidence_path
        except Exception as exc:  # pragma: no cover
            logger.error(f"Failed to save evidence: {exc}")
            return None
        finally:
            self._cleanup_temp_artifacts()

    def _write_document(self, evidence_path: Path) -> None:
        doc = Document()

        title = doc.add_heading(f"{self.current_evidence['feature']} - {self.current_evidence['scenario']}", 0)
        title.alignment = WD_ALIGN_PARAGRAPH.CENTER

        doc.add_paragraph(f"Feature: {self.current_evidence['feature']}")
        doc.add_paragraph(f"Scenario: {self.current_evidence['scenario']}")
        doc.add_paragraph(f"Executed At: {self.current_evidence['timestamp']}")
        if self.current_evidence.get("tags"):
            doc.add_paragraph(f"Tags: {', '.join(self.current_evidence['tags'])}")
        doc.add_paragraph("")

        api_requests = self.current_evidence.get("api_requests", [])
        db_queries = self.current_evidence.get("database_queries", [])
        ui_screenshots = self.current_evidence.get("ui_screenshots", [])
        tags = set(self.current_evidence.get("tags", []))

        if api_requests:
            doc.add_heading("API Execution Details", level=1)
            for idx, req in enumerate(api_requests, 1):
                doc.add_heading(f"Request {idx}", level=2)
                doc.add_paragraph(f"Method: {req['request']['method']}")
                doc.add_paragraph(f"URL: {req['request']['url']}")
                if req["request"].get("headers"):
                    doc.add_paragraph(f"Headers: {json.dumps(req['request']['headers'], indent=2, ensure_ascii=False)}")
                if req["request"].get("body") is not None:
                    doc.add_paragraph(f"Body: {json.dumps(req['request']['body'], indent=2, ensure_ascii=False)}")
                doc.add_paragraph(f"Response Status: {req['response']['status_code']}")
                if req["response"].get("headers"):
                    doc.add_paragraph(f"Response Headers: {json.dumps(req['response']['headers'], indent=2, ensure_ascii=False)}")
                if req["response"].get("body") is not None:
                    doc.add_paragraph(f"Response Body: {json.dumps(req['response']['body'], indent=2, ensure_ascii=False)}")
                doc.add_paragraph("")

        if db_queries:
            doc.add_heading("DB Details", level=1)
            for idx, query in enumerate(db_queries, 1):
                doc.add_heading(f"Query {idx}", level=2)
                doc.add_paragraph(f"SQL: {query['query']}")
                if query.get("error"):
                    doc.add_paragraph(f"Error: {query['error']}")
                else:
                    doc.add_paragraph(f"Rows: {query.get('row_count', 0)}")
                    if query.get("result"):
                        doc.add_paragraph(f"Result: {json.dumps(query['result'], indent=2, ensure_ascii=False)}")
                doc.add_paragraph("")

        if "ui" in tags and ui_screenshots:
            doc.add_heading("UI Evidence", level=1)
            for idx, screenshot_info in enumerate(ui_screenshots, 1):
                doc.add_heading(f"Screenshot {idx}", level=2)
                if screenshot_info.get("description"):
                    doc.add_paragraph(f"Description: {screenshot_info['description']}")
                if screenshot_info.get("page_url"):
                    doc.add_paragraph(f"Page URL: {screenshot_info['page_url']}")
                if screenshot_info.get("timestamp"):
                    doc.add_paragraph(f"Time: {screenshot_info['timestamp']}")
                screenshot_path = Path(screenshot_info["path"])
                if screenshot_path.exists():
                    paragraph = doc.add_paragraph()
                    paragraph.alignment = WD_ALIGN_PARAGRAPH.CENTER
                    run = paragraph.add_run()
                    run.add_picture(str(screenshot_path), width=Inches(6))
                    doc.add_paragraph("")
                else:
                    doc.add_paragraph(f"[Screenshot file not found: {screenshot_path}]")

        doc.save(str(evidence_path))

    def _cleanup_temp_artifacts(self) -> None:
        for file_path in self._temp_files:
            try:
                if file_path.exists():
                    file_path.unlink()
            except Exception as exc:  # pragma: no cover
                logger.warning(f"Failed to remove temporary file {file_path}: {exc}")

        if self._temp_dir and self._temp_dir.exists():
            try:
                os.rmdir(self._temp_dir)
            except OSError:
                pass

        self._temp_files = []
        self._temp_dir = None

    def _serialize_body(self, body: Any) -> Any:
        if body is None:
            return None
        if isinstance(body, (dict, list)):
            return body
        if isinstance(body, str):
            try:
                return json.loads(body)
            except (json.JSONDecodeError, ValueError):
                return body
        return str(body)

    def _sanitize_filename(self, filename: str) -> str:
        invalid_chars = '<>:"/\\|?*'
        for char in invalid_chars:
            filename = filename.replace(char, "_")
        filename = filename.strip(" .")
        if len(filename) > 100:
            filename = filename[:100]
        return filename

