from pathlib import Path

from pytest_bdd import scenarios

FEATURE_ROOT = Path(__file__).resolve().parents[2] / "features" / "test_case"

scenarios((FEATURE_ROOT / "api" / "api_example.feature").as_posix())
scenarios((FEATURE_ROOT / "ui" / "ui_example.feature").as_posix())

