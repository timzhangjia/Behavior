import glob
import os
from types import SimpleNamespace
from typing import Optional

import pytest

from config import FrameworkConfig, load_config


# load file in the features/steps
steps_path = os.path.join(os.path.dirname(__file__), "features", "steps")
pytest_plugins = []
if os.path.isdir(steps_path):
    for file in glob.glob(os.path.join(steps_path, "**", "*.py"), recursive=True):
        rel_path = os.path.relpath(file, os.path.dirname(__file__))
        module_name = rel_path.replace(os.path.sep, ".").rsplit(".", 1)[0]
        if not module_name.endswith("__init__"):
            pytest_plugins.append(module_name)
    # Preload step modules to ensure step definitions are registered.
    for plugin_name in pytest_plugins:
        __import__(plugin_name)

def pytest_addoption(parser):
    parser.addoption(
        "--test-env",
        action="store",
        default=None,
        help="Target environment profile (e.g. sit, uat). Overrides TEST_ENV.",
    )


@pytest.fixture(scope="session")
def framework_config(pytestconfig) -> FrameworkConfig:
    cli_env: Optional[str] = pytestconfig.getoption("test_env")
    env_name = (cli_env or os.getenv("TEST_ENV") or "sit").lower()
    os.environ["TEST_ENV"] = env_name
    return load_config(env_name)


@pytest.fixture(scope="function")
def context() -> SimpleNamespace:
    """Per-scenario container for sharing data across step definitions."""
    return SimpleNamespace()


# Session-level context management
def pytest_sessionstart(session):
    session.shared_context = {}

def pytest_sessionfinish(session, exitstatus):
    session.shared_context.clear()

# Correct implementation: apply Gherkin tags as pytest markers
# This ensures markers are actually attached to the test function
def pytest_bdd_apply_tag(tag, function):
    marker = pytest.mark.__getattr__(tag)
    marker(function)  # Apply marker to the function

# Optional: before and after scenario hooks for context management
def pytest_bdd_before_scenario(request, feature, scenario):
    request.session.shared_context["current_scenario"] = scenario.name
    context = request.getfixturevalue("context")
    context.config = request.getfixturevalue("framework_config")

def pytest_bdd_after_scenario(request, feature, scenario):
    request.session.shared_context.pop("current_scenario", None)
    try:
        context = request.getfixturevalue("context")
    except Exception:
        return
    session = getattr(context, "ui_session", None)
    if session:
        session.stop()
        context.ui_session = None