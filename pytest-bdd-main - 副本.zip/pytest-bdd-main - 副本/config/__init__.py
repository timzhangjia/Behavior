"""
Top-level helpers for loading framework configuration.

Usage examples:

    from config import load_config

    cfg = load_config()              # auto-detect env via TEST_ENV (default: sit)
    api_request = cfg.get_api_request("create_demo_post")
    payload = cfg.load_api_payload(api_request["payload"])
"""

from .config import FrameworkConfig, config, load_config

__all__ = ["FrameworkConfig", "config", "load_config"]