from __future__ import annotations

import json
import os
from configparser import ConfigParser
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, Optional

import yaml


def _resolve_env_placeholders(value: Any) -> Any:
    """Recursively resolve ${VAR} placeholders using environment variables."""

    def _replace_env_var(text: str) -> str:
        if text.startswith("${") and text.endswith("}"):
            env_name = text[2:-1]
            return os.getenv(env_name, "")
        return text

    if isinstance(value, dict):
        return {key: _resolve_env_placeholders(val) for key, val in value.items()}
    if isinstance(value, list):
        return [_resolve_env_placeholders(item) for item in value]
    if isinstance(value, str):
        return _replace_env_var(value)
    return value


def _read_yaml(path: Path, *, required: bool = True) -> Dict[str, Any]:
    if not path.exists():
        if required:
            raise FileNotFoundError(f"Configuration file not found: {path}")
        return {}
    with path.open("r", encoding="utf-8") as fh:
        data = yaml.safe_load(fh) or {}
    return _resolve_env_placeholders(data)


def _parse_window_size(raw: str) -> tuple[int, int]:
    try:
        width_str, height_str = (part.strip() for part in raw.split(",", maxsplit=1))
        return int(width_str), int(height_str)
    except Exception as exc:  # pragma: no cover - fallback path
        raise ValueError(f"Invalid window size format: {raw}") from exc


@dataclass(frozen=True)
class BrowserOptions:
    headless: bool
    slow_mo: int
    viewport: tuple[int, int]


class FrameworkConfig:
    """Unified configuration loader supporting multi-environment profiles."""

    def __init__(self, env: Optional[str] = None, project_root: Optional[Path] = None) -> None:
        self.project_root = project_root or Path(__file__).resolve().parents[1]
        self.config_root = self.project_root / "config"
        if not self.config_root.exists():
            raise FileNotFoundError(f"Config directory not found: {self.config_root}")

        self.environment = (env or os.getenv("TEST_ENV") or "sit").lower()
        self._settings_parser = self._load_settings()
        self.env_root = self.config_root / self.environment
        if not self.env_root.exists():
            raise FileNotFoundError(f"Environment directory not found: {self.env_root}")

        self._api_config = _read_yaml(self.env_root / "api" / "api_config.yaml")
        self._ui_config = _read_yaml(self.env_root / "ui" / "ui_config.yaml")
        self._db_config = _read_yaml(self.env_root / "db" / "db_config.yaml", required=False)

    # --------------------------------------------------------------------- #
    # Generic helpers
    # --------------------------------------------------------------------- #
    @property
    def settings(self) -> ConfigParser:
        return self._settings_parser

    def _load_settings(self) -> ConfigParser:
        parser = ConfigParser()
        settings_path = self.config_root / "settings.ini"
        if not settings_path.exists():
            raise FileNotFoundError(f"settings.ini not found: {settings_path}")
        parser.read(settings_path, encoding="utf-8")
        return parser

    # --------------------------------------------------------------------- #
    # Browser configuration
    # --------------------------------------------------------------------- #
    def browser_options(self) -> BrowserOptions:
        defaults = self._settings_parser
        headless_env = os.getenv("HEADLESS")
        headless_default = defaults.getboolean("BROWSER", "headless", fallback=True)
        headless = headless_default if headless_env is None else headless_env.lower() == "true"

        ui_browser = self._ui_config.get("ui", {}).get("browser", {})
        slow_mo = int(ui_browser.get("slow_mo", 0))
        window_size_raw = ui_browser.get(
            "viewport",
            defaults.get("BROWSER", "window_size", fallback="1920,1080"),
        )
        if isinstance(window_size_raw, Iterable) and not isinstance(window_size_raw, str):
            values = list(window_size_raw)
            if len(values) == 2:
                try:
                    viewport = (int(values[0]), int(values[1]))
                except (TypeError, ValueError):
                    viewport = (1920, 1080)
            else:
                viewport = (1920, 1080)
        else:
            viewport = _parse_window_size(str(window_size_raw))

        return BrowserOptions(headless=headless, slow_mo=slow_mo, viewport=viewport)

    # --------------------------------------------------------------------- #
    # UI configuration helpers
    # --------------------------------------------------------------------- #
    @property
    def ui(self) -> Dict[str, Any]:
        return self._ui_config.get("ui", {})

    def get_ui(self, dotted_path: str, default: Any = None) -> Any:
        return _dig(self.ui, dotted_path, default)

    # --------------------------------------------------------------------- #
    # API configuration helpers
    # --------------------------------------------------------------------- #
    @property
    def api(self) -> Dict[str, Any]:
        return self._api_config.get("api", {})

    def get_api(self, dotted_path: str, default: Any = None) -> Any:
        return _dig(self.api, dotted_path, default)

    def get_api_request(self, name: str) -> Dict[str, Any]:
        requests = self.api.get("requests", {})
        if name not in requests:
            available = ", ".join(sorted(requests)) or "<none>"
            raise KeyError(f"API request '{name}' not defined. Available: {available}")

        request_cfg = dict(requests[name])
        base_url = self.api.get("base_url", "")
        endpoint = request_cfg.get("endpoint", "")
        if not endpoint:
            raise ValueError(f"API request '{name}' is missing 'endpoint' configuration.")
        if endpoint.startswith(("http://", "https://")):
            request_cfg["url"] = endpoint
        else:
            request_cfg["url"] = f"{base_url.rstrip('/')}/{endpoint.lstrip('/')}"
        return request_cfg

    def load_api_payload(self, filename: str) -> Dict[str, Any]:
        payload_path = self.env_root / "api" / "payloads" / filename
        if not payload_path.exists():
            raise FileNotFoundError(f"API payload not found: {payload_path}")
        with payload_path.open("r", encoding="utf-8") as fh:
            return json.load(fh)

    # --------------------------------------------------------------------- #
    # DB configuration helpers
    # --------------------------------------------------------------------- #
    @property
    def db(self) -> Dict[str, Any]:
        return self._db_config.get("db", {})


def _dig(mapping: Dict[str, Any], dotted_path: str, default: Any = None) -> Any:
    current: Any = mapping
    for part in dotted_path.split("."):
        if not isinstance(current, dict):
            return default
        if part not in current:
            return default
        current = current[part]
    return current


def load_config(env: Optional[str] = None) -> FrameworkConfig:
    """Factory helper with an expressive verb for callers."""
    return FrameworkConfig(env=env)


# Backwards compatible singleton accessor
config = FrameworkConfig()

