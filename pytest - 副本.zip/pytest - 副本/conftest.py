from __future__ import annotations

import asyncio
import os
import shutil
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any, Dict

import pytest

from src.utils.settings import Settings
from src.utils.logger import Logger
from src.utils.evidence import EvidenceManager
from src.utils.report import generate_report
from src.utils.helpers import run_in_loop


@dataclass
class TestContext:
	"""Lightweight context object to mimic Behave's context for step reuse."""
	settings: Settings
	logger: Logger
	event_loop: asyncio.AbstractEventLoop
	evidence_manager: EvidenceManager
	report_dir: Path
	run_id: str
	# Mutable per-scenario attrs
	feature_name: str | None = None
	scenario_name: str | None = None
	scenario_tags: list[str] | None = None
	browser: Any | None = None
	api_client: Any | None = None
	page: Any | None = None
	response: Any | None = None
	api_headers: Dict[str, str] | None = None
	api_params: Dict[str, Any] | None = None
	variables: Dict[str, Any] | None = None
	current_page_name: str | None = None


@pytest.fixture(scope="session")
def session_artifacts() -> dict:
	"""Initialize session-scoped resources and return a dict shared across tests."""
	logger = Logger()
	settings = Settings()

	# Per-run report directory
	run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
	base_report_dir = Path(os.getenv("REPORT_DIR", "allure-report"))
	report_dir = base_report_dir / f"run_{run_id}"
	report_dir.mkdir(parents=True, exist_ok=True)

	# Evidence directory cleanup and init
	evidence_dir = os.getenv("EVIDENCE_DIR", "evidence")
	try:
		evidence_path = Path(evidence_dir)
		if evidence_path.exists():
			shutil.rmtree(evidence_path)
		evidence_path.mkdir(parents=True, exist_ok=True)
	except Exception as e:  # noqa: BLE001
		logger.warning(f"Failed to cleanup evidence directory: {e}")
	evidence_manager = EvidenceManager(evidence_dir=evidence_dir)

	# Dedicated event loop for the test session
	loop = asyncio.new_event_loop()
	asyncio.set_event_loop(loop)

	return {
		"logger": logger,
		"settings": settings,
		"report_dir": report_dir,
		"run_id": run_id,
		"evidence_manager": evidence_manager,
		"loop": loop,
		"summary_results": [],
	}


@pytest.fixture
def context(session_artifacts: dict) -> TestContext:
	"""Provide a fresh per-test context while sharing session-scoped resources."""
	return TestContext(
		settings=session_artifacts["settings"],
		logger=session_artifacts["logger"],
		event_loop=session_artifacts["loop"],
		evidence_manager=session_artifacts["evidence_manager"],
		report_dir=session_artifacts["report_dir"],
		run_id=session_artifacts["run_id"],
	)


# ---------------------------
# pytest-bdd integration hooks
# ---------------------------

def pytest_bdd_apply_tag(tag, function):
	"""Map Gherkin tags to pytest markers to allow -m selection."""
	return pytest.mark.__getattr__(tag)


@pytest.hookimpl(tryfirst=True)
def pytest_bdd_before_scenario(request, feature, scenario):
	"""Before each scenario: set names, reset per-scenario state, start evidence."""
	ctx: TestContext = request.getfixturevalue("context")
	logger: Logger = ctx.logger
	logger.info(f"Starting Scenario execution: {scenario.name}")
	ctx.feature_name = feature.name
	ctx.scenario_name = scenario.name
	ctx.scenario_tags = list(getattr(scenario, "tags", []))
	ctx.browser = None
	ctx.api_client = None
	ctx.page = None
	ctx.response = None
	ctx.api_headers = None
	ctx.api_params = None
	ctx.variables = None
	ctx.current_page_name = None
	# Evidence for this scenario
	ctx.evidence_manager.start_scenario(ctx.feature_name, ctx.scenario_name, tags=ctx.scenario_tags or [])


@pytest.hookimpl(hookwrapper=True)
def pytest_bdd_after_scenario(request, feature, scenario):
	"""After each scenario: persist evidence, close resources, append summary."""
	yield
	ctx: TestContext = request.getfixturevalue("context")
	logger: Logger = ctx.logger
	logger.info(f"Scenario execution completed: {scenario.name}")
	evidence_path = None
	# Save evidence (and copy screenshots into run assets for the summary)
	if hasattr(ctx, "evidence_manager"):
		data_copy = dict(ctx.evidence_manager.current_evidence)
		screenshots = data_copy.get("ui_screenshots", [])
		if screenshots:
			assets_dir = ctx.report_dir / "assets" / f"{data_copy.get('feature','')}_{data_copy.get('scenario','')}"
			assets_dir.mkdir(parents=True, exist_ok=True)
			for s in screenshots:
				src_path = Path(s.get("path", ""))
				if src_path.exists():
					dest_path = assets_dir / src_path.name
					try:
						shutil.copyfile(src_path, dest_path)
						s["path"] = str(dest_path)
					except Exception:  # noqa: BLE001
						pass
		evidence_path = ctx.evidence_manager.save_evidence()
		if evidence_path:
			logger.info(f"Test evidence saved to: {evidence_path}")
			# Also copy evidence docx into report run folder with unique name
			try:
				dest_docs_dir = ctx.report_dir / "evidence_docs"
				dest_docs_dir.mkdir(parents=True, exist_ok=True)
				# sanitize file name via EvidenceManager helper if available
				safe_feature = ctx.evidence_manager._sanitize_filename(getattr(ctx, "feature_name", "Unknown"))  # noqa: SLF001
				safe_scenario = ctx.evidence_manager._sanitize_filename(scenario.name)  # noqa: SLF001
				dest_name = f"{safe_feature}_{safe_scenario}_{ctx.run_id}.docx"
				shutil.copyfile(evidence_path, dest_docs_dir / dest_name)
			except Exception as e:  # noqa: BLE001
				logger.warning(f"Failed to copy evidence docx to report folder: {e}")

	# Record summary
	session_artifacts = request.getfixturevalue("session_artifacts")
	session_artifacts["summary_results"].append(
		{
			"feature": getattr(ctx, "feature_name", "Unknown"),
			"scenario": scenario.name,
			"status": "unknown",  # pytest-bdd doesn't pass status here; determined by pytest outcome
			"evidence": str(evidence_path) if evidence_path else "",
			"data": data_copy if "data_copy" in locals() else {},
		}
	)

	# Cleanup resources
	loop = ctx.event_loop
	if getattr(ctx, "api_client", None):
		try:
			if loop and not loop.is_closed():
				loop.run_until_complete(ctx.api_client.close())
			else:
				asyncio.run(ctx.api_client.close())
		except Exception as e:  # noqa: BLE001
			logger.error(f"Failed to close API client: {str(e)}")
		ctx.api_client = None
	if getattr(ctx, "browser", None):
		try:
			if loop and not loop.is_closed():
				loop.run_until_complete(ctx.browser.close())
			else:
				asyncio.run(ctx.browser.close())
		except Exception as e:  # noqa: BLE001
			logger.error(f"Failed to close browser: {str(e)}")
		ctx.browser = None


@pytest.hookimpl(tryfirst=True)
def pytest_bdd_before_step(request, feature, scenario, step, step_func):
	ctx: TestContext = request.getfixturevalue("context")
	ctx.logger.debug(f"Executing Step: {step.name}")


@pytest.hookimpl(tryfirst=True)
def pytest_bdd_step_error(request, feature, scenario, step, step_func, exception):
	"""On step error, capture a failure screenshot if there is a page."""
	ctx: TestContext = request.getfixturevalue("context")
	if hasattr(ctx, "page") and ctx.page and hasattr(ctx, "evidence_manager"):
		try:
			screenshot_path = ctx.evidence_manager.prepare_screenshot_path(f"failure_{step.name}")
			run_in_loop(ctx, ctx.page.screenshot(str(screenshot_path), full_page=True))
			ctx.evidence_manager.add_ui_screenshot(
				screenshot_path=str(screenshot_path),
				description=f"Failure screenshot for step '{step.name}'",
				page_url=run_in_loop(ctx, ctx.page.url()),
			)
		except Exception as e:  # noqa: BLE001
			ctx.logger.error(f"Failed to capture failure screenshot: {str(e)}")


def pytest_sessionfinish(session, exitstatus):
	"""Close session event loop and generate summary report."""
	# session is a pytest.Session; pull artifacts from the first node's config
	config = session.config
	# Retrieve our session_artifacts via the stash on the config by reusing the fixture indirectly
	# If it cannot be retrieved (edge case), skip reporting gracefully.
	try:
		# Create a temporary fixture request to access the fixture is non-trivial here;
		# so we store artifacts on config during first fixture creation for reliable access.
		artifacts = getattr(config, "_session_artifacts_cache", None)
		if artifacts is None:
			return
	except Exception:
		return

	logger: Logger = artifacts["logger"]
	loop: asyncio.AbstractEventLoop = artifacts["loop"]
	report_dir: Path = artifacts["report_dir"]
	results = artifacts.get("summary_results", [])

	# Generate summary report (HTML/DOCX handled by generate_report)
	if results:
		report_path = generate_report(results, report_dir)
		if report_path:
			logger.info(f"Summary report generated at: {report_path}")

	# Close event loop
	try:
		if loop and not loop.is_closed():
			pending = asyncio.all_tasks(loop)
			if pending:
				loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
			loop.close()
	except Exception as e:  # noqa: BLE001
		logger.error(f"Error closing event loop: {str(e)}")


@pytest.hookimpl(tryfirst=True)
def pytest_sessionstart(session):
	"""Persist session_artifacts on config for access in pytest_sessionfinish."""
	try:
		# Manually instantiate the fixture to store it for sessionfinish
		# This leverages pytest's fixture mechanism via request isn't available here,
		# so we replicate minimal init to keep logic in one place by calling the function.
		artifacts = session.config._inicache.get("_internal_session_artifacts")  # type: ignore[attr-defined]
		if artifacts is None:
			# Fallback: initialize similarly to session_artifacts()
			logger = Logger()
			settings = Settings()
			run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
			base_report_dir = Path(os.getenv("REPORT_DIR", "allure-report"))
			report_dir = base_report_dir / f"run_{run_id}"
			report_dir.mkdir(parents=True, exist_ok=True)
			evidence_dir = os.getenv("EVIDENCE_DIR", "evidence")
			try:
				evidence_path = Path(evidence_dir)
				if evidence_path.exists():
					shutil.rmtree(evidence_path)
				evidence_path.mkdir(parents=True, exist_ok=True)
			except Exception as e:  # noqa: BLE001
				logger.warning(f"Failed to cleanup evidence directory: {e}")
			evidence_manager = EvidenceManager(evidence_dir=evidence_dir)
			loop = asyncio.new_event_loop()
			asyncio.set_event_loop(loop)
			artifacts = {
				"logger": logger,
				"settings": settings,
				"report_dir": report_dir,
				"run_id": run_id,
				"evidence_manager": evidence_manager,
				"loop": loop,
				"summary_results": [],
			}
		setattr(session.config, "_session_artifacts_cache", artifacts)
	except Exception:
		# Best-effort only; normal fixture still works
		pass


