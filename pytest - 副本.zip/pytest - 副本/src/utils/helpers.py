"""
General helper utilities used across steps and environment.
"""

from __future__ import annotations

import asyncio
from typing import Any, Dict


def run_in_loop(context, coroutine):
    """
    Execute an async coroutine using Behave's context event loop.
    Falls back to asyncio.run when no reusable loop is available.
    """
    loop = getattr(context, "event_loop", None)
    if loop and not loop.is_closed():
        try:
            if loop.is_running():
                import nest_asyncio  # type: ignore
                nest_asyncio.apply()
            return loop.run_until_complete(coroutine)
        except RuntimeError:
            pass
    return asyncio.run(coroutine)


def get_value_from_yaml_path(yaml_data: Dict[str, Any], path: str) -> Any:
    """
    Retrieve a value from nested YAML data using dot notation.
    Example: api_config.base_url -> yaml_data["api_config"]["base_url"]
    """
    value: Any = yaml_data
    for key in path.split("."):
        if isinstance(value, dict) and key in value:
            value = value[key]
        else:
            raise KeyError(f"Path '{path}' not found. Missing key: '{key}'.")
    return value

