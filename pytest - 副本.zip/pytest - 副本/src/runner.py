"""Pytest-BDD test runner entry point."""

from __future__ import annotations

import argparse
import os
import subprocess
import sys

from dataclasses import dataclass
from pathlib import Path


@dataclass
class RunOptions:
	feature: str | None = None
	tags: str | None = None


def build_pytest_command(options: RunOptions) -> list[str]:
	"""Compose a pytest command that collects scenarios from tests/test_features.py."""
	cmd: list[str] = ["pytest", "-q", "tests/test_features.py"]
	# Marker selection via -m to emulate behave --tags
	if options.tags:
		# Support comma-separated tags interpreted as logical AND of tags
		tags = [t.strip() for t in options.tags.split(",") if t.strip()]
		if tags:
			if len(tags) == 1:
				cmd.extend(["-m", tags[0]])
			else:
				selector = " and ".join(tags)
				cmd.extend(["-m", selector])
	# Optional: scope to a single feature file by -k filename stem
	if options.feature:
		feature_path = Path(options.feature)
		if not feature_path.exists():
			raise FileNotFoundError(f"Feature file not found: {feature_path}")
		# pytest-bdd loads all scenarios via scenarios('features'); use -k to filter by feature filename
		cmd.extend(["-k", feature_path.stem])
	return cmd


def run_tests(options: RunOptions) -> int:
	command = build_pytest_command(options)
	print(f"Executing command: {' '.join(command)}")
	env = os.environ.copy()
	# Ensure project root is importable so 'src' can be resolved
	env["PYTHONPATH"] = os.getcwd() + (os.pathsep + env["PYTHONPATH"] if "PYTHONPATH" in env else "")
	result = subprocess.run(command, cwd=os.getcwd(), env=env)
	return result.returncode


def parse_args() -> argparse.Namespace:
	"""Parse command-line arguments for pytest-bdd execution."""
	parser = argparse.ArgumentParser(description="Execute pytest-bdd feature scenarios.")
	parser.add_argument(
		"-f",
		"--feature",
		help="Path to a specific feature file to filter collection (name-based).",
	)
	parser.add_argument(
		"-t",
		"--tags",
		help="Comma separated list of tags to filter scenarios (e.g. api,smoke).",
	)
	return parser.parse_args()


def main() -> None:
	"""CLI entry point."""
	args = parse_args()
	options = RunOptions(
		feature=args.feature,
		tags=args.tags,
	)
	exit_code = run_tests(options)
	sys.exit(exit_code)


if __name__ == "__main__":
	main()

