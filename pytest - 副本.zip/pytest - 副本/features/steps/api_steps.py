"""
API Test Steps - Defines BDD steps for API testing.
"""

from pytest_bdd import given, when, then

from src.api.actions import (
	assert_header,
	assert_is_json,
	assert_json_value,
	assert_status,
	assert_success,
	assert_text_contains,
	initialize_client,
	initialize_client_from_config,
	parse_expected_value,
	save_json_value,
	send_request,
	send_request_with_body_from_text,
	send_request_with_json_file,
	send_request_with_params_table,
	set_auth,
	set_header,
)


@given('I initialize API client with base URL "{base_url}"')
def step_init_api_client(context, base_url):
	initialize_client(context, base_url)


@given('I initialize API client with config file "{config_file}" and value "{yaml_path}"')
def step_init_api_client_from_yaml(context, config_file, yaml_path):
	initialize_client_from_config(context, config_file, yaml_path)


@given('I set API request header "{header_name}" to "{header_value}"')
def step_set_api_header(context, header_name, header_value):
	set_header(context, header_name, header_value)


@given('I set API authentication as "{auth_type}" with credentials "{credentials}"')
def step_set_api_auth(context, auth_type, credentials):
	set_auth(context, auth_type, credentials)


@when('I send "{method}" request to "{endpoint}" with JSON file "{json_file}"')
def step_send_request_with_json_file(context, method, endpoint, json_file):
	send_request_with_json_file(context, method, endpoint, json_file)


@when('I send "{method}" request to "{endpoint}" with request body')
def step_send_request_with_body(context, method, endpoint, doc_string):
	# pytest-bdd provides step doc strings via the 'doc_string' fixture
	send_request_with_body_from_text(context, method, endpoint, doc_string)


@when('I send "{method}" request to "{endpoint}" with query parameters')
def step_send_request_with_params(context, method, endpoint, table):
	# If needed in the future, adapt 'table' to the expected structure; not used in current features.
	send_request_with_params_table(context, method, endpoint, table)


@when('I send "{method}" request to "{endpoint}"')
def step_send_request_only(context, method, endpoint):
	send_request(context, method, endpoint)


@then('the response status code should be "{expected_status}"')
def step_assert_status(context, expected_status):
	assert_status(context, int(expected_status))


@then('the response status code should be successful')
def step_assert_success(context):
	assert_success(context)


@then('the response header "{header_name}" should be "{expected_value}"')
def step_assert_header(context, header_name, expected_value):
	assert_header(context, header_name, expected_value)


@then('the response JSON value for "{key}" should be "{expected_value}"')
def step_assert_json_value(context, key, expected_value):
	parsed_value = parse_expected_value(expected_value)
	assert_json_value(context, key, parsed_value)


@then('the response should contain text "{expected_text}"')
def step_assert_text(context, expected_text):
	assert_text_contains(context, expected_text)


@then('the response should be in JSON format')
def step_assert_json_format(context):
	assert_is_json(context)


@then('I save the response JSON value for "{key}" as "{variable_name}"')
def step_save_json_value_step(context, key, variable_name):
	save_json_value(context, key, variable_name)
