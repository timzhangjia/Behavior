"""
UI Test Steps - Defines BDD steps for UI testing.
"""

from pytest_bdd import given, when, then

from src.ui.actions import (
	assert_element_contains_text,
	assert_element_visible,
	assert_page_title,
	assert_page_url_contains,
	click_element,
	double_click_element,
	ensure_browser,
	hover_element,
	navigate_to,
	navigate_to_from_config,
	open_page,
	open_page_from_config,
	take_manual_screenshot,
	type_text,
	wait_for_page_load,
	wait_seconds,
)


@given('I open the browser')
def step_open_browser(context):
	ensure_browser(context)


@given('I open page "{page_name}" with URL "{url}"')
def step_open_page(context, page_name, url):
	open_page(context, page_name, url, f"Opened page: {page_name}")


@given('I open page "{page_name}" with URL from config "{config_file}" and value "{yaml_path}"')
def step_open_page_from_config(context, page_name, config_file, yaml_path):
	open_page_from_config(context, page_name, config_file, yaml_path)


@when('I navigate to "{url}"')
def step_navigate_to(context, url):
	navigate_to(context, url, f"Navigated to: {url}")


@when('I navigate to URL from config "{config_file}" and value "{yaml_path}"')
def step_navigate_to_from_config(context, config_file, yaml_path):
	navigate_to_from_config(context, config_file, yaml_path)


@when('I type "{text}" into element "{element_name}"')
def step_type_text(context, text, element_name):
	type_text(context, element_name, text)


@when('I click element "{element_name}"')
def step_click_element(context, element_name):
	click_element(context, element_name)


@when('I double click element "{element_name}"')
def step_double_click_element(context, element_name):
	double_click_element(context, element_name)


@when('I hover over element "{element_name}"')
def step_hover_element(context, element_name):
	hover_element(context, element_name)


@when('I wait for "{seconds}" seconds')
def step_wait_seconds(context, seconds):
	wait_seconds(context, int(seconds))


@when('I wait for the page to load')
def step_wait_page_load(context):
	wait_for_page_load(context)


@then('element "{element_name}" should be visible')
def step_assert_element_visible(context, element_name):
	assert_element_visible(context, element_name)


@then('element "{element_name}" should contain text "{expected_text}"')
def step_assert_element_text(context, element_name, expected_text):
	assert_element_contains_text(context, element_name, expected_text)


@then('the page title should be "{expected_title}"')
def step_assert_page_title(context, expected_title):
	assert_page_title(context, expected_title)


@then('the page URL should contain "{expected_url}"')
def step_assert_page_url(context, expected_url):
	assert_page_url_contains(context, expected_url)


@then('I take a screenshot and save it as "{filename}"')
def step_take_screenshot(context, filename):
	take_manual_screenshot(context, filename)
