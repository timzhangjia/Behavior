from pytest_bdd import scenarios

# Collect all scenarios from the features directory
scenarios("features")


