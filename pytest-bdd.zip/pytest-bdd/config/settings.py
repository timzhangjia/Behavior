from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any, Dict, Optional

import yaml
from pydantic import BaseModel, Field


class UserCredentials(BaseModel):
    username: str
    password: str


class EmailConfig(BaseModel):
    smtp_server: str = Field(default="smtp.qq.com")
    smtp_port: int = Field(default=587)
    sender_email: str
    sender_password: str
    recipient_email: str


class APIConfig(BaseModel):
    """API endpoint configuration."""
    login_path: str = Field(default="/auth/login")
    health_path: str = Field(default="/health")
    content_type: str = Field(default="application/json")


class ReportConfig(BaseModel):
    """Report generation configuration."""
    shareable_report_filename: str = Field(default="shareable-report.html")
    email_report_filename: str = Field(default="email-report.html")
    report_prefix: str = Field(default="TestReport_")
    allure_results_dir: str = Field(default="allure-results")
    allure_report_dir: str = Field(default="allure-report")
    reports_dir: str = Field(default="reports")


class EmailTemplateConfig(BaseModel):
    """Email template configuration."""
    placeholder_sender_email: str = Field(default="your_email@qq.com")
    placeholder_sender_password: str = Field(default="your_app_password")
    subject_prefix: str = Field(default="Test Report - ")
    body_template: str = Field(
        default="""测试执行完成！

{test_summary}

详细测试报告请查看附件。

此邮件由自动化测试系统发送。"""
    )


class EnvironmentConfig(BaseModel):
    base_url: str
    api_base_url: str
    timeout: int = Field(default=30000, ge=0)
    users: Dict[str, UserCredentials] = Field(default_factory=dict)
    email: Optional[EmailConfig] = Field(default=None)
    api: Optional[APIConfig] = Field(default=None)
    report: Optional[ReportConfig] = Field(default=None)
    email_template: Optional[EmailTemplateConfig] = Field(default=None)


def _load_yaml(env: str) -> Dict[str, Any]:
    config_dir = Path(__file__).parent
    file_path = config_dir / f"env_{env}.yaml"
    if not file_path.exists():
        available = ", ".join(sorted(p.stem for p in config_dir.glob("env_*.yaml")))
        raise FileNotFoundError(f"Environment '{env}' not found. Available: {available}")

    with file_path.open("r", encoding="utf-8") as f:
        raw: Dict[str, Any] = yaml.safe_load(f) or {}
    return raw


@lru_cache()
def get_settings(env: str) -> EnvironmentConfig:
    """Load environment configuration once per test session."""
    data = _load_yaml(env)
    return EnvironmentConfig(**data)


def get_project_config() -> Dict[str, Any]:
    """Get project-level configuration (paths, defaults, etc.)."""
    config_dir = Path(__file__).parent
    project_config_file = config_dir / "project_config.yaml"
    
    if project_config_file.exists():
        with project_config_file.open("r", encoding="utf-8") as f:
            return yaml.safe_load(f) or {}
    
    # Return defaults if config file doesn't exist
    return {
        "paths": {
            "reports_dir": "reports",
            "allure_results_dir": "allure-results",
            "allure_report_dir": "allure-report",
            "allure_cli_path": "tools/allure/bin/allure",
        },
        "report": {
            "shareable_report_filename": "shareable-report.html",
            "email_report_filename": "email-report.html",
            "report_prefix": "TestReport_",
        },
        "email_template": {
            "placeholder_sender_email": "your_email@qq.com",
            "placeholder_sender_password": "your_app_password",
            "subject_prefix": "Test Report - ",
        },
        "api": {
            "login_path": "/auth/login",
            "health_path": "/health",
            "content_type": "application/json",
        },
    }


def resolve_env(pytest_config) -> str:
    """Helper to resolve target environment from CLI option or default."""
    env = pytest_config.getoption("--env") or "sit"
    return env.lower()
