from __future__ import annotations

import json
from dataclasses import dataclass
from http.server import BaseHTTPRequestHandler, HTTPServer
from threading import Thread
from typing import Dict


@dataclass
class MockAPIServer:
    server: HTTPServer
    thread: Thread
    base_url: str

    def shutdown(self) -> None:
        self.server.shutdown()
        self.thread.join()


class _RequestHandler(BaseHTTPRequestHandler):
    valid_credentials: Dict[str, str] = {"username": "", "password": ""}

    def _send_json(self, status: int, payload: Dict[str, str]) -> None:
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_POST(self) -> None:  # noqa: N802
        if self.path == "/auth/login":
            content_length = int(self.headers.get("Content-Length", "0"))
            raw_body = self.rfile.read(content_length)
            try:
                payload = json.loads(raw_body.decode("utf-8"))
            except json.JSONDecodeError:
                self._send_json(400, {"detail": "Invalid JSON"})
                return

            if (
                payload.get("username") == self.valid_credentials.get("username")
                and payload.get("password") == self.valid_credentials.get("password")
            ):
                self._send_json(200, {"token": "demo-token"})
            else:
                self._send_json(401, {"detail": "Unauthorized"})
        else:
            self._send_json(404, {"detail": "Not found"})

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/health":
            self._send_json(200, {"status": "ok"})
        else:
            self._send_json(404, {"detail": "Not found"})

    def log_message(self, format: str, *args) -> None:  # noqa: A003
        # Suppress console noise during tests
        return


def start_mock_api_server(credentials: Dict[str, str]) -> MockAPIServer:
    class Handler(_RequestHandler):
        pass

    Handler.valid_credentials = credentials

    server = HTTPServer(("127.0.0.1", 0), Handler)
    thread = Thread(target=server.serve_forever, daemon=True)
    thread.start()
    host, port = server.server_address
    base_url = f"http://{host}:{port}"
    return MockAPIServer(server=server, thread=thread, base_url=base_url)

