from __future__ import annotations

import json

from playwright.sync_api import APIRequestContext, APIResponse

from config.settings import get_project_config

from .base_api import BaseAPI


class AuthService(BaseAPI):
    def __init__(self, request: APIRequestContext, base_url: str):
        super().__init__(request, base_url)
        self._project_config = get_project_config()
        self._api_config = self._project_config.get("api", {})
        self._login_path = self._api_config.get("login_path", "/auth/login")
        self._health_path = self._api_config.get("health_path", "/health")
        self._content_type = self._api_config.get("content_type", "application/json")

    def login(self, username: str, password: str) -> APIResponse:
        payload = json.dumps({"username": username, "password": password})
        headers = {"Content-Type": self._content_type}
        return self.post(self._login_path, data=payload, headers=headers)

    def health(self) -> APIResponse:
        return self.get(self._health_path)
