# 变更记录（Changes）

> 本文档记录“最原始版本”到当前版本的所有结构性改动与原因，便于新成员快速了解演进历程与当前约定。

生成时间：2025-11-16

---

## 一、从原始版本到当前版本的关键变化（摘要）

- 测试框架
  - 从自定义/分散的脚本组织，统一到 Pytest + Pytest-BDD + Playwright。
  - 优势：生态成熟、可维护性更强、学习成本更低。

- 报告体系
  - 保留 Allure Web 报告作为数据源，新增“单文件”报告（TestReport_*.html），可直接双击打开/分享。
  - 统一由 run.py 生成，不再输出多份临时报告文件。

- 配置管理
  - 使用 config/env_*.yaml + settings.py 统一加载；新增 project_config（project_config.yaml）管理项目级常量（路径、报告命名、模板占位符等）。

- 目录与命名
  - features/test_case 下按业务域组织 .feature 文件，features/steps 下按 API/UI 拆分步骤定义。
  - utils 目录清理与重命名，职责更清晰：
    - bdd_feature_locator.py：根据步骤文件定位 feature 文件
    - mock_auth_server.py：内置鉴权 API 的 Mock 服务（/auth/login、/health）
    - allure_report_builder.py：Allure Web 报告打包为单文件 HTML
  - 删除未使用/易混淆的工具：email_sender.py、data_generator.py、db_manager.py、clean_allure_fixtures.py

- 运行方式
  - 统一入口：python run.py [-m marker] [--env sit|uat] [--no-open|--no-report]
  - CI 模式：--ci 仅表示非交互（默认不打开浏览器），不再发送邮件或产出多余制品。

---

## 二、当前版本和最原始版本的所有文件改动（简述）

以下为“文件级别”的实际变更，按类别列出。

### 1. 新增文件（核心）
- run.py：统一的执行与报告打包脚本（清理 -> 执行 -> 结果清洗 -> 生成 Allure -> 打包单文件）。
- config/project_config.yaml：项目级通用配置（路径、报告命名、模板占位符、API 路径默认值等）。
- src/utils/allure_report_builder.py：将 Allure Web 报告打包为单文件 HTML。
- src/utils/bdd_feature_locator.py：从步骤文件推断对应的 feature 文件路径。
- src/utils/mock_auth_server.py：简易鉴权 API Mock（/auth/login、/health）。

### 2. 删除文件（未使用/冗余）
- src/utils/email_sender.py：不再支持邮件发送、移除模板与依赖。
- src/utils/data_generator.py：当前示例未使用，避免造成误解。
- src/utils/db_manager.py：未使用的数据库工具，移除。
- src/utils/clean_allure_fixtures.py：清理逻辑已内置在 run.py。
- src/utils/report_builder.py：旧名，已更名为 allure_report_builder.py。
- src/utils/bdd.py：旧名，已更名为 bdd_feature_locator.py。

### 3. 重命名/替换（提炼职责——让名字即含义）
- utils
  - report_builder.py → allure_report_builder.py（强调“构建单文件报告”的职责）
  - bdd.py → bdd_feature_locator.py（强调“定位 feature”的职责）
  - mock_api_server.py → mock_auth_server.py（强调与鉴权相关的 Mock）

- 文档
  - docs/MIGRATION.md → docs/changes.md（统一用“变更记录”，更贴近团队习惯）

### 4. 修改文件（要点）
- run.py
  - 只产出最终的 TestReport_*.html；临时 shareable/email 报告删除。
  - 统一英文输出；示例与参数精简（--no-save、--email-report、--send-email、--shareable 等移除）。
  - 新增 build_final_report_path，按时间戳和 marker/环境生成最终文件名。
  - 引用 utils/allure_report_builder.py 打包最终单文件。

- features/steps/*
  - import from src.utils.bdd_feature_locator import feature_path_for（替换旧 bdd.py 导入）。
  - features/steps/conftest.py 使用 src/utils/mock_auth_server.py。

- config/settings.py
  - 增加 project_config 读取函数（get_project_config）；引入 API/Report/EmailTemplate 配置模型，支持更规范的默认值与占位符。

---

## 三、目录结构（当前）

```
pytest-bdd/
├── config/
│   ├── env_sit.yaml
│   ├── env_uat.yaml
│   ├── project_config.yaml
│   └── settings.py
├── features/
│   ├── test_case/
│   │   ├── api/
│   │   └── ui/
│   ├── test_data/
│   └── steps/
│       ├── api/
│       ├── ui/
│       └── common/
├── src/
│   ├── api/services/
│   └── ui/pages/ + templates/
├── tools/allure/               # 本地 Allure CLI
├── run.py                      # 统一入口（单文件报告）
└── docs/
    ├── README.md
    ├── JENKINS.md
    └── changes.md              # 本文档
```

---

## 四、如何从零开始运行

- 运行全部测试并生成单文件报告：
  - python run.py
- 按标记运行：
  - python run.py -m api
  - python run.py -m smoke
- 切换环境：
  - python run.py -m api --env uat
- 只运行不生成报告：
  - python run.py --no-report
- CI 模式（非交互，不自动打开报告）：
  - python run.py --ci

---

## 五、为什么这样做（设计取舍）
- 移除邮件与多制品：减少配置与维护，避免“多份报告”的困扰；需要发邮件可在 CI 中基于最终 HTML 自行实现。
- 简化 utils：对新人“看名字就懂用途”；删除未使用模块，降低误解。
- 单一入口：所有人只记住 run.py 即可。
- 强约定：features/steps 的组织与命名统一，后续扩大场景时不易混乱。

---

如需查看更细的改动，请使用 git diff --stat 或逐文件对比。
