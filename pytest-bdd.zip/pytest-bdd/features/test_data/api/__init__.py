from __future__ import annotations

from functools import lru_cache
from importlib import resources
import json


@lru_cache()
def load_payload(name: str) -> dict:
    data = resources.files(__name__).joinpath(name).read_text(encoding="utf-8")
    return json.loads(data)
