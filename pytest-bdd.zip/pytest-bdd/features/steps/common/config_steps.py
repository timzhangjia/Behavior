from __future__ import annotations

from pytest_bdd import given, parsers


@given(parsers.parse('the config value "{key}" is loaded'), target_fixture="config_value")
def config_value_fixture(settings, key: str):
    if not hasattr(settings, key):
        raise AttributeError(f"Configuration key '{key}' not found")
    return getattr(settings, key)
