from __future__ import annotations

import allure
from pytest_bdd import given, scenarios, then, when

from src.ui.pages.login_page import LoginPage
from src.utils.bdd_feature_locator import feature_path_for

scenarios(feature_path_for(__file__))


@given("the user opens the sample login page", target_fixture="login_page")
def open_login_page(page, admin_credentials):
    login_page = LoginPage(page)
    login_page.render_demo(admin_credentials["username"], admin_credentials["password"])
    page.take_screenshot("Given the user opens the sample login page")
    return login_page


@when("the user logs in with the admin account")
def login_with_admin(login_page: LoginPage, admin_credentials: dict[str, str]):
    login_page.fill_credentials(**admin_credentials)
    login_page.page.take_screenshot("When the user logs in with the admin account - before click")
    login_page.click_login()


@then("the user should see the dashboard")
def assert_dashboard(login_page: LoginPage):
    login_page.assert_logged_in()
    login_page.page.take_screenshot("Then the user should see the dashboard")
