from __future__ import annotations

from pytest_bdd import scenarios, when

from src.api.services.auth_service import AuthService
from features.steps.api import common_steps  # noqa: F401
from features.steps.common import config_steps  # noqa: F401
from src.utils.bdd_feature_locator import feature_path_for

scenarios(feature_path_for(__file__))


@when("the client checks the health endpoint", target_fixture="response")
def invoke_health(auth_service: AuthService):
    return auth_service.health()
