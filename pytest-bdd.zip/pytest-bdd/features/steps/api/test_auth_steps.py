from __future__ import annotations

import allure
from pytest_bdd import given, parsers, scenarios, then, when

from features.test_data.api import load_payload
from src.api.services.auth_service import AuthService
from features.steps.api import common_steps  # noqa: F401
from src.utils.bdd_feature_locator import feature_path_for

scenarios(feature_path_for(__file__))


@given(parsers.parse('the API payload "{payload_name}" is loaded'), target_fixture="api_payload")
def api_payload_fixture(payload_name: str) -> dict:
    with allure.step(f'Given the API payload "{payload_name}" is loaded'):
        return load_payload(payload_name)


@given(parsers.parse('the config value "{key}" is loaded'), target_fixture="config_value")
def config_value_fixture(settings, key: str):
    with allure.step(f'Given the config value "{key}" is loaded'):
        if not hasattr(settings, key):
            raise AttributeError(f"Configuration key '{key}' not found")
        return getattr(settings, key)


@when("the client requests a token with admin credentials", target_fixture="response")
def request_token(auth_service: AuthService, admin_credentials: dict[str, str]):
    with allure.step("When the client requests a token with admin credentials"):
        return auth_service.login(**admin_credentials)


@when("the client submits the loaded payload for token request", target_fixture="response")
def submit_payload(auth_service: AuthService, api_payload: dict[str, str]):
    with allure.step("When the client submits the loaded payload for token request"):
        return auth_service.login(**api_payload)


@then("the response contains a token")
def assert_token_present(response):
    with allure.step("Then the response contains a token"):
        payload = response.json()
        assert "token" in payload, "Token missing from response"
