from __future__ import annotations

import allure
from pytest_bdd import given, then

from src.api.services.auth_service import AuthService


@given("the API client targets the active environment", target_fixture="auth_service")
def auth_service_fixture(api_request_context, settings) -> AuthService:
    with allure.step("Given the API client targets the active environment"):
        return AuthService(api_request_context, settings.api_base_url)


@then("the API returns a 200 status code")
def assert_status_code(response):
    with allure.step("Then the API returns a 200 status code"):
        assert response.status == 200, f"Expected 200 got {response.status}"
