from __future__ import annotations



from pathlib import Path
from typing import Generator

import pytest
from playwright.sync_api import APIRequestContext, Browser, Playwright, sync_playwright

from config.settings import EnvironmentConfig, get_settings, resolve_env
from src.utils.mock_auth_server import MockAPIServer, start_mock_api_server


@pytest.fixture(scope="session")
def project_root() -> Path:
    return Path(__file__).resolve().parents[3]


@pytest.fixture(scope="session")
def env(pytestconfig: pytest.Config) -> str:
    return resolve_env(pytestconfig)


@pytest.fixture(scope="session")
def settings(env: str) -> EnvironmentConfig:
    return get_settings(env)


@pytest.fixture(scope="session")
def mock_api_server(settings: EnvironmentConfig) -> Generator[MockAPIServer, None, None]:
    admin = settings.users.get("admin")
    credentials = {"username": admin.username, "password": admin.password} if admin else {"username": "", "password": ""}
    server = start_mock_api_server(credentials)
    settings.api_base_url = server.base_url
    yield server
    server.shutdown()


@pytest.fixture(scope="session")
def playwright_sync() -> Generator[Playwright, None, None]:
    with sync_playwright() as playwright:
        yield playwright


@pytest.fixture(scope="session")
def browser(playwright_sync: Playwright) -> Generator[Browser, None, None]:
    browser = playwright_sync.chromium.launch(
        headless=False,  # 显示浏览器窗口
        slow_mo=100      # 每个操作延迟100ms，方便观察
    )
    yield browser
    browser.close()


import allure
from allure_commons.types import AttachmentType


@pytest.hookimpl(tryfirst=True)
def pytest_bdd_before_scenario(request, feature, scenario):
    """Hook to set Allure labels from BDD feature/scenario."""
    # Get feature file name without extension
    feature_file = Path(feature.filename).stem
    
    # Get scenario line range if available
    line_info = ""
    if hasattr(scenario, 'line') and scenario.line:
        # Try to get the end line (scenario usually spans multiple lines)
        # For now, we'll use the start line and estimate end line
        start_line = scenario.line
        # Estimate end line (scenario typically 5-10 lines)
        end_line = start_line + 5
        line_info = f" ({start_line}-{end_line})"
    
    # Set suite to: "Feature: <name> @<file> (start-end)"
    suite_name = f"Feature: {feature.name} @{feature_file}{line_info}"
    allure.dynamic.suite(suite_name)
    
    # Set sub suite to scenario name
    allure.dynamic.sub_suite(f"Scenario: {scenario.name}")
    
    # Set story to scenario name (for better grouping)
    allure.dynamic.story(scenario.name)
    
    # Also set the parent suite to remove Python file path
    # This will make the suite hierarchy cleaner
    allure.dynamic.parent_suite(feature.name)


@pytest.hookimpl(tryfirst=True, hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """Hook to capture test execution status."""
    outcome = yield
    rep = outcome.get_result()
    setattr(item, "rep_" + rep.when, rep)


@pytest.fixture()
def page(browser: Browser, request: pytest.FixtureRequest):
    """Create a new browser page for a test, with automatic screenshot on failure."""
    page = browser.new_page()
    
    # Add a helper method to take screenshots easily
    def take_screenshot(name: str = None):
        """Take a screenshot and attach it to the Allure report."""
        try:
            # Use the step name from the test node if no name is provided
            # The name is usually in the format: test_feature_name[scenario_name]
            # We'll clean it up to be more readable.
            raw_name = request.node.name
            if '[' in raw_name:
                # Extract scenario name from test_search_playwright_keyword[Search Playwright keyword]
                clean_name = raw_name.split('[')[1].replace(']', '')
            else:
                clean_name = raw_name.replace('test_', '')
            
            screenshot_name = name or clean_name

            screenshot = page.screenshot(full_page=True)
            allure.attach(
                screenshot,
                name=screenshot_name,
                attachment_type=AttachmentType.PNG
            )
            print(f"📸 Screenshot saved: {screenshot_name}")
        except Exception as e:
            print(f"❌ Error taking screenshot: {e}")
    
    # Attach the helper method to the page object
    page.take_screenshot = take_screenshot
    
    yield page
    
    # Take screenshot on test failure
    if hasattr(request.node, "rep_call") and request.node.rep_call.failed:
        take_screenshot(f"FAILED_{request.node.name}")
    
    page.close()


@pytest.fixture(scope="session")
def api_request_context(mock_api_server: MockAPIServer, playwright_sync: Playwright, settings: EnvironmentConfig) -> Generator[APIRequestContext, None, None]:
    request_context = playwright_sync.request.new_context(base_url=settings.api_base_url)
    yield request_context
    request_context.dispose()


@pytest.fixture()
def admin_credentials(settings: EnvironmentConfig) -> dict[str, str]:
    admin = settings.users.get("admin")
    if not admin:
        raise RuntimeError("Admin user is not configured in the selected environment")
    return {"username": admin.username, "password": admin.password}
