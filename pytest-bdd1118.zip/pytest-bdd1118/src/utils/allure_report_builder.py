# -*- coding: utf-8 -*-
"""
Allure 报告单文件打包器（Allure Report Single-file Builder）

将已生成的 Allure Web 报告目录打包为一个可独立打开的 HTML 文件：
- 内联 CSS/JS
- 嵌入 JSON 数据与附件（含截图，使用 base64）
- 浏览器直接双击打开，无需本地服务器

用法：
    python allure_report_builder.py <allure_report_dir> <output_html_file>
"""
import argparse
import base64
import json
import mimetypes
from pathlib import Path

# --- 注入的 JS：虚拟文件系统 + 动态重写附件链接 ---
JS_INJECT_SCRIPT = """<script type="text/javascript">
    (function() {
        const VFS = window.__VFS_DATA__;
        function resolvePath(url) {
            try {
                const requestUrl = new URL(url, window.location.href);
                let path = decodeURIComponent(requestUrl.pathname);
                const base = window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/') + 1);
                if (path.startsWith(base)) path = path.substring(base.length);
                return path.startsWith('/') ? path.substring(1) : path;
            } catch (e) { return null; }
        }
        function rewriteElement(element) {
            const attr = element.tagName === 'IMG' ? 'src' : 'href';
            const originalUrl = element.getAttribute(attr);
            if (!originalUrl) return;
            const relativePath = resolvePath(originalUrl);
            if (relativePath && VFS.hasOwnProperty(relativePath)) {
                const file = VFS[relativePath];
                if (file.isBase64) {
                    element.setAttribute(attr, file.content);
                    if (element.tagName === 'A') {
                        element.addEventListener('click', function(e) {
                            e.preventDefault();
                            const w = window.open();
                            w.document.write('<html><head><title>' + relativePath + '</title></head><body style="margin:0;display:flex;justify-content:center;align-items:center;height:100vh;background:#000;"><img src="' + file.content + '" style="max-width:100%;max-height:100%;"/></body></html>');
                            w.document.close();
                        });
                    }
                }
            }
        }
        function scanAndRewrite(){ document.querySelectorAll('img[src], a[href]').forEach(rewriteElement); }
        const observer = new MutationObserver(m=>m.forEach(x=>x.addedNodes.forEach(node=>{
            if (node.nodeType===1){
                if (node.tagName==='IMG'||node.tagName==='A') rewriteElement(node);
                if (node.querySelectorAll) node.querySelectorAll('img[src], a[href]').forEach(rewriteElement);
            }
        })));
        observer.observe(document.documentElement,{childList:true,subtree:true});
        if (document.readyState==='loading') document.addEventListener('DOMContentLoaded', scanAndRewrite); else scanAndRewrite();
        setTimeout(scanAndRewrite, 1000);
        setTimeout(scanAndRewrite, 3000);

        const originalFetch = window.fetch;
        window.fetch = function(url, options){
            const p = resolvePath(url);
            if (p && VFS.hasOwnProperty(p)){
                const file = VFS[p];
                if (file.isBase64){
                    const [header, base64Data] = file.content.split(',');
                    const contentType = header.split(':')[1].split(';')[0];
                    const byteCharacters = atob(base64Data);
                    const byteNumbers = new Array(byteCharacters.length);
                    for (let i=0;i<byteCharacters.length;i++){ byteNumbers[i]=byteCharacters.charCodeAt(i); }
                    const byteArray = new Uint8Array(byteNumbers);
                    const blob = new Blob([byteArray], { type: contentType });
                    return Promise.resolve(new Response(blob));
                } else {
                    return Promise.resolve(new Response(JSON.stringify(file.content),{headers:{'Content-Type':'application/json'}}));
                }
            }
            return originalFetch.apply(this, arguments);
        };

        const originalXhrOpen = XMLHttpRequest.prototype.open;
        const originalXhrSend = XMLHttpRequest.prototype.send;
        XMLHttpRequest.prototype.open = function(method, url, ...args){ this._vfsPath = resolvePath(url); return originalXhrOpen.apply(this, [method, url, ...args]); };
        XMLHttpRequest.prototype.send = function(body){
            if (this._vfsPath && VFS.hasOwnProperty(this._vfsPath)){
                const file = VFS[this._vfsPath];
                const responseText = file.isBase64 ? file.content : JSON.stringify(file.content);
                Object.defineProperty(this,'status',{value:200});
                Object.defineProperty(this,'readyState',{value:4});
                Object.defineProperty(this,'responseText',{value:responseText});
                Object.defineProperty(this,'response',{value:responseText});
                this.dispatchEvent(new Event('load'));
                this.dispatchEvent(new Event('loadend'));
                return;
            }
            return originalXhrSend.apply(this, arguments);
        };
    })();
</script>"""


def get_mime_type(file_path: Path) -> str:
    mime_type, _ = mimetypes.guess_type(file_path)
    return mime_type or 'application/octet-stream'


def main(report_dir: Path, output_file: Path):
    print(f"Packaging Allure report from: {report_dir}")
    print(f"Output will be saved to: {output_file}")

    index_html_path = report_dir / "index.html"
    if not index_html_path.exists():
        print(f"[ERROR] 'index.html' not found in '{report_dir}'. Aborting.")
        return

    with open(index_html_path, 'r', encoding='utf-8') as f:
        html_content = f.read()

    for css_link in report_dir.rglob("*.css"):
        relative_path = css_link.relative_to(report_dir).as_posix()
        print(f"  - Inlining CSS: {relative_path}")
        with open(css_link, 'r', encoding='utf-8') as f:
            css_content = f.read()
        link_tag_alt = f'<link rel="stylesheet" type="text/css" href="{relative_path}">'
        style_tag = f'<style type="text/css">\n{css_content}\n</style>'
        html_content = html_content.replace(link_tag_alt, style_tag)

    print("  - Collecting files for virtual filesystem...")
    vfs_data = {}
    total_data_size = 0
    files_to_embed = [p for p in report_dir.rglob("*") if p.is_file() and p.name != 'index.html' and p.suffix != '.css']

    for file_path in files_to_embed:
        relative_path = file_path.relative_to(report_dir).as_posix()
        try:
            if file_path.suffix == '.json':
                with open(file_path, 'r', encoding='utf-8') as f:
                    content = json.load(f)
                vfs_data[relative_path] = {'content': content, 'isBase64': False}
                size = len(json.dumps(content).encode('utf-8'))
            elif file_path.suffix != '.js':
                with open(file_path, 'rb') as f:
                    encoded = base64.b64encode(f.read()).decode('utf-8')
                mime_type = get_mime_type(file_path)
                content = f"data:{mime_type};base64,{encoded}"
                vfs_data[relative_path] = {'content': content, 'isBase64': True}
                size = len(content.encode('utf-8'))
            else:
                continue
            total_data_size += size
        except Exception as e:
            print(f"[WARN] Could not process file {relative_path}: {e}")

    print(f"  - Collected {len(vfs_data)} data files (Total embedded size: {total_data_size / (1024*1024):.2f} MB).")

    print("  - Embedding VFS data and dynamic rewriter script...")
    vfs_script = f'<script type="text/javascript">window.__VFS_DATA__ = {json.dumps(vfs_data, ensure_ascii=False)};</script>'
    html_content = html_content.replace('</head>', f'{vfs_script}\n{JS_INJECT_SCRIPT}\n</head>')

    for js_file in sorted(list(report_dir.rglob("*.js"))):
        relative_path = js_file.relative_to(report_dir).as_posix()
        print(f"  - Inlining JS: {relative_path}")
        with open(js_file, 'r', encoding='utf-8') as f:
            js_content = f.read()
        script_tag_to_replace = f'<script src="{relative_path}"></script>'
        script_tag_to_replace_async = f'<script async src="{relative_path}"></script>'
        inlined = f'<script type="text/javascript">\n// Inlined from {relative_path}\n{js_content}\n</script>'
        html_content = html_content.replace(script_tag_to_replace, inlined)
        html_content = html_content.replace(script_tag_to_replace_async, inlined)

    try:
        with open(output_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
        print(f"\n[SUCCESS] Report packaged successfully!")
        print(f"  - File: {output_file}")
        print(f"  - Size: {output_file.stat().st_size / (1024 * 1024):.2f} MB")
    except IOError as e:
        print(f"[ERROR] Could not write output file: {e}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Package an Allure report into a single HTML file.")
    parser.add_argument("report_dir", type=Path, help="Path to the generated Allure report directory.")
    parser.add_argument("output_file", type=Path, help="Path to save the single-file HTML report.")
    args = parser.parse_args()

    if not args.report_dir.is_dir():
        print(f"[ERROR] Report directory not found: {args.report_dir}")
    else:
        main(args.report_dir, args.output_file)

