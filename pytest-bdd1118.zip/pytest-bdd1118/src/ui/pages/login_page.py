from __future__ import annotations

from textwrap import dedent

from playwright.sync_api import expect

from .base_page import BasePage


class LoginPage(BasePage):
    username_input = "#username"
    password_input = "#password"
    submit_button = "#submit"
    success_banner = "#welcome-message"

    SAMPLE_HTML = dedent(
        """
        <!DOCTYPE html>
        <html lang=\"en\">
        <head>
          <meta charset=\"utf-8\" />
          <title>Sample Login</title>
          <style>
            body { font-family: Arial, sans-serif; max-width: 320px; margin: 48px auto; }
            label { display: block; margin-bottom: 8px; }
            input { width: 100%; padding: 8px; margin-bottom: 12px; box-sizing: border-box; }
            button { padding: 8px 12px; width: 100%; }
            #welcome-message { display: none; margin-top: 16px; font-weight: bold; color: #0f7a0f; }
            #welcome-message[data-error='true'] { color: #a00; }
          </style>
        </head>
        <body data-username=\"__USERNAME__\" data-password=\"__PASSWORD__\">
          <h1>Sample Login</h1>
          <form id=\"login-form\">
            <label for=\"username\">Username</label>
            <input id=\"username\" name=\"username\" />
            <label for=\"password\">Password</label>
            <input id=\"password\" name=\"password\" type=\"password\" />
            <button id=\"submit\" type=\"submit\">Sign in</button>
          </form>
          <div id=\"welcome-message\"></div>
          <script>
            (function() {
              const form = document.getElementById('login-form');
              const welcome = document.getElementById('welcome-message');
              form.addEventListener('submit', function(event) {
                event.preventDefault();
                const expectedUser = document.body.dataset.username;
                const expectedPass = document.body.dataset.password;
                const providedUser = document.getElementById('username').value;
                const providedPass = document.getElementById('password').value;
                if (providedUser === expectedUser && providedPass === expectedPass) {
                  welcome.textContent = `Welcome, ${providedUser}!`;
                  welcome.dataset.error = 'false';
                  welcome.style.display = 'block';
                } else {
                  welcome.textContent = 'Login failed';
                  welcome.dataset.error = 'true';
                  welcome.style.display = 'block';
                }
              });
            })();
          </script>
        </body>
        </html>
        """
    )

    def render_demo(self, username: str, password: str) -> None:
        html = (
            self.SAMPLE_HTML.replace("__USERNAME__", username)
            .replace("__PASSWORD__", password)
        )
        self.page.set_content(html)

    def login(self, username: str, password: str) -> None:
        self.fill_credentials(username, password)
        self.click_login()

    def fill_credentials(self, username: str, password: str) -> None:
        """Fills the username and password fields."""
        self.fill(self.username_input, username)
        self.fill(self.password_input, password)

    def click_login(self) -> None:
        """Clicks the login button."""
        self.click(self.submit_button)

    def assert_logged_in(self) -> None:
        self.page.wait_for_function(
            "selector => document.querySelector(selector)?.style.display === 'block'",
            arg=self.success_banner,
        )
        banner = self.page.locator(self.success_banner)
        expect(banner).to_be_visible()
        expect(banner).to_contain_text("Welcome")
        expect(banner).not_to_have_attribute("data-error", "true")
