from __future__ import annotations

from playwright.sync_api import Page, expect


class BasePage:
    """Common Playwright helpers for derived page objects."""

    def __init__(self, page: Page):
        self.page = page

    def open(self, url: str) -> None:
        self.page.goto(url)

    def wait_for_url(self, fragment: str, timeout: float | None = None) -> None:
        expect(self.page).to_have_url(lambda url: fragment in url, timeout=timeout)

    def click(self, selector: str) -> None:
        self.page.click(selector)

    def fill(self, selector: str, value: str) -> None:
        self.page.fill(selector, value)

    def get_text(self, selector: str) -> str:
        return self.page.inner_text(selector)
