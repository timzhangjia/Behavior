from __future__ import annotations

from functools import lru_cache
from importlib import resources
import json
import os
import yaml


@lru_cache()
def load_payload(name: str) -> dict:
    data = resources.files(__name__).joinpath(name).read_text(encoding="utf-8")
    return json.loads(data)


# Load YAML configuration files in this package directory into CONFIG_MAP
_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_MAP: dict = {}


def _load_all_yaml_files() -> None:
    for filename in os.listdir(_DIR):
        if filename.endswith((".yaml", ".yml")):
            file_path = os.path.join(_DIR, filename)
            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    data = yaml.safe_load(f) or {}
                    if isinstance(data, dict):
                        CONFIG_MAP.update(data)
            except FileNotFoundError:
                # skip missing files (race conditions, etc.)
                continue


def get_base_path(url_key: str) -> str:
    """Return the base path/string for the given key loaded from package YAML files.

    Raises KeyError if the key is not found.
    """
    if not CONFIG_MAP:
        _load_all_yaml_files()

    if url_key not in CONFIG_MAP:
        raise KeyError(f"Key '{url_key}' not found.")

    return CONFIG_MAP[url_key]


# Eagerly load YAML files so `get_base_path` is ready-to-use.
_load_all_yaml_files()
