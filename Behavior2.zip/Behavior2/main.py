"""Minimal entrypoint to run Behave tests.

Usage:
  - By args: python main.py -f features/api_example.feature -t smoke
  - Or via env: FEATURE=features/api_example.feature TAGS=smoke python main.py
"""

from __future__ import annotations

import argparse
import os
import sys

from run import RunOptions, run_tests


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run Behave features (minimal).")
    group = parser.add_mutually_exclusive_group()
    group.add_argument("-f", "--feature", help="Feature file path")
    group.add_argument("-t", "--tags", help="Comma-separated tags (e.g. ui,smoke)")
    parser.add_argument("--env", help="TEST_ENV (e.g. sit/uat), overrides environment variable")
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    # Defaults: feature from env FEATURE or ui_example; tags from env TAGS if provided
    feature = args.feature or os.getenv("FEATURE")
    tags = args.tags or os.getenv("TAGS")
    # If neither provided, default to run smoke tag
    if not feature and not tags:
        tags = "smoke"
    if args.env:
        os.environ["TEST_ENV"] = args.env
    options = RunOptions(feature=feature, tags=tags)
    sys.exit(run_tests(options))


if __name__ == "__main__":
    main()

