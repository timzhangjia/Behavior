"""Reusable actions for UI-related Behave steps (co-located with UI components)."""

from __future__ import annotations

import asyncio
from datetime import datetime
from pathlib import Path

from src.ui.page import Browser
from src.utils.file_reader import FileReader
from src.utils.logger import Logger
from src.utils.helpers import get_value_from_yaml_path, run_in_loop

logger = Logger()
file_reader = FileReader()


def ensure_browser(context) -> None:
    if not getattr(context, "browser", None):
        context.browser = Browser(context.settings)
        run_in_loop(context, context.browser.start())
        logger.info("Browser opened")


def _capture_screenshot(context, page_name: str, page_url: str, description: str) -> None:
    if not hasattr(context, "page") or not context.page:
        return
    if not hasattr(context, "evidence_manager"):
        return
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    safe_page_name = page_name.replace(" ", "_").replace("/", "_")
    screenshot_hint = f"{safe_page_name}_{timestamp}"
    screenshot_path = context.evidence_manager.prepare_screenshot_path(screenshot_hint)
    run_in_loop(context, context.page.screenshot(str(screenshot_path), full_page=True))
    context.evidence_manager.add_ui_screenshot(
        screenshot_path=str(screenshot_path),
        description=description,
        page_url=page_url,
    )
    logger.debug(f"Screenshot captured: {screenshot_path}")


def open_page(context, page_name: str, url: str, evidence_note: str) -> None:
    ensure_browser(context)
    page = run_in_loop(context, context.browser.new_page(page_name=page_name))
    run_in_loop(context, page.goto(url))
    run_in_loop(context, page.wait_for_load_state("networkidle"))
    context.page = page
    context.current_page_name = page_name
    _capture_screenshot(context, page_name, url, evidence_note)
    logger.info(f"Opened page '{page_name}' -> {url}")


def open_page_from_config(context, page_name: str, config_file: str, yaml_path: str) -> None:
    ui_config_dir = Path(context.settings.ui_config_dir)
    config_path = ui_config_dir / config_file
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    config_data = file_reader.read_yaml(str(config_path))
    url = get_value_from_yaml_path(config_data, yaml_path)
    if not url:
        raise ValueError(f"URL at '{yaml_path}' is empty in '{config_file}'")
    open_page(context, page_name, url, f"Opened page '{page_name}' from config")


def navigate_to(context, url: str, evidence_note: str) -> None:
    run_in_loop(context, context.page.goto(url))
    run_in_loop(context, context.page.wait_for_load_state("networkidle"))
    page_name = getattr(context, "current_page_name", "unknown_page")
    _capture_screenshot(context, page_name, url, evidence_note)
    logger.info(f"Navigated to {url}")


def navigate_to_from_config(context, config_file: str, yaml_path: str) -> None:
    ui_config_dir = Path(context.settings.ui_config_dir)
    config_path = ui_config_dir / config_file
    if not config_path.exists():
        raise FileNotFoundError(f"Config file not found: {config_path}")
    config_data = file_reader.read_yaml(str(config_path))
    url = get_value_from_yaml_path(config_data, yaml_path)
    if not url:
        raise ValueError(f"URL at '{yaml_path}' is empty in '{config_file}'")
    navigate_to(context, url, "Navigated via config")


def type_text(context, element_name: str, text: str) -> None:
    element = _resolve_element(context, element_name)
    try:
        run_in_loop(context, element.wait_for(timeout=5000))
    except Exception:
        pass
    run_in_loop(context, element.type_slowly(text))
    logger.info(f"Typed into '{element_name}': {text}")


def click_element(context, element_name: str) -> None:
    element = _resolve_element(context, element_name)
    run_in_loop(context, element.click())
    logger.info(f"Clicked element '{element_name}'")


def double_click_element(context, element_name: str) -> None:
    element = _resolve_element(context, element_name)
    run_in_loop(context, element.double_click())
    logger.info(f"Double clicked element '{element_name}'")


def hover_element(context, element_name: str) -> None:
    element = _resolve_element(context, element_name)
    run_in_loop(context, element.hover())
    logger.info(f"Hovered element '{element_name}'")


def wait_seconds(context, seconds: int) -> None:
    run_in_loop(context, asyncio.sleep(seconds))
    logger.info(f"Waited {seconds} seconds")


def wait_for_page_load(context) -> None:
    run_in_loop(context, context.page.wait_for_load_state("networkidle"))
    logger.info("Page load completed")


def assert_element_visible(context, element_name: str) -> None:
    element = _resolve_element(context, element_name)
    is_visible = run_in_loop(context, element.is_visible())
    assert is_visible, f"Element {element_name} is not visible"
    logger.info(f"Element '{element_name}' is visible")


def assert_element_contains_text(context, element_name: str, expected_text: str) -> None:
    element = _resolve_element(context, element_name)
    actual_text = run_in_loop(context, element.text_content())
    assert expected_text in actual_text, f"Expected '{expected_text}' in '{actual_text}'"
    logger.info(f"Element '{element_name}' contains '{expected_text}'")


def assert_page_title(context, expected_title: str) -> None:
    actual_title = run_in_loop(context, context.page.title())
    assert actual_title == expected_title, f"Expected title '{expected_title}', got '{actual_title}'"
    logger.info(f"Page title verified: {actual_title}")


def assert_page_url_contains(context, expected_url: str) -> None:
    actual_url = run_in_loop(context, context.page.url())
    assert expected_url in actual_url, f"URL '{actual_url}' does not contain '{expected_url}'"
    logger.info(f"Page URL contains '{expected_url}'")


def take_manual_screenshot(context, filename: str) -> None:
    run_in_loop(context, context.page.screenshot(filename))
    logger.info(f"Screenshot saved as '{filename}'")


def _resolve_element(context, element_name: str):
    page_name = getattr(context, "current_page_name", None)
    if page_name:
        return context.page.get_element_by_name(element_name, page_name=page_name)
    return context.page.get_element(element_name)

