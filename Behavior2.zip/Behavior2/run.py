"""Behavior test runner entry point."""

from __future__ import annotations

import argparse
import os
import subprocess
import sys

from dataclasses import dataclass
from pathlib import Path


@dataclass
class RunOptions:
    feature: str | None = None
    tags: str | None = None
    parallel: bool = False
    workers: int = 1


def build_behave_command(options: RunOptions) -> list[str]:
    cmd: list[str] = ["behave"]
    if options.feature:
        feature_path = Path(options.feature)
        if not feature_path.exists():
            raise FileNotFoundError(f"Feature file not found: {feature_path}")
        cmd.append(str(feature_path))
    else:
        cmd.append("features")

    if options.tags:
        for tag in options.tags.split(","):
            tag_value = tag.strip()
            if tag_value:
                cmd.extend(["--tags", tag_value])

    cmd.extend(["--no-capture", "--no-capture-stderr"])
    return cmd


def run_tests(options: RunOptions) -> int:
    command = build_behave_command(options)
    print(f"Executing command: {' '.join(command)}")
    if options.parallel:
        print("Note: Parallel execution requires additional tooling. Running in serial mode.")
    env = os.environ.copy()
    # Ensure project root is importable so 'src' package can be resolved from Behave
    env["PYTHONPATH"] = os.getcwd() + (os.pathsep + env["PYTHONPATH"] if "PYTHONPATH" in env else "")
    result = subprocess.run(command, cwd=os.getcwd(), env=env)
    return result.returncode


def parse_args() -> argparse.Namespace:
    """Parse command-line arguments for Behave execution."""
    parser = argparse.ArgumentParser(description="Execute Behave feature files.")
    parser.add_argument(
        "-f",
        "--feature",
        help="Path to a specific feature file. Defaults to running the entire features directory.",
    )
    parser.add_argument(
        "-t",
        "--tags",
        help="Comma separated list of tags to filter scenarios (e.g. api,smoke).",
    )
    parser.add_argument(
        "--parallel",
        action="store_true",
        help="Enable experimental parallel execution (serial fallback when unsupported).",
    )
    parser.add_argument(
        "-w",
        "--workers",
        type=int,
        default=2,
        help="Number of workers when parallel mode is enabled.",
    )
    return parser.parse_args()


def main() -> None:
    """CLI entry point."""
    args = parse_args()
    options = RunOptions(
        feature=args.feature,
        tags=args.tags,
        parallel=args.parallel,
        workers=args.workers,
    )
    exit_code = run_tests(options)
    sys.exit(exit_code)


if __name__ == "__main__":
    main()
