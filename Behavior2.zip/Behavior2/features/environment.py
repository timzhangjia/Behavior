"""
Behave Environment Configuration - Defines pre and post processing for test execution
"""

import asyncio
import os
from pathlib import Path
from datetime import datetime
from src.utils.settings import Settings
from src.ui.page import Browser
from src.api.request import APIRequest
from src.utils.logger import Logger
from src.utils.evidence import EvidenceManager
from src.utils.helpers import run_in_loop
from src.utils.report import generate_report
import shutil

logger = Logger()
settings = Settings()


def before_all(context):
    """Execute before all tests start"""
    try:
        logger.info("=" * 50)
        logger.info("Starting test suite execution")
        logger.info("=" * 50)
        context.settings = settings
        context.logger = logger
        context.browser = None
        context.api_client = None
        context.summary_results = []
        # Per-run report directory, e.g. allure-report/run_YYYYmmdd_HHMMSS
        run_id = datetime.now().strftime("%Y%m%d_%H%M%S")
        base_report_dir = Path(os.getenv("REPORT_DIR", "allure-report"))
        context.report_dir = base_report_dir / f"run_{run_id}"
        context.report_dir.mkdir(parents=True, exist_ok=True)
        context.run_id = run_id
        
        # Initialize evidence manager (cleanup previous evidence first)
        evidence_dir = os.getenv("EVIDENCE_DIR", "evidence")
        try:
            evidence_path = Path(evidence_dir)
            if evidence_path.exists():
                import shutil as _shutil
                _shutil.rmtree(evidence_path)
            evidence_path.mkdir(parents=True, exist_ok=True)
        except Exception as e:
            logger.warning(f"Failed to cleanup evidence directory: {e}")
        context.evidence_manager = EvidenceManager(evidence_dir=evidence_dir)
        
        # Initialize event loop for async operations
        # Create a new event loop for each test run
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        context.event_loop = loop
    except Exception as e:
        logger.error(f"Error in before_all: {str(e)}")
        import traceback
        traceback.print_exc()
        raise


def after_all(context):
    """Execute after all tests complete"""
    logger.info("=" * 50)
    logger.info("Test suite execution completed")
    logger.info("=" * 50)
    
    # Close event loop
    if hasattr(context, 'event_loop'):
        try:
            loop = context.event_loop
            if not loop.is_closed():
                # Wait for pending tasks
                pending = asyncio.all_tasks(loop)
                if pending:
                    loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
                loop.close()
        except Exception as e:
            logger.error(f"Error closing event loop: {str(e)}")

    # Generate summary report
    results = getattr(context, "summary_results", [])
    if results:
        report_path = generate_report(results, context.report_dir)
        if report_path:
            logger.info(f"Summary report generated at: {report_path}")


def before_feature(context, feature):
    """Execute before each feature starts"""
    logger.info(f"Starting Feature execution: {feature.name}")
    context.feature_name = feature.name


def after_feature(context, feature):
    """Execute after each feature completes"""
    logger.info(f"Feature execution completed: {feature.name}")


def before_scenario(context, scenario):
    """Execute before each scenario starts"""
    logger.info(f"Starting Scenario execution: {scenario.name}")
    context.scenario_name = scenario.name
    # Use scenario_tags instead of tags to avoid context masking warning
    if hasattr(scenario, 'tags'):
        context.scenario_tags = scenario.tags
    context.browser = None
    context.api_client = None
    context.page = None
    context.response = None
    
    # Initialize evidence for this scenario
    feature_name = getattr(context, 'feature_name', 'Unknown')
    scenario_tags = list(getattr(scenario, "tags", []))
    context.evidence_manager.start_scenario(feature_name, scenario.name, tags=scenario_tags)


def after_scenario(context, scenario):
    """Execute after each scenario completes"""
    logger.info(f"Scenario execution completed: {scenario.name}")
    
    evidence_path = None
    # Save evidence for this scenario
    if hasattr(context, 'evidence_manager'):
        # Prepare data copy and persist screenshots for summary embedding
        data_copy = dict(context.evidence_manager.current_evidence)
        screenshots = data_copy.get("ui_screenshots", [])
        if screenshots:
            assets_dir = context.report_dir / "assets" / f"{data_copy.get('feature','')}_{data_copy.get('scenario','')}"
            assets_dir.mkdir(parents=True, exist_ok=True)
            for s in screenshots:
                src_path = Path(s.get("path", ""))
                if src_path.exists():
                    dest_path = assets_dir / src_path.name
                    try:
                        shutil.copyfile(src_path, dest_path)
                        s["path"] = str(dest_path)
                    except Exception:
                        pass
        evidence_path = context.evidence_manager.save_evidence()
        if evidence_path:
            logger.info(f"Test evidence saved to: {evidence_path}")
            # Also copy evidence docx into report run folder with unique name
            try:
                safe_feature = context.evidence_manager._sanitize_filename(getattr(context, "feature_name", "Unknown"))
                safe_scenario = context.evidence_manager._sanitize_filename(scenario.name)
                dest_docs_dir = context.report_dir / "evidence_docs"
                dest_docs_dir.mkdir(parents=True, exist_ok=True)
                dest_name = f"{safe_feature}_{safe_scenario}_{context.run_id}.docx"
                shutil.copyfile(evidence_path, dest_docs_dir / dest_name)
            except Exception as e:
                logger.warning(f"Failed to copy evidence docx to report folder: {e}")

    # Record scenario summary
    if hasattr(context, "summary_results"):
        context.summary_results.append({
            "feature": getattr(context, "feature_name", "Unknown"),
            "scenario": scenario.name,
            "status": getattr(scenario, "status", "unknown"),
            "evidence": str(evidence_path) if evidence_path else "",
            "data": data_copy if 'data_copy' in locals() else {},
        })
    
    # Cleanup resources
    loop = context.event_loop if hasattr(context, 'event_loop') else None
    
    if hasattr(context, 'api_client') and context.api_client:
        try:
            if loop and not loop.is_closed():
                loop.run_until_complete(context.api_client.close())
            else:
                asyncio.run(context.api_client.close())
        except Exception as e:
            logger.error(f"Failed to close API client: {str(e)}")
        context.api_client = None
    
    if hasattr(context, 'browser') and context.browser:
        try:
            if loop and not loop.is_closed():
                loop.run_until_complete(context.browser.close())
            else:
                asyncio.run(context.browser.close())
        except Exception as e:
            logger.error(f"Failed to close browser: {str(e)}")
        context.browser = None


def before_step(context, step):
    """Execute before each step starts"""
    logger.debug(f"Executing Step: {step.name}")


def after_step(context, step):
    """Execute after each step completes"""
    if step.status == "failed":
        logger.error(f"Step execution failed: {step.name}")
        if hasattr(context, "page") and context.page and hasattr(context, "evidence_manager"):
            try:
                screenshot_path = context.evidence_manager.prepare_screenshot_path(f"failure_{step.name}")
                run_in_loop(context, context.page.screenshot(str(screenshot_path), full_page=True))
                context.evidence_manager.add_ui_screenshot(
                    screenshot_path=str(screenshot_path),
                    description=f"Failure screenshot for step '{step.name}'",
                    page_url=run_in_loop(context, context.page.url())
                )
            except Exception as e:
                logger.error(f"Failed to capture failure screenshot: {str(e)}")
