"""
Database Test Steps - Defines BDD steps for database verification.
"""

from behave import given, then, when

from src.utils.database import (
    assert_affected_rows_action as assert_affected_rows,
    assert_query_row_count_action as assert_query_row_count,
    assert_query_value_action as assert_query_value,
    connect_configured_database,
    connect_database,
    execute_query_action as execute_query,
    execute_update_action as execute_update,
)


@given('I connect to database "{db_type}"')
def step_connect_database(context, db_type):
    connect_database(context, db_type)


@given('I connect to configured database')
def step_connect_configured_database(context):
    connect_configured_database(context)


@when('I execute SQL query "{sql_query}"')
def step_execute_sql(context, sql_query):
    execute_query(context, sql_query)


@when('I execute SQL update "{sql_query}"')
def step_execute_sql_update(context, sql_query):
    execute_update(context, sql_query)


@then('the query result should contain "{expected_count}" rows')
def step_assert_query_result_count(context, expected_count):
    assert_query_row_count(context, int(expected_count))


@then('the query result row "{row_index}" column "{column_name}" should be "{expected_value}"')
def step_assert_query_result_value(context, row_index, column_name, expected_value):
    assert_query_value(context, int(row_index), column_name, expected_value)


@then('the affected rows should be "{expected_count}"')
def step_assert_affected_rows(context, expected_count):
    assert_affected_rows(context, int(expected_count))

